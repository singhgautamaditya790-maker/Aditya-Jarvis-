package main

import (
	"sync"
	"sync/atomic"
	"time"
)

// TrayStatus is the live data the tray menu shows (design: usejarvis-tray.html
// §00). The brain pushes it via the `tray.status` RPC; the tray thread reads
// it when the menu opens. Platform-neutral so Windows + macOS share one source
// of truth.
type TrayStatus struct {
	State       string   // pebble state: idle/listening/thinking/speaking/asking/done/muted
	Waiting     int      // pending approvals — the "Waiting on you" row
	Recent      []string // recent activity lines ("Sent the Acme reply · 2m"), newest first
	Paused      bool     // agent paused
	Muted       bool     // microphone muted
	BrainOnline bool
	Sidecars    string // "2/2"
	Port        int
}

var (
	trayStatusMu  sync.RWMutex
	trayStatusCur = TrayStatus{State: "idle", Port: 3142}
	// trayRefresh nudges the platform tray to update (icon/tooltip) when the
	// status changes out of band. Set by the platform tray; no-op elsewhere.
	trayRefresh = func() {}
	// trayApplyMuteV gates the microphone locally when the tray "Mute microphone"
	// toggle flips. Mic control the sidecar owns (not the brain): it pauses the
	// wake listener, ends any live realtime session, and reflects it on the
	// pebble. Set by the client once its audio services exist; no-op until then.
	// atomic.Value because connectAndServe re-assigns it on every reconnect while
	// the tray (Windows) / Cocoa (macOS) threads read it — a plain var is a data
	// race. Use trayApplyMute()/setTrayApplyMute(), never the var directly.
	trayApplyMuteV atomic.Value // func(bool)
)

func trayApplyMute(muted bool) {
	if f, ok := trayApplyMuteV.Load().(func(bool)); ok && f != nil {
		f(muted)
	}
}

func setTrayApplyMute(f func(bool)) { trayApplyMuteV.Store(f) }

// trayCtlQ serializes mute/pause side effects off the UI threads. The work
// (audio-device teardown, WS emits) must not block the tray/Cocoa thread, but
// one goroutine per toggle had no ordering guarantee — a rapid double-toggle
// could interleave and leave the mic state diverging from the menu. A single
// worker drains in click order.
var trayCtlQ = make(chan func(), 32)

func init() {
	go func() {
		for f := range trayCtlQ {
			f()
		}
	}()
}

// trayCtlAsync enqueues f for the serialized worker. The 32-deep buffer is far
// beyond any human toggle rate; if it ever fills (wedged brain connection),
// fall back to a raw goroutine rather than blocking the UI thread.
func trayCtlAsync(f func()) {
	select {
	case trayCtlQ <- f:
	default:
		go f()
	}
}

func setTrayStatus(s TrayStatus) {
	trayStatusMu.Lock()
	trayStatusCur = s
	trayStatusMu.Unlock()
	trayRefresh()
}

// micMuted reports whether the user has muted the microphone from the tray.
//
// This is THE gate every path that opens the mic must consult — one-shot
// session capture, realtime voice, and the always-on wake listener. Mute is a
// gate the user owns indefinitely, not a momentary pause a consumer restores
// on its way out; representing it in one place is what keeps the menu, the
// pebble and the device from drifting apart. Cheaper than getTrayStatus()
// (no Recent copy) and safe to call from any goroutine.
func micMuted() bool {
	trayStatusMu.RLock()
	defer trayStatusMu.RUnlock()
	return trayStatusCur.Muted
}

func getTrayStatus() TrayStatus {
	trayStatusMu.RLock()
	defer trayStatusMu.RUnlock()
	s := trayStatusCur
	s.Recent = append([]string(nil), trayStatusCur.Recent...) // copy to avoid a data race
	return s
}

// trayStateCode maps a pebble state string (as pushed in tray.status) to the
// pebble state int the tray icon dot is drawn from — same numbering as
// pebbleStateToInt. Platform-neutral so Windows + macOS share the mapping.
func trayStateCode(s string) int {
	switch s {
	case "listening":
		return 1
	case "thinking":
		return 2
	case "speaking":
		return 3
	case "working":
		return 4
	case "asking":
		return 5
	case "done":
		return 6
	case "muted":
		return 7
	default:
		return 0
	}
}

// trayStatusFromParams merges a `tray.status` RPC payload over the current
// status (partial updates are fine — the brain may send only what changed).
func trayStatusFromParams(params map[string]any) TrayStatus {
	s := getTrayStatus()
	if v, ok := params["state"].(string); ok && v != "" {
		s.State = v
	}
	if v, ok := params["waiting"].(float64); ok {
		s.Waiting = int(v)
	}
	if v, ok := params["paused"].(bool); ok {
		s.Paused = v
	}
	// NOTE: `muted` is deliberately NOT read from this payload. The microphone
	// is sidecar-owned local state (the brain's own tray heartbeat says as
	// much) and micMuted() is now the authoritative gate on every mic-opening
	// path — so honoring a `muted` field here would turn a best-effort status
	// heartbeat into remote mic control, and a brain that echoed muted:false
	// would silently un-gate a mic the user muted. Mute changes only via the
	// tray toggle.
	if v, ok := params["brain_online"].(bool); ok {
		s.BrainOnline = v
	}
	if v, ok := params["sidecars"].(string); ok {
		s.Sidecars = v
	}
	if v, ok := params["port"].(float64); ok && v > 0 {
		s.Port = int(v)
	}
	if arr, ok := params["recent"].([]any); ok {
		s.Recent = s.Recent[:0]
		for _, it := range arr {
			if str, ok := it.(string); ok {
				s.Recent = append(s.Recent, str)
			}
		}
	}
	return s
}

// Self-update entry in the tray menu. Kept apart from TrayStatus: that one is
// the brain's to push (tray.status replaces it), while the update offer is
// the sidecar's own knowledge and must survive every push.
var (
	trayUpdateLabelV atomic.Value // string; "" hides the item
	// trayOpenUpdate opens the update prompt; set by the client.
	trayOpenUpdate func()
	// trayReady is closed once the platform tray owns the UI loop, so a window
	// opened from the startup offer cannot race its setup (macOS).
	trayReady     = make(chan struct{})
	trayReadyOnce sync.Once
)

// trayUpdateLabelFor is the menu text for an update offer ("" = no item).
func trayUpdateLabelFor(o UpdateOffer) string {
	switch {
	case o.Blocked && o.Version != "":
		return "Update required: v" + o.Version + "…"
	case o.Blocked:
		return "Update required…"
	case o.Version != "":
		return "Update to v" + o.Version + "…"
	}
	return ""
}

func setTrayUpdateOffer(o UpdateOffer) {
	label := trayUpdateLabelFor(o)
	if prev, _ := trayUpdateLabelV.Load().(string); prev == label {
		return
	}
	trayUpdateLabelV.Store(label)
	trayRefresh()
}

func trayUpdateLabel() string {
	s, _ := trayUpdateLabelV.Load().(string)
	return s
}

func markTrayReady() { trayReadyOnce.Do(func() { close(trayReady) }) }

// waitTrayReady blocks until the tray is up (true), or timeout (false).
func waitTrayReady(timeout time.Duration) bool {
	select {
	case <-trayReady:
		return true
	case <-time.After(timeout):
		return false
	}
}
