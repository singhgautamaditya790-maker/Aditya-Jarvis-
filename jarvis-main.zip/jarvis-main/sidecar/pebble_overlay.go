package main

// Pebble overlay — native per-platform rendered floating cursor companion.
//
// Architecture (replaces the abandoned webview-based pebble):
//   - One layered/transparent native window per OS
//   - Rendered with native drawing primitives (GDI+ on Windows, Core Graphics
//     on macOS, Cairo on Linux) — no browser, no webview, no transparency hacks
//   - Cursor polled at 60fps; window position SetWindowPos'd with eased
//     physics matching the mock
//   - State machine drives the visible glyph (idle dot / listening waveform /
//     thinking dots / speaking bars / working amber-pulse)
//
// The implementation lives in pebble_overlay_<os>.go behind build tags. This
// file is the cross-platform interface + state types only.

import (
	"sync/atomic"
	"time"
)

// PebbleState mirrors the React state machine used in the design mock.
type PebbleState string

const (
	PebbleIdle      PebbleState = "idle"
	PebbleListening PebbleState = "listening"
	PebbleThinking  PebbleState = "thinking"
	PebbleSpeaking  PebbleState = "speaking"
	PebbleWorking   PebbleState = "working"
	PebbleAsking    PebbleState = "asking" // amber — waiting on your approval/authority
	PebbleDone      PebbleState = "done"   // green flash — job landed
	PebbleMuted     PebbleState = "muted"  // mic muted — quiet, no chroma
)

// PebbleSpec configures the overlay at spawn time.
type PebbleSpec struct {
	// CursorOffsetX/Y is the pixel offset from the OS cursor at which the
	// pebble's centre is rendered. (14, 16) keeps the cursor outside the
	// pebble's visible disc with a comfortable companion distance.
	CursorOffsetX int `json:"cursor_offset_x"`
	CursorOffsetY int `json:"cursor_offset_y"`

	// SummonHotkey, if non-empty, registers a global hotkey that toggles
	// listening/idle and shows/hides the bubble.
	//
	// There is NO default here: the sidecar registers exactly what it is given
	// and empty means "no global hotkey". The default lives on the daemon side
	// (PEBBLE_DEFAULT_SUMMON_HOTKEY in src/config/pebble-hotkeys.ts, overridable
	// via `pebble.summon_hotkey` in config.yaml), because that is where the
	// user's config is read. Naming a default in this comment was wrong even
	// before #563 moved it.
	//
	// Parsed by startHotkeyListener via the shared grammar in
	// hotkeys_keyspec.go; see docs/PEBBLE_HOTKEYS.md.
	SummonHotkey string `json:"summon_hotkey"`

	// PaletteHotkey, if non-empty, registers a second global hotkey that
	// fires the OnPalette callback, opening a fuzzy room picker at the cursor.
	// Same "no default here" rule as SummonHotkey.
	//
	// NOTE: on Windows this value also gates the Ctrl+middle-click palette
	// gesture (pebble_overlay_windows.go), so empty turns off the mouse hook
	// too. Deliberate, and documented in docs/PEBBLE_HOTKEYS.md.
	PaletteHotkey string `json:"palette_hotkey"`
}

// PebbleService is the platform-agnostic API for the native pebble overlay.
// One pebble exists per sidecar at most; callers spawn it once and update
// state via SetState.
type PebbleService interface {
	// Spawn creates and shows the pebble overlay. Idempotent — calling
	// while already spawned is a no-op (returns nil).
	Spawn(spec PebbleSpec) error

	// SetState transitions the pebble to a new visual state. Triggers a
	// repaint on the next frame. Calling while not spawned returns an error.
	SetState(state PebbleState) error

	// SetText updates the body line shown in the bubble (listening hint,
	// speaking transcript). Empty string falls back to the default per-state
	// copy. Safe to call before Spawn — value is just stashed until paint.
	SetText(text string) error

	// PointAt animates the pebble to a fixed virtual-screen position
	// for `durationMs` milliseconds, showing `label` in the bubble. After
	// the duration expires the previous state + text are restored and
	// the pebble resumes cursor-follow. Used by T8's `[POINT:x,y:label]`
	// LLM tags — Clicky-style "click here" UX.
	PointAt(x, y int, label string, durationMs int) error

	// SetEye toggles the eye glyph that visualises awareness/OCR firing.
	// Daemon turns it on when sidecar emits a screen_capture event,
	// clears it after a short timeout. Safe before Spawn.
	SetEye(active bool) error

	// SetAnswerOverflow tells the pebble that the current speaking response
	// is too long to fully fit in the bubble. The sidecar paints an
	// "open full ↗" button; on click it emits pebble.open_answer with
	// `answerID` so the daemon can spawn a markdown panel. Empty string
	// clears the button. Safe before Spawn.
	SetAnswerOverflow(answerID string) error

	// SetBlinded marks awareness as hard-paused. The pebble dims and
	// shows a struck-through eye. Persists across SetState. Safe before
	// Spawn (value just stashed).
	SetBlinded(blinded bool) error

	// SetEthereal configures ethereal mode: when enabled, the pebble fades out
	// after staying idle for idleSeconds and pops back in (a faster animation
	// than the fade-out) the moment it next becomes active. Live-updatable from
	// settings and safe to call before Spawn (the values are just stored).
	SetEthereal(enabled bool, idleSeconds int)

	// Close hides + destroys the overlay. Idempotent.
	Close() error

	// OnSummon registers a callback fired each time the user triggers the
	// summon hotkey. The callback runs on whatever goroutine
	// the hotkey listener uses; receivers should not block.
	//
	// The pebble itself does NOT change state on summon — it leaves that
	// to the brain. The callback is the sidecar's signal to the daemon
	// ("user wants attention"); the daemon then drives state transitions
	// via SetState (listening → thinking → speaking → idle, or whatever
	// the voice/LLM lifecycle dictates).
	OnSummon(callback func())

	// OnPalette registers a callback fired when the user triggers the
	// palette hotkey. Same threading and non-blocking contract as
	// OnSummon. The callback drives the daemon's palette open/close flow.
	OnPalette(callback func())

	// OnBlindToggle (W6-T2) registers a callback fired when the user
	// long-presses the pebble disc. The daemon flips awareness.enabled
	// in config and dispatches pebble.set_blinded.
	OnBlindToggle(callback func())

	// OnAnswerOpen registers a callback fired when the user clicks the
	// "open full ↗" button on the speaking bubble. The callback receives
	// the answer id that SetAnswerOverflow was called with. Threading:
	// runs on a fresh goroutine.
	OnAnswerOpen(callback func(answerID string))
}

// mutedNudgeGen serializes claims on the bubble text: a nudge only clears the
// text it wrote, and any later writer (another nudge, or the brain via
// pebble.set_state) takes ownership by bumping the counter.
var mutedNudgeGen atomic.Int64

// mutedNudgeDur is how long the "muted" explanation stays in the bubble before
// the state's default copy comes back. A var so tests can shrink it.
var mutedNudgeDur = 2500 * time.Millisecond

// flashMutedPebble is the visible consequence of a mic request turned away by
// mute. Re-asserting the muted state alone is invisible when the pebble is
// already showing it, so the bubble carries the reason for a moment — a
// silently ignored hotkey is indistinguishable from a broken one.
// invalidateMutedNudge takes the bubble text away from any pending muted nudge.
// Callers that set bubble text through some other route must call it, or a
// nudge armed moments earlier will blank their text when it expires.
func invalidateMutedNudge() { mutedNudgeGen.Add(1) }

func flashMutedPebble(p PebbleService) {
	flashPebbleNudge(p, PebbleMuted, "Microphone muted — unmute from the tray menu")
}

// flashPebbleNudge is the general form: assert `state` and hold `text` in the
// bubble for mutedNudgeDur, then hand the bubble back to the state's default
// copy. Used for every "your key press went nowhere, and here is why" moment:
// mute, and a live-voice session the server would not open. Silence there is
// indistinguishable from a broken hotkey, which is precisely how a refused
// realtime dial used to read.
func flashPebbleNudge(p PebbleService, state PebbleState, text string) {
	if p == nil {
		return
	}
	gen := mutedNudgeGen.Add(1)
	_ = p.SetText(text)
	_ = p.SetState(state)
	go func() {
		time.Sleep(mutedNudgeDur)
		// Only the most recent claim clears the text; if anything else has
		// written to the bubble since (invalidateMutedNudge), it owns it now.
		if mutedNudgeGen.Load() == gen {
			_ = p.SetText("") // back to the per-state default copy
		}
	}()
}

// NewPebbleService returns the platform-specific implementation. Defined in
// pebble_overlay_<os>.go.
//
// (declared here so callers in main.go / client.go can construct one without
// per-platform imports; each platform file provides the body.)
