//go:build darwin

package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

// ── Element Cache ──────────────────────────────────────────────────────

// walkDesktopElements is the walk that mints element ids, and the one
// resolveDesktopElement repeats to confirm one (desktop_element_cache.go).
var walkDesktopElements = func(pid, depth int, budget time.Duration) ([]any, error) {
	tree, err := walkDarwinTree(pid, depth, budget)
	if err != nil {
		return nil, err
	}
	if msg, ok := tree["error"].(string); ok && msg != "" {
		return nil, errors.New(msg)
	}
	elems, _ := tree["elements"].([]any)
	return elems, nil
}

// ── list_windows ──────────────────────────────────────────────────────

func handleListWindows(params map[string]any) (*RPCResult, error) {
	script := `
tell application "System Events"
	set windowList to ""
	set fg to name of first process whose frontmost is true
	repeat with proc in (every process whose background only is false)
		set procName to name of proc
		set procPID to unix id of proc
		try
			repeat with w in windows of proc
				set wTitle to name of w
				set wPos to position of w
				set wSize to size of w
				set windowList to windowList & procName & "|||" & procPID & "|||" & wTitle & "|||" & (item 1 of wPos) & "|||" & (item 2 of wPos) & "|||" & (item 1 of wSize) & "|||" & (item 2 of wSize) & "|||" & (procName = fg) & linefeed
			end repeat
		end try
	end repeat
	return windowList
end tell`

	out, err := runOsascript(script, 15*time.Second)
	if err != nil {
		return nil, fmt.Errorf("list_windows failed: %w", err)
	}

	windows := []map[string]any{}
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		parts := strings.Split(line, "|||")
		if len(parts) < 8 {
			continue
		}
		procName := strings.TrimSpace(parts[0])
		pid, _ := strconv.Atoi(strings.TrimSpace(parts[1]))
		title := strings.TrimSpace(parts[2])
		left, _ := strconv.Atoi(strings.TrimSpace(parts[3]))
		top, _ := strconv.Atoi(strings.TrimSpace(parts[4]))
		width, _ := strconv.Atoi(strings.TrimSpace(parts[5]))
		height, _ := strconv.Atoi(strings.TrimSpace(parts[6]))
		isFG := strings.TrimSpace(parts[7]) == "true"

		windows = append(windows, map[string]any{
			"title":         title,
			"pid":           pid,
			"process_name":  procName,
			"left":          left,
			"top":           top,
			"right":         left + width,
			"bottom":        top + height,
			"is_foreground": isFG,
		})
	}

	return &RPCResult{Result: map[string]any{"windows": windows}}, nil
}

// ── get_window_tree ────────────────────────────────────────────────────

// handleGetWindowTree walks the AX tree through JXA. It deliberately does not
// read params["semantic"]: durable refs (sig/path/ordinal) are implemented only
// in the Windows UIA walk, so `semantic: true` is a no-op here and elements come
// back without refs rather than with an error. Documented in
// docs/sidecar/SIDECAR_PROTOCOL.md, "Surface Limits"; the shared sig helpers in
// semantic.go are provider-independent if this walk ever grows them.
func handleGetWindowTree(params map[string]any) (*RPCResult, error) {
	// Every path that does not fill the cache retires it instead, so a failed
	// or empty snapshot leaves no earlier ids live (desktop_element_cache.go,
	// forget). Deferred so a return added later cannot skip it.
	filled := false
	defer func() {
		if !filled {
			elementCache.forget()
		}
	}()

	pid := 0
	if v, ok := params["pid"].(float64); ok {
		pid = int(v)
	}

	// If no PID given, resolve the frontmost process PID via AppleScript
	if pid == 0 {
		pidScript := `tell application "System Events" to unix id of first process whose frontmost is true`
		pidOut, err := runOsascript(pidScript, 5*time.Second)
		if err != nil {
			return nil, fmt.Errorf("get_window_tree: could not determine frontmost PID: %w", err)
		}
		pid, _ = strconv.Atoi(strings.TrimSpace(pidOut))
		if pid == 0 {
			return nil, fmt.Errorf("get_window_tree: frontmost PID resolved to 0")
		}
	}

	depth := 3
	if v, ok := params["depth"].(float64); ok {
		depth = int(v)
	}

	tree, err := walkDarwinTree(pid, depth, jxaWalkTimeout)
	if err != nil {
		return nil, err
	}

	// Cache elements for click/type reference, with the depth that produced
	// them: a read-back at a different depth walks a different tree and its
	// indices do not line up (#661).
	if elems, ok := tree["elements"].([]any); ok {
		elementCache.fill(elems, pid, depth)
		filled = true
	}

	return &RPCResult{Result: tree}, nil
}

// The JXA walk's budgets (jxaWalkTimeout, jxaTypeReadBackTimeout) and the
// read-back policies built from them live in desktop_element_action.go, where
// Linux compiles and tests them too (#712).

// desktopPlatformName names this platform in an unsupported-action refusal.
const desktopPlatformName = "macOS"

// desktopPointerTargetChecked: dispatchPointer does not check the window under
// the pointer (see dispatchPointer), and a click's reply says so.
const desktopPointerTargetChecked = false

// walkDarwinTree runs the JXA accessibility walk for one process. Ids are
// indices in this walk's depth-first order, so the snapshot and the read-back
// in resolveDesktopElement must both come through here with the same depth.
func walkDarwinTree(pid, depth int, timeout time.Duration) (map[string]any, error) {
	// Use JXA (JavaScript for Automation) to walk the accessibility tree
	jsScript := fmt.Sprintf(`
ObjC.import('stdlib')
var se = Application('System Events')
var maxDepth = %d
var procs = se.processes.whose({unixId: %d})
if (procs.length === 0) {
    JSON.stringify({error: 'Process not found', pid: %d})
} else {
var proc = procs[0]
var elements = []
function walk(el, depth) {
    if (depth > maxDepth || elements.length > 200) return
    try {
        var role = el.role()
        var name = ''
        try { name = el.name() || '' } catch(e) {}
        var pos = [0, 0], sz = [0, 0]
        try { pos = el.position(); sz = el.size() } catch(e) {}
        if (sz[0] > 0 && sz[1] > 0) {
            elements.push({
                id: elements.length,
                name: String(name).substring(0, 100),
                control_type: role,
                automation_id: '',
                enabled: el.enabled(),
                focusable: el.focused !== undefined,
                rect: {x: pos[0], y: pos[1], w: sz[0], h: sz[1]}
            })
        }
        var children = el.uiElements()
        for (var i = 0; i < children.length && i < 50; i++) {
            walk(children[i], depth + 1)
        }
    } catch(e) {}
}
var wins = proc.windows()
for (var w = 0; w < wins.length; w++) { walk(wins[w], 0) }
var winTitle = ''
try { winTitle = proc.frontWindow ? proc.frontWindow.name() : (wins.length > 0 ? wins[0].name() : '') } catch(e) {}
JSON.stringify({window_title: winTitle, pid: %d, element_count: elements.length, elements: elements})
}`, depth, pid, pid, pid)

	out, err := runOsascriptJS(jsScript, timeout)
	if err != nil {
		return nil, fmt.Errorf("get_window_tree failed: %w", err)
	}

	var tree map[string]any
	if err := json.Unmarshal([]byte(out), &tree); err != nil {
		return nil, fmt.Errorf("parse tree: %w (%s)", err, truncate(out, 200))
	}
	return tree, nil
}

// ── click_element ────────────────────────────────────────────────────

func handleClickElement(params map[string]any) (*RPCResult, error) {
	return handleClickElementWith(params, darwinClickReadBack)
}

// dispatchPointer performs action at (x, y), for clickElement
// (desktop_element_action.go), which has already confirmed the element and
// the action.
//
// Unlike Linux and Windows it does NOT first check that the window under the
// point is the element's (#705). The check here would be an AX hit test or a
// CGWindowList walk, and macOS draws windows that are listed and on top but
// click-through -- this sidecar's own pebble overlay among them -- so whether
// a given window takes the click is exactly what has to be measured on a real
// Mac before a refusal is trusted. CI has no macOS test runner, and a refusal
// path that has never executed is the failure #712 describes; a check that
// fails closed on every click would be worse than the gap. Filed separately.
func dispatchPointer(id int, action string, x, y, pid int) error {
	_, _ = id, pid
	var err error
	switch action {
	case "double_click":
		err = doubleClickAtCoords(x, y)
	case "right_click":
		err = rightClickAtCoords(x, y)
	default: // click, focus
		err = clickAtCoords(x, y)
	}
	if err != nil {
		return fmt.Errorf("%s failed: %w", action, err)
	}
	return nil
}

// clickAtCoords performs a left-click at the given screen coordinates.
// It tries cliclick first (if available), then falls back to python3 + Quartz.
func clickAtCoords(x, y int) error {
	// Try cliclick first (brew install cliclick)
	if _, err := exec.LookPath("cliclick"); err == nil {
		ctx, cancel := context.WithTimeout(context.Background(), pointerDispatchTimeout)
		defer cancel()
		return exec.CommandContext(ctx, "cliclick", fmt.Sprintf("c:%d,%d", x, y)).Run()
	}

	// Fallback: python3 + Quartz.CoreGraphics (available on macOS with Xcode CLT)
	pyScript := fmt.Sprintf(`
from Quartz.CoreGraphics import *
import time
pt = CGPointMake(%d, %d)
ev = CGEventCreateMouseEvent(None, kCGEventLeftMouseDown, pt, kCGMouseButtonLeft)
CGEventPost(kCGHIDEventTap, ev)
time.sleep(0.05)
ev = CGEventCreateMouseEvent(None, kCGEventLeftMouseUp, pt, kCGMouseButtonLeft)
CGEventPost(kCGHIDEventTap, ev)
`, x, y)

	ctx, cancel := context.WithTimeout(context.Background(), pointerDispatchTimeout)
	defer cancel()
	return exec.CommandContext(ctx, "python3", "-c", pyScript).Run()
}

// ── type_text ────────────────────────────────────────────────────────

func handleTypeText(params map[string]any) (*RPCResult, error) {
	return handleTypeTextWith(params, darwinTypeReadBack, func(text string) error {
		// Pass the text as an argv item rather than interpolating it into the
		// script source. osascript args are real arguments (no shell, no string
		// literal), so newlines/quotes/backslashes in `text` are data and cannot
		// break out of the keystroke statement -- this is what prevents
		// AppleScript injection via attacker/LLM-controlled text.
		script := `on run argv
	tell application "System Events" to keystroke (item 1 of argv)
end run`
		_, err := runOsascriptArgs(script, keystrokeTimeout, text)
		return err
	})
}

// ── press_keys ───────────────────────────────────────────────────────

func handlePressKeys(params map[string]any) (*RPCResult, error) {
	keys, _ := params["keys"].(string)
	if keys == "" {
		return nil, fmt.Errorf("missing required parameter: keys")
	}

	script := convertKeysToOsascript(keys)
	if _, err := runOsascript(script, 5*time.Second); err != nil {
		return nil, fmt.Errorf("press_keys failed: %w", err)
	}

	return &RPCResult{Result: map[string]any{"success": true, "keys": keys}}, nil
}

// ── launch_app ───────────────────────────────────────────────────────

func handleLaunchApp(params map[string]any) (*RPCResult, error) {
	executable, _ := params["executable"].(string)
	if executable == "" {
		return nil, fmt.Errorf("missing required parameter: executable")
	}
	args, err := extractArgs(params)
	if err != nil {
		return nil, fmt.Errorf("launch_app: %w", err)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	// Use "open -a" for .app bundles; fall back to direct exec for plain binaries
	if strings.HasSuffix(executable, ".app") || !strings.Contains(executable, "/") {
		// Looks like an app name or .app bundle — use open -a
		var cmd *exec.Cmd
		if args != "" {
			cmd = exec.CommandContext(ctx, "open", "-a", executable, "--args", args)
		} else {
			cmd = exec.CommandContext(ctx, "open", "-a", executable)
		}

		if err := cmd.Run(); err != nil {
			return nil, fmt.Errorf("launch_app: open -a %q failed: %w", executable, err)
		}

		name := executable
		if strings.HasSuffix(name, ".app") {
			name = name[:len(name)-4]
		}
		if idx := strings.LastIndex(name, "/"); idx >= 0 {
			name = name[idx+1:]
		}

		// Poll for the process AND a visible window instead of a fixed
		// 500ms sleep — returning before the window exists made the next
		// tool call fail ("no window found") or, worse, act on the wrong app.
		pid, probe, probeErr := waitForAppWindowDarwin(name, 0, 5*time.Second)
		if pid == 0 {
			return nil, fmt.Errorf("launch_app: open -a %q succeeded but no running %s.app process appeared within 5s", executable, name)
		}
		return launchResultDarwin(pid, name, probe, probeErr), nil
	}

	// Absolute/relative path to a binary — start detached
	var cmd *exec.Cmd
	if args != "" {
		cmd = exec.CommandContext(ctx, executable, strings.Fields(args)...)
	} else {
		cmd = exec.CommandContext(ctx, executable)
	}

	if err := cmd.Start(); err != nil {
		return nil, fmt.Errorf("launch_app: failed to start %q: %w", executable, err)
	}

	// Detach: don't wait, let the child run independently
	go func() { _ = cmd.Wait() }()

	pid := 0
	if cmd.Process != nil {
		pid = cmd.Process.Pid
	}
	if pid == 0 {
		return nil, fmt.Errorf("launch_app: started %q but could not obtain process ID", executable)
	}

	name := executable
	if idx := strings.LastIndex(executable, "/"); idx >= 0 {
		name = executable[idx+1:]
	}

	_, probe, probeErr := waitForAppWindowDarwin("", pid, 5*time.Second)
	return launchResultDarwin(pid, name, probe, probeErr), nil
}

// countWindowsDarwin asks System Events how many windows pid owns.
//
// A denied automation prompt is not "zero windows", it is no answer at all,
// and the two have to stay distinguishable: the caller reports the first as
// a failed launch and the second as an unverified one.
func countWindowsDarwin(pid int) (int, error) {
	script := fmt.Sprintf(`tell application "System Events" to count windows of (first process whose unix id is %d)`, pid)

	// Bounded on purpose: the first automation attempt can raise a consent
	// dialog, and osascript blocks behind it for as long as the dialog is
	// up. Without a deadline the whole launch_app RPC would hang there.
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "osascript", "-e", script)
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()

	if errors.Is(ctx.Err(), context.DeadlineExceeded) {
		return 0, fmt.Errorf("%w: System Events did not answer in time, which usually means an automation consent dialog is waiting to be answered", errWindowCheckUnavailable)
	}
	if err != nil {
		msg := strings.TrimSpace(stderr.String())
		if isPermissionErrorDarwin(msg) {
			return 0, fmt.Errorf("%w: %s", errWindowCheckUnavailable, firstLine(msg))
		}
		if msg == "" {
			msg = err.Error()
		}
		// Anything else (the process is not registered with System Events
		// yet, most often) may still resolve on a later poll.
		return 0, fmt.Errorf("System Events could not count windows: %s", firstLine(msg))
	}
	n, convErr := strconv.Atoi(strings.TrimSpace(string(out)))
	if convErr != nil {
		return 0, fmt.Errorf("System Events returned a non-numeric window count %q", strings.TrimSpace(string(out)))
	}
	return n, nil
}

// isPermissionErrorDarwin recognises the AppleScript failures that mean the
// sidecar will never be allowed to look, rather than that it looked and saw
// nothing: -1743 (automation not authorized), -25211 (assistive access not
// granted), and -1728 on System Events itself when it is blocked outright.
func isPermissionErrorDarwin(stderr string) bool {
	if stderr == "" {
		return false
	}
	lower := strings.ToLower(stderr)
	for _, marker := range []string{"-1743", "-25211", "not authorized", "not allowed assistive access", "assistive access"} {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	return false
}

// waitForAppWindowDarwin polls until the app has a visible window, up to
// timeout. When pid is 0 it is first resolved from `ps` by app name (see
// appProcessPid). Returns the pid (0 if the process never appeared), what the
// window check established, and the last probe error for the caller's note.
func waitForAppWindowDarwin(name string, pid int, timeout time.Duration) (int, launchProbe, error) {
	deadline := time.Now().Add(timeout)
	var lastErr error
	for {
		if pid == 0 && name != "" {
			// Re-asked on every poll until it answers: `open -a` returns before
			// a cold launch has exec'd the app's main process.
			if out, err := exec.Command("ps", "-axo", "pid=,comm=").Output(); err == nil {
				pid = appProcessPid(string(out), name)
			}
		}
		if pid != 0 {
			n, err := countWindowsDarwin(pid)
			switch {
			case err == nil && n > 0:
				return pid, probeWindowFound, nil
			case errors.Is(err, errWindowCheckUnavailable):
				// Permission will not appear mid-poll; stop rather than
				// spend the whole timeout re-asking the same question.
				return pid, probeUncheckable, err
			case err != nil:
				lastErr = err
			}
		}
		if time.Now().After(deadline) {
			return pid, probeWindowAbsent, lastErr
		}
		time.Sleep(300 * time.Millisecond)
	}
}

// launchResultDarwin builds the launch_app result with an honest
// window_visible flag: success means "the app is on screen", not merely
// "a process was spawned".
//
// The unverified case is kept separate from the failed one. Reporting
// success:false when the automation permission was refused would mark every
// working launch on an unprompted Mac as a failure, and the model would
// launch the app again on the strength of it.
func launchResultDarwin(pid int, name string, probe launchProbe, probeErr error) *RPCResult {
	res := map[string]any{"pid": pid, "name": name}

	switch probe {
	case probeWindowFound:
		res["success"] = true
		res["window_visible"] = true

	case probeUncheckable:
		res["success"] = true
		res["window_visible"] = nil
		res["note"] = fmt.Sprintf("app started (pid %d) but whether a window opened could NOT be checked: %v. This is not a failure report - the app may well be on screen. Run desktop_list_windows to see what is actually open before interacting, and do not launch it again on the strength of this result.", pid, probeErr)

	default: // probeWindowAbsent
		res["success"] = false
		res["window_visible"] = false
		res["note"] = fmt.Sprintf("process started (pid %d) but no window appeared within 5s - the app may still be starting, be windowless, or have exited. Run desktop_list_windows to check before interacting; do NOT assume it is open.", pid)
	}

	return &RPCResult{Result: res}
}

// ── focus_window ─────────────────────────────────────────────────────

func handleFocusWindow(params map[string]any) (*RPCResult, error) {
	pidF, ok := params["pid"].(float64)
	if !ok {
		return nil, fmt.Errorf("missing required parameter: pid")
	}
	pid := int(pidF)

	script := fmt.Sprintf(`
tell application "System Events"
	set proc to first process whose unix id is %d
	set frontmost of proc to true
end tell`, pid)

	_, err := runOsascript(script, 5*time.Second)
	success := err == nil

	return &RPCResult{Result: map[string]any{"success": success, "pid": pid}}, nil
}

// doubleClickAtCoords performs a double-click at screen coordinates.
func doubleClickAtCoords(x, y int) error {
	if _, err := exec.LookPath("cliclick"); err == nil {
		ctx, cancel := context.WithTimeout(context.Background(), pointerDispatchTimeout)
		defer cancel()
		return exec.CommandContext(ctx, "cliclick", fmt.Sprintf("dc:%d,%d", x, y)).Run()
	}
	pyScript := fmt.Sprintf(`
from Quartz.CoreGraphics import *
import time
pt = CGPointMake(%d, %d)
for _ in range(2):
    ev = CGEventCreateMouseEvent(None, kCGEventLeftMouseDown, pt, kCGMouseButtonLeft)
    CGEventSetIntegerValueField(ev, kCGMouseEventClickState, 2)
    CGEventPost(kCGHIDEventTap, ev)
    ev = CGEventCreateMouseEvent(None, kCGEventLeftMouseUp, pt, kCGMouseButtonLeft)
    CGEventSetIntegerValueField(ev, kCGMouseEventClickState, 2)
    CGEventPost(kCGHIDEventTap, ev)
    time.sleep(0.05)
`, x, y)
	ctx, cancel := context.WithTimeout(context.Background(), pointerDispatchTimeout)
	defer cancel()
	return exec.CommandContext(ctx, "python3", "-c", pyScript).Run()
}

// rightClickAtCoords performs a right-click at screen coordinates.
func rightClickAtCoords(x, y int) error {
	if _, err := exec.LookPath("cliclick"); err == nil {
		ctx, cancel := context.WithTimeout(context.Background(), pointerDispatchTimeout)
		defer cancel()
		return exec.CommandContext(ctx, "cliclick", fmt.Sprintf("rc:%d,%d", x, y)).Run()
	}
	pyScript := fmt.Sprintf(`
from Quartz.CoreGraphics import *
import time
pt = CGPointMake(%d, %d)
ev = CGEventCreateMouseEvent(None, kCGEventRightMouseDown, pt, kCGMouseButtonRight)
CGEventPost(kCGHIDEventTap, ev)
time.sleep(0.05)
ev = CGEventCreateMouseEvent(None, kCGEventRightMouseUp, pt, kCGMouseButtonRight)
CGEventPost(kCGHIDEventTap, ev)
`, x, y)
	ctx, cancel := context.WithTimeout(context.Background(), pointerDispatchTimeout)
	defer cancel()
	return exec.CommandContext(ctx, "python3", "-c", pyScript).Run()
}

// ── find_element ─────────────────────────────────────────────────────

func handleFindElement(params map[string]any) (*RPCResult, error) {
	// Walk (which fills the cache and mints this walk's ids), then filter THAT
	// walk's reply -- see findInWalk.
	res, err := handleGetWindowTree(params)
	if err != nil {
		return nil, fmt.Errorf("find_element failed: %w", err)
	}

	name, _ := params["name"].(string)
	controlType, _ := params["control_type"].(string)
	className, _ := params["class_name"].(string)
	// automation_id is ignored on macOS (not an accessibility concept)

	matches := findInWalk(res.Result, name, controlType, className)
	return &RPCResult{Result: map[string]any{
		"match_count": len(matches),
		"elements":    matches,
	}}, nil
}

// ── Helpers ───────────────────────────────────────────────────────────

// runOsascript runs an AppleScript via osascript and returns trimmed stdout.
func runOsascript(script string, timeout time.Duration) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, "osascript", "-e", script)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(out)), nil
}

// runOsascriptArgs runs an AppleScript that reads its inputs from `argv`, passing
// caller-supplied values as process arguments (after `--`) rather than interpolating
// them into the script source. This makes the values data, not code, so they cannot
// inject AppleScript. The script must be an `on run argv ... end run` handler.
func runOsascriptArgs(script string, timeout time.Duration, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmdArgs := append([]string{"-e", script, "--"}, args...)
	cmd := exec.CommandContext(ctx, "osascript", cmdArgs...)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(out)), nil
}

// runOsascriptJS runs a JXA (JavaScript for Automation) script via osascript -l JavaScript.
func runOsascriptJS(script string, timeout time.Duration) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, "osascript", "-l", "JavaScript", "-e", script)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(out)), nil
}

// convertKeysToOsascript converts a comma-separated key spec like "cmd,s" or
// "ctrl,shift,a" into a complete AppleScript tell-block for System Events.
//
// Modifier names: ctrl/control, alt/option, shift, cmd/command/super/win
// Special key names map to AppleScript key codes.
func convertKeysToOsascript(keys string) string {
	parts := strings.Split(strings.ToLower(strings.TrimSpace(keys)), ",")
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}

	var modifiers []string
	var keyParts []string

	for _, part := range parts {
		switch part {
		case "ctrl", "control":
			modifiers = append(modifiers, "control down")
		case "alt", "option":
			modifiers = append(modifiers, "option down")
		case "shift":
			modifiers = append(modifiers, "shift down")
		case "cmd", "command", "super", "win":
			modifiers = append(modifiers, "command down")
		default:
			keyParts = append(keyParts, part)
		}
	}

	usingClause := ""
	if len(modifiers) > 0 {
		usingClause = fmt.Sprintf(" using {%s}", strings.Join(modifiers, ", "))
	}

	if len(keyParts) == 0 {
		// No key, just modifiers — nothing meaningful to send
		return `tell application "System Events" to keystroke ""`
	}

	key := keyParts[0]

	// Check for special keys that require key code
	if keyCode, isSpecial := osascriptKeyCode(key); isSpecial {
		return fmt.Sprintf(`tell application "System Events" to key code %d%s`, keyCode, usingClause)
	}

	// Single printable character — use keystroke
	escaped := strings.ReplaceAll(key, "\\", "\\\\")
	escaped = strings.ReplaceAll(escaped, `"`, `\"`)
	return fmt.Sprintf(`tell application "System Events" to keystroke "%s"%s`, escaped, usingClause)
}

// osascriptKeyCode maps special key names to AppleScript key codes.
// Returns (keyCode, true) for known special keys, (0, false) otherwise.
func osascriptKeyCode(key string) (int, bool) {
	keyCodes := map[string]int{
		"enter":     36,
		"return":    36,
		"tab":       48,
		"escape":    53,
		"esc":       53,
		"delete":    51,
		"backspace": 51,
		"space":     49,
		"up":        126,
		"down":      125,
		"left":      123,
		"right":     124,
		"home":      115,
		"end":       119,
		"pageup":    116,
		"pgup":      116,
		"pagedown":  121,
		"pgdn":      121,
		"f1":        122,
		"f2":        120,
		"f3":        99,
		"f4":        118,
		"f5":        96,
		"f6":        97,
		"f7":        98,
		"f8":        100,
		"f9":        101,
		"f10":       109,
		"f11":       103,
		"f12":       111,
	}
	if code, ok := keyCodes[strings.ToLower(key)]; ok {
		return code, true
	}
	return 0, false
}

// toInt converts common JSON number types to int.
func toInt(v any) int {
	switch n := v.(type) {
	case float64:
		return int(n)
	case int:
		return n
	case string:
		i, _ := strconv.Atoi(n)
		return i
	}
	return 0
}
