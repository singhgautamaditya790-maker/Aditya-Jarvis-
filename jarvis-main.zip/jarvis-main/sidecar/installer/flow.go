package main

// The install/update flow shared by console/silent mode and the GUI wizard.
// Every failure maps to one of the frozen exit codes in main.go.

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"github.com/jarvis/sidecar/internal/update"
)

// minSetupSidecarVersion is the first sidecar release whose flag.Parse knows
// --setup. Older sidecars hard-exit on unknown flags with a dead stderr under
// -H windowsgui, so the handoff is version-gated.
const minSetupSidecarVersion = "0.9.1"

func logf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, format+"\n", args...)
}

// installedSidecar is what detection found on this machine.
type installedSidecar struct {
	Version    string // "" when absent
	InstallDir string // "" when absent
	// PackageManager is "bun" or "npm" when a global install of the package
	// owns the sidecar here, "" otherwise. Which one matters: they keep
	// separate global trees, so only the owner's commands reach it.
	PackageManager string
}

// progressFn receives coarse stage updates ("download", "verify", "install")
// with a human-readable detail line. Never called concurrently.
type progressFn func(stage, detail string)

// installOutcome is performInstall's result: Code is a main.go exit code,
// Err the terminal failure (nil on success), and the flags say which of the
// no-op success paths was taken.
type installOutcome struct {
	Code       int
	Err        error
	Rel        *pkgRelease
	Inst       installedSidecar
	InstallDir string
	UpToDate   bool
	NpmManaged bool
}

// performInstall runs resolve → detect → download → verify → stop → swap →
// register. It never launches the sidecar — callers own that (console mode
// respects --no-launch; the wizard launches from its Done page).
func performInstall(registryURL string, silent bool, progress progressFn) installOutcome {
	fail := func(code int, err error) installOutcome {
		return installOutcome{Code: code, Err: err}
	}

	progress("resolve", "Checking the latest sidecar version…")
	rel, err := fetchLatestRelease(registryURL)
	if err != nil {
		return fail(exitNetwork, fmt.Errorf("could not resolve the latest sidecar: %w", err))
	}

	inst, err := detectInstalled()
	if err != nil {
		return fail(exitOther, fmt.Errorf("could not inspect the existing installation: %w", err))
	}
	out := installOutcome{Code: exitOK, Rel: rel, Inst: inst}
	switch {
	case inst.PackageManager != "":
		out.NpmManaged = true
		return out
	case inst.Version != "" && !versionLess(inst.Version, rel.Version):
		out.UpToDate = true
		out.InstallDir = inst.InstallDir
		return out
	}

	workDir, err := os.MkdirTemp("", "jarvis-installer-*")
	if err != nil {
		return fail(exitFilesystem, fmt.Errorf("could not create a work directory: %w", err))
	}
	defer os.RemoveAll(workDir)

	// No version in the detail line: it is what the wizard's stage row shows,
	// and that row is not the place for a number the user did not pick. The
	// console path still names the resolved version on its final line.
	progress("download", "Downloading the latest sidecar…")
	tgz, err := update.Download(rel, workDir)
	if err != nil {
		return fail(exitNetwork, err)
	}

	progress("verify", "Verifying the payload (sha512 + code signature)…")
	staged := filepath.Join(workDir, "staged")
	if err := update.Extract(tgz, staged); err != nil {
		// Guard violations mean the payload is untrustworthy (3); local I/O
		// failures (disk full, permissions) are filesystem errors (5). The
		// exit codes are a frozen contract, so don't conflate them.
		var rej update.PayloadRejectedError
		if errors.As(err, &rej) {
			return fail(exitVerification, fmt.Errorf("payload rejected: %w", err))
		}
		return fail(exitFilesystem, fmt.Errorf("could not unpack the payload: %w", err))
	}
	stagedBin := filepath.Join(staged, "bin")
	// Layout before signature: a package that predates the current layout would
	// otherwise surface as "code-signature verification failed", sending the
	// reader after a signing problem that does not exist.
	if err := update.CheckPayloadLayout(stagedBin, rel.Version); err != nil {
		return fail(exitVerification, err)
	}
	if err := update.VerifyPayloadSignature(stagedBin); err != nil {
		return fail(exitVerification, fmt.Errorf("code-signature verification failed (refusing to install an unverified sidecar): %w", err))
	}

	progress("install", "Stopping the running sidecar…")
	if err := stopRunningSidecar(inst, silent); err != nil {
		return fail(exitStopFailed, fmt.Errorf("could not stop the running sidecar: %w", err))
	}

	installDir := inst.InstallDir
	if installDir == "" {
		if installDir, err = installDirDefault(); err != nil {
			return fail(exitFilesystem, fmt.Errorf("no writable install location: %w", err))
		}
	}
	progress("install", fmt.Sprintf("Installing to %s…", installDir))
	if err := update.Swap(stagedBin, installDir); err != nil {
		return fail(exitFilesystem, fmt.Errorf("install failed: %w", err))
	}
	// The running sidecar was stopped above, so nothing needs the previous
	// copy for a rollback.
	if err := update.CleanupOld(installDir); err != nil {
		logf("warning: could not remove the previous copy: %v", err)
	}
	out.InstallDir = installDir

	if got, err := update.InstalledBinaryVersion(installDir); err != nil {
		logf("warning: post-install version check failed: %v", err)
	} else if got != rel.Version {
		logf("warning: installed binary reports %q, expected %q", got, rel.Version)
	}

	// System registration (uninstall entry, Start Menu, uninstaller copy) —
	// real on Windows, no-op elsewhere.
	if err := registerInstall(installDir, rel.Version); err != nil {
		logf("warning: system registration incomplete: %v", err)
	}
	return out
}

// runInstall is the console/silent entrypoint.
func runInstall(registryURL string, silent, noLaunch, autostartOn bool) int {
	out := performInstall(registryURL, silent, func(_, detail string) { logf("%s", detail) })
	switch {
	case out.Err != nil:
		logf("%v", out.Err)
		if out.Code == exitNetwork {
			logf("(the npm registry is the only payload source — check the network and retry)")
		}
		return out.Code
	case out.NpmManaged:
		pm := out.Inst.PackageManager
		logf("this machine's sidecar is managed by %s; update it with: %s update -g @usejarvis/sidecar", pm, pm)
		return exitOK
	case out.UpToDate:
		logf("installed sidecar %s is already current", out.Inst.Version)
		return exitOK
	}
	logf("installed sidecar %s to %s", out.Rel.Version, out.InstallDir)
	if shouldApplyAutostart(out) {
		if err := applyAutostart(out.InstallDir, autostartOn); err != nil {
			logf("warning: autostart registration failed: %v", err)
		}
	}
	if !noLaunch {
		firstInstall := out.Inst.Version == ""
		if err := launchInstalled(out.InstallDir, out.Rel.Version, firstInstall); err != nil {
			logf("warning: could not launch the sidecar: %v", err)
		}
	}
	return exitOK
}

// shouldApplyAutostart reports whether this run may touch the login-item
// registration. FIRST INSTALL ONLY: the sidecar never clears its Run value
// when the preference is off, so re-applying on an update would silently
// resurrect a login item the user had disabled. No-op outcomes (npm-managed,
// already current) installed nothing and must not touch it either.
func shouldApplyAutostart(out installOutcome) bool {
	return !out.NpmManaged && !out.UpToDate && out.Inst.Version == ""
}

// setupHandoffAllowed gates passing --setup to the installed sidecar: older
// releases die on unknown flags.
func setupHandoffAllowed(version string) bool {
	return !versionLess(version, minSetupSidecarVersion)
}
