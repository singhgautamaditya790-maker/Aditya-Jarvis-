#!/usr/bin/env bash
# Tests for the release tag gate in .github/workflows/release-exec.yml (#644).
# Needs bash and bun (for Bun.YAML); no network, no Docker, no GitHub.
#
# The validator is a `run:` block inside the workflow, not a script file, on
# purpose: its job holds `permissions: {}` and checks nothing out, so there is
# no file to call. This test therefore pulls that block out of the YAML and
# executes it VERBATIM against each fixture, with the env the runner would give
# it. A copy of the regex kept here would pass forever while the workflow
# drifted.
#
# Three parts:
#   1. the validator: accept/reject for each tag, what reaches $GITHUB_OUTPUT,
#      that a hostile tag is never evaluated (a sentinel file stays absent),
#      that a real run must be building the tag it publishes, and that a UTF-8
#      locale does not widen the alphabet;
#   2. the structure that makes the validator the ONLY control that matters:
#      no `run:` contains a `${{ }}` expression; the raw tag (by expression, by
#      bracket syntax, or through $GITHUB_REF/$GITHUB_REF_NAME) is read nowhere
#      but the validator's env; the gate's outputs forward exactly what the
#      validator wrote; every output a job reads exists; every job that reads
#      one lists validate-tag in `needs:` (the needs context holds direct
#      dependencies only, so a missing entry silently yields ""); no consumer
#      runs after a failed gate; and every job sits downstream of it;
#   3. the structure check run against mutated copies of the workflow, one hole
#      per copy, each of which must be reported -- so a structure check that
#      has been neutered fails here instead of passing everything.
#   Plus (#685) the dry-run decision in release-exec.yml and
#   sidecar-release.yml: each site that makes it is evaluated under a tag
#   push, a real dispatch and a dry dispatch, and they must agree.
#   Plus (#781, #779) the artifact handoffs into the jobs that sign and
#   publish: sidecar-release.yml publish-sidecar, and installer-release.yml
#   sign-windows and publish. Each check is executed verbatim against
#   tampered, extra, missing and undigested fixtures.
#   Plus (#680) the image path: one build in build-image (a real push by
#   digest and a dry-run twin into an OCI archive that differ only in
#   outputs), smoke-image running exactly that digest with no write scope,
#   publish-docker tagging it with no rebuild after the approval chain, and
#   only those two jobs holding packages: write. Its three scripts (the
#   pull, the archive load and the tag step) are executed verbatim against
#   a docker stub, with tampered, wrong and missing inputs.
#   Plus (#817) post-sign verification in a job without id-token, on the
#   digest that ships, gating the publish.
#   Plus (#684, #818) the version gates of sidecar-release.yml and
#   installer-release.yml, executed verbatim against hostile VERSION files,
#   and no ${{ }} inside any run: of either workflow.
#   Plus one sink executed directly -- pack-brain's `npm version` -- with a
#   hostile value and no validator in front of it, to show the env-quoted form
#   is safe on its own and not just because the gate stopped the input.
#
# Run from anywhere:  .github/scripts/release-exec.test.sh
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKFLOW="${RELEASE_EXEC_WORKFLOW:-${HERE}/../workflows/release-exec.yml}"

pass=0
fail=0
ok() {
	pass=$((pass + 1))
	echo "  ok   - $1"
}
no() {
	fail=$((fail + 1))
	echo "  FAIL - $1"
	[ -n "${2:-}" ] && printf '%s\n' "$2" | sed 's/^/         /'
}

WORK="$(mktemp -d)" || exit 1
trap 'rm -rf "$WORK"' EXIT

command -v bun >/dev/null || {
	echo "bun is required (Bun.YAML)" >&2
	exit 1
}

# yq <mode> [args]: read a workflow (default $WORKFLOW, or $YQ_FILE) with Bun's
# YAML parser.
yq() {
	# shellcheck disable=SC2016 # JavaScript source, not shell: nothing should expand.
	WORKFLOW="${YQ_FILE:-$WORKFLOW}" bun -e '
const mode = process.argv[1];
const doc = Bun.YAML.parse(await Bun.file(process.env.WORKFLOW).text());
const jobs = doc.jobs ?? {};
const needsOf = (j) => [jobs[j]?.needs ?? []].flat();
const findStep = (job, pred) => (jobs[job]?.steps ?? []).find(pred);
if (mode === "validator" || mode === "step") {
  const step = mode === "validator"
    ? findStep("validate-tag", (s) => s.id === "validate")
    : findStep(process.argv[2], (s) => s.name === process.argv[3] || s.id === process.argv[3]);
  if (!step || typeof step.run !== "string") process.exit(3);
  process.stdout.write(step.run);
  process.exit(0);
}
if (mode === "run-expressions") {
  // #684: the same rule as the structure check below, for any workflow:
  // no `run:` (or github-script `script:`) contains a ${{ }} expression.
  const found = [];
  for (const [name, job] of Object.entries(jobs))
    for (const [i, s] of (job.steps ?? []).entries()) {
      const label = name + ": step " + (s.name ?? s.id ?? s.uses ?? String(i));
      if (typeof s.run === "string" && s.run.includes("${{")) found.push(label + " has a ${{ }} expression inside run:");
      if (typeof s.with?.script === "string" && s.with.script.includes("${{")) found.push(label + " has a ${{ }} expression inside a script: input");
    }
  if (found.length) console.log(found.join("\n"));
  process.exit(0);
}
if (mode === "dry-run") {
  // #685: one dry-run decision. Every place that must make it (DRY_RUN, and
  // where `env` is not available: the sidecar call input, discord-notify,
  // the environment names) spells it `inputs.dry_run == true`, each is
  // EVALUATED under every way the workflow starts, and they must agree. No
  // other expression reads dry_run, nothing redefines DRY_RUN, and every
  // consumer compares DRY_RUN with true and nothing else (a bare
  // `if: env.DRY_RUN` is the string "false", which is truthy).
  const out = [];
  const file = require("node:path").basename(process.env.WORKFLOW);
  const ENV_NAME = "${{ inputs.dry_run == true && \x27release-dry-run\x27 || \x27release\x27 }}";
  const FLAG = "${{ inputs.dry_run == true }}";
  // [description, getter, canonical text, kind]
  const sites = [["env.DRY_RUN", (d) => d.env?.DRY_RUN, FLAG, "env"]];
  if (file === "release-exec.yml") sites.push(
    ["jobs.sidecar.with.dry_run", (d) => d.jobs?.sidecar?.with?.dry_run, FLAG, "flag"],
    ["jobs.discord-notify.if", (d) => d.jobs?.["discord-notify"]?.if, "${{ inputs.dry_run != true }}", "notify"],
    ["jobs.publish-brain.environment.name", (d) => d.jobs?.["publish-brain"]?.environment?.name, ENV_NAME, "environment"]);
  else if (file === "sidecar-release.yml") sites.push(
    ["jobs.publish-sidecar.environment.name", (d) => d.jobs?.["publish-sidecar"]?.environment?.name, ENV_NAME, "environment"]);
  else out.push("no dry-run sites are known for " + file);
  // A small evaluator for the GitHub expression subset these use: literals,
  // inputs.dry_run, ! == != && || and parentheses, with GitHub loose
  // equality (different types compare as numbers, so null == false is true)
  // and its truthiness. Anything else is reported, never guessed at.
  const evaluate = (src, value) => {
    const m = /^\$\{\{([\s\S]*)\}\}$/.exec(String(src).trim());
    if (!m) throw new Error("not a single ${{ }} expression");
    const toks = m[1].match(/\s+|\x27(?:[^\x27]|\x27\x27)*\x27|&&|\|\||==|!=|!|\(|\)|[A-Za-z_][\w.-]*|\S/g).filter((t) => !/^\s+$/.test(t));
    let i = 0;
    const peek = () => toks[i];
    const num = (v) => v === null ? 0 : typeof v === "boolean" ? Number(v) : typeof v === "string" ? (v.trim() === "" ? 0 : Number(v)) : v;
    const eq = (a, b) => typeof a === typeof b && a !== null && b !== null
      ? (typeof a === "string" ? a.toLowerCase() === b.toLowerCase() : a === b)
      : (a === null && b === null) || num(a) === num(b);
    const truthy = (v) => !(v === false || v === null || v === "" || v === 0 || Number.isNaN(v));
    const primary = () => {
      const t = toks[i++];
      if (t === "(") { const v = or(); if (toks[i++] !== ")") throw new Error("unbalanced parentheses"); return v; }
      if (t === "true") return true;
      if (t === "false") return false;
      if (t === "null") return null;
      if (/^\x27/.test(t ?? "")) return t.slice(1, -1).replace(/\x27\x27/g, "\x27");
      if (/^inputs\.dry_run$/i.test(t ?? "")) return value;
      throw new Error("cannot evaluate " + JSON.stringify(t));
    };
    // GitHub precedence: ! binds tighter than == and !=, which bind tighter
    // than &&, then ||. So !a == b is (!a) == b.
    const not = () => { if (peek() === "!") { i++; return !truthy(not()); } return primary(); };
    const cmp = () => {
      const a = not();
      if (peek() === "==" || peek() === "!=") { const op = toks[i++]; const b = not(); return op === "==" ? eq(a, b) : !eq(a, b); }
      return a;
    };
    const and = () => { let v = cmp(); while (peek() === "&&") { i++; const r = cmp(); v = truthy(v) ? r : v; } return v; };
    const or = () => { let v = and(); while (peek() === "||") { i++; const r = and(); v = truthy(v) ? v : r; } return v; };
    const v = or();
    if (i !== toks.length) throw new Error("trailing " + JSON.stringify(toks.slice(i).join(" ")));
    return { v, truthy };
  };
  // EVAL_EXPR set: evaluate it for EVAL_VALUE (JSON) and print the result,
  // so the evaluator itself can be checked against known GitHub answers.
  if (process.env.EVAL_EXPR !== undefined) {
    try { console.log(JSON.stringify(evaluate(process.env.EVAL_EXPR, JSON.parse(process.env.EVAL_VALUE)).v)); }
    catch (e) { console.log("error: " + e.message); }
    process.exit(0);
  }
  // A tag push has no inputs; a dispatch or a workflow_call passes a boolean.
  const starts = [["a tag push", null, false], ["a real dispatch", false, false], ["a dry-run dispatch", true, true]];
  for (const [what, get, canon, kind] of sites) {
    const src = get(doc);
    if (src === undefined) { out.push(what + " is missing"); continue; }
    if (src !== canon) out.push(what + " is " + JSON.stringify(src) + ", not the one spelling " + JSON.stringify(canon));
    for (const [how, value, dry] of starts) {
      let r;
      try { r = evaluate(src, value); } catch (e) { out.push(what + ": " + e.message); break; }
      const { v, truthy } = r;
      // An env value is the expression result as a string; null becomes "".
      const ok = kind === "env" ? (v === null ? "" : String(v)) === String(dry)
        : kind === "flag" ? v === dry
        : kind === "notify" ? truthy(v) === !dry
        : v === (dry ? "release-dry-run" : "release");
      if (!ok) out.push(what + " disagrees on " + how + " (dry run " + dry + "): it gives " + JSON.stringify(v));
    }
  }
  // Every other reading of the input is a second decision.
  const known = new Set(sites.map(([what]) => what));
  const walk = (o, path) => {
    if (typeof o === "string") {
      // An `if:` is an expression with or without the ${{ }} around it.
      const exprs = /\.if$/.test(path) && !o.includes("${{") ? [o] : o.match(/\$\{\{[\s\S]*?\}\}/g) ?? [];
      // The input, by dot or bracket (contexts are case-insensitive, and
      // github.event.inputs.dry_run contains inputs.dry_run), or the whole
      // inputs context serialised. env.DRY_RUN is the consumer, checked below.
      const readsInput = /\binputs\s*(?:\.\s*dry_run\b|\[\s*["\x27]?dry_run\b)|\btoJSON\s*\(\s*inputs\s*\)/i;
      for (const e of exprs)
        if (readsInput.test(e) && !known.has(path)) out.push(path + " reads dry_run on its own: " + e);
      return;
    }
    if (o && typeof o === "object") for (const [k, v] of Object.entries(o)) walk(v, path + "." + k);
  };
  walk(doc.jobs ?? {}, "jobs");
  walk(doc.concurrency ?? {}, "concurrency");
  for (const [k, v] of Object.entries(doc.env ?? {})) if (k !== "DRY_RUN") walk(v, "env." + k);
  const consumerIf = /^(?:\$\{\{\s*)?env\.DRY_RUN\s*(?:==|!=)\s*\x27true\x27(?:\s*\}\})?$/;
  const consumerRun = /"\$\{?DRY_RUN\}?"\s*!?=\s*"true"/g;
  for (const [name, job] of Object.entries(doc.jobs ?? {})) {
    if (job.env && "DRY_RUN" in job.env) out.push(name + ": redefines DRY_RUN");
    for (const [i, s] of (job.steps ?? []).entries()) {
      const label = name + ": step " + (s.name ?? s.id ?? s.uses ?? String(i));
      if (s.env && "DRY_RUN" in s.env) out.push(label + " redefines DRY_RUN");
      if (/DRY_RUN/.test(String(s.if ?? "")) && !consumerIf.test(String(s.if).trim()))
        out.push(label + " tests DRY_RUN as " + JSON.stringify(s.if) + ", not env.DRY_RUN == or != \x27true\x27");
      if (typeof s.run === "string" && /DRY_RUN/.test(s.run.replace(consumerRun, "")))
        out.push(label + " reads DRY_RUN other than as \"$DRY_RUN\" = or != \"true\"");
    }
  }
  if (out.length) console.log(out.join("\n"));
  process.exit(0);
}
if (mode === "sidecar-digests") {
  // #781: every sidecar-* artifact publish-sidecar publishes crosses with a
  // digest carried as a job output, and is checked against it first.
  const out = [];
  const isUpload = (st) => String(st.uses ?? "").toLowerCase().startsWith("actions/upload-artifact@");
  // Legs of a job: 1 with no matrix, or with a matrix that is exactly one
  // include entry and no axis. Any axis multiplies the legs (and include can
  // add more), so anything else counts as many: they would share one
  // outputs block.
  const legsOf = (j) => {
    const m = jobs[j]?.strategy?.matrix;
    if (m === undefined) return 1;
    if (!m || typeof m !== "object") return Infinity;
    const keys = Object.keys(m);
    return keys.length === 1 && keys[0] === "include" && Array.isArray(m.include) ? m.include.length : Infinity;
  };
  // The digest is taken of the finished file: after it, the job only uploads.
  const digestLast = (name) => {
    const steps = jobs[name]?.steps ?? [];
    const at = steps.findIndex((st) => st.id === "digest");
    if (at < 0) { out.push(name + ": no step with id digest"); return; }
    if (!steps.slice(at + 1).length || !steps.slice(at + 1).every(isUpload))
      out.push(name + ": steps other than uploads run after the digest is taken, so it may not describe what is uploaded");
    if (!steps.slice(at + 1).some((st) => /^sidecar-/.test(String(st.with?.name ?? ""))))
      out.push(name + ": does not upload a sidecar-* artifact after the digest");
    if (steps[at]["continue-on-error"] !== undefined) out.push(name + ": the digest step has continue-on-error");
    if (jobs[name]?.outputs?.sha256 !== "${{ steps.digest.outputs.sha256 }}")
      out.push(name + ": output sha256 must be ${{ steps.digest.outputs.sha256 }} (got " + JSON.stringify(jobs[name]?.outputs?.sha256) + ")");
  };
  // A matrix shares ONE outputs block across its legs, so any leg can write
  // a name another leg owns. Whatever uploads a sidecar-* artifact is
  // therefore a job with at most one leg, and so the only writer of its own
  // digest.
  for (const [name, job] of Object.entries(jobs))
    if ((job.steps ?? []).some((st) => isUpload(st) && /^sidecar-/.test(String(st.with?.name ?? ""))) && legsOf(name) > 1)
      out.push(name + ": uploads a sidecar-* artifact from a matrix of " + legsOf(name) + " legs, any of which can set the digest output");
  // Each leg job: one leg, the npm package its name says.
  const expectEnv = {};
  for (const leg of ["linux-x64", "linux-arm64", "darwin-arm64", "darwin-x64"]) {
    const j = "build-sidecar-" + leg;
    if (!jobs[j]) { out.push("no " + j + " job"); continue; }
    const inc = jobs[j].strategy?.matrix?.include ?? [];
    if (legsOf(j) !== 1 || inc[0]?.npm_pkg !== leg) out.push(j + ": must build exactly the " + leg + " leg (got " + JSON.stringify(inc.map((l) => l.npm_pkg)) + ")");
    digestLast(j);
    expectEnv[leg] = "needs." + j + ".outputs.sha256";
  }
  digestLast("sign-sidecar-windows");
  expectEnv["win32-x64"] = "needs.sign-sidecar-windows.outputs.sha256";
  const pub = jobs["publish-sidecar"];
  if (!pub) out.push("no publish-sidecar job");
  else {
    for (const ref of Object.values(expectEnv)) {
      const n = ref.split(".")[1];
      if (!needsOf("publish-sidecar").includes(n)) out.push("publish-sidecar: does not list " + n + " in needs, so its outputs read as empty");
    }
    const steps = pub.steps ?? [];
    const dl = steps.findIndex((st) => String(st.uses ?? "").toLowerCase().startsWith("actions/download-artifact@"));
    const v = steps[dl + 1];
    if (dl < 0) out.push("publish-sidecar: no artifact download");
    else if (!v || typeof v.run !== "string" || !/\bsha256sum\s+--strict\s+-c\b/.test(v.run))
      out.push("publish-sidecar: the step right after the download is not a sha256sum --strict -c of the artifacts");
    else {
      if (v.if !== undefined) out.push("publish-sidecar: the artifact check has an if:, so it can be switched off on its own");
      for (const st of [steps[dl], v])
        if (st["continue-on-error"] !== undefined) out.push("publish-sidecar: continue-on-error on " + (st.name ?? st.uses) + ", so a failed check would not stop the publish");
      // By name, so two legs cannot be crossed over: the script binds each
      // SHA_<LEG> to that leg file, which the fixtures below exercise.
      for (const [leg, ref] of Object.entries(expectEnv)) {
        const k = "SHA_" + leg.toUpperCase().replace(/-/g, "_");
        if (v.env?.[k] !== "${{ " + ref + " }}")
          out.push("publish-sidecar: the artifact check must take " + k + " from ${{ " + ref + " }} (got " + JSON.stringify(v.env?.[k]) + ")");
      }
    }
  }
  if (out.length) console.log(out.join("\n"));
  process.exit(0);
}
if (mode === "installer-digests") {
  // #779: the installer crosses build-windows -> sign-windows -> publish, and
  // build-macos -> publish, each by a digest that is a job output of the job
  // that produced the bytes, checked in the step right after the download.
  const out = [];
  const isUpload = (st) => String(st.uses ?? "").toLowerCase().startsWith("actions/upload-artifact@");
  const isDownload = (st) => String(st.uses ?? "").toLowerCase().startsWith("actions/download-artifact@");
  for (const name of ["build-windows", "sign-windows", "build-macos"]) {
    const job = jobs[name];
    if (!job) { out.push("no " + name + " job"); continue; }
    // None of the three needs a matrix; with one, its legs would share one
    // outputs block and any leg could set the digest (#779 re-review).
    if (job.strategy?.matrix !== undefined)
      out.push(name + ": has a matrix, whose legs would share one outputs block");
    const dg = (job.steps ?? []).find((st) => st.id === "digest");
    if (dg && dg["continue-on-error"] !== undefined) out.push(name + ": the digest step has continue-on-error");
    if (job.outputs?.sha256 !== "${{ steps.digest.outputs.sha256 }}")
      out.push(name + ": output sha256 must be ${{ steps.digest.outputs.sha256 }} (got " + JSON.stringify(job.outputs?.sha256) + ")");
    const steps = job.steps ?? [];
    const at = steps.findIndex((st) => st.id === "digest");
    if (at < 0) out.push(name + ": no step with id digest");
    else if (!steps.slice(at + 1).length || !steps.slice(at + 1).every(isUpload))
      out.push(name + ": steps other than uploads run after the digest is taken");
  }
  // check <job> <env var> <expected needs reference>: the step after the
  // job download reads that digest, under no condition of its own.
  const check = (job, want) => {
    const steps = jobs[job]?.steps ?? [];
    const dl = steps.findIndex(isDownload);
    const v = steps[dl + 1];
    if (dl < 0 || !v || typeof v.run !== "string" || !/\bsha256sum\b[^\n]*\s-c\b/.test(v.run)) {
      out.push(job + ": the step right after its download is not a sha256sum -c");
      return;
    }
    if (v.if !== undefined || v["continue-on-error"] !== undefined || steps[dl]["continue-on-error"] !== undefined)
      out.push(job + ": its digest check can be skipped or allowed to fail");
    for (const [k, ref] of Object.entries(want)) {
      if (v.env?.[k] !== "${{ " + ref + " }}") out.push(job + ": the check must take " + k + " from ${{ " + ref + " }} (got " + JSON.stringify(v.env?.[k]) + ")");
      const n = ref.split(".")[1];
      if (!needsOf(job).includes(n)) out.push(job + ": does not list " + n + " in needs, so its outputs read as empty");
    }
  };
  check("sign-windows", { SHA256: "needs.build-windows.outputs.sha256" });
  // The SIGNED installer: its digest comes from the signer, not the build.
  check("publish", { SHA_WIN32_X64: "needs.sign-windows.outputs.sha256", SHA_DARWIN: "needs.build-macos.outputs.sha256" });
  if (out.length) console.log(out.join("\n"));
  process.exit(0);
}
if (mode === "image") {
  // #680: the image is built once, smoke-tested by digest, and tagged from
  // that digest with no rebuild; the dry run is the same build into an
  // archive; and only the job after the approval chain creates a tag.
  const out = [];
  const lc = (st) => String(st.uses ?? "").toLowerCase();
  const isBuild = (st) => /^docker\/(build-push-action|bake-action)@/.test(lc(st));
  const code = (st) => typeof st.run === "string" ? st.run.split("\n").filter((l) => !/^\s*#/.test(l)).join("\n") : "";
  const stepsOf = (j) => jobs[j]?.steps ?? [];
  const writes = (perm) => perm === "write-all" || (perm && typeof perm === "object" && Object.values(perm).some((x) => x === "write"));
  const permOf = (j) => jobs[j]?.permissions ?? doc.permissions;
  const upstream = (j, target, seen = new Set()) => {
    if (j === target) return true;
    if (seen.has(j)) return false;
    seen.add(j);
    return needsOf(j).some((n) => upstream(n, target, seen));
  };
  // Who builds, who writes to a registry, who holds packages: write.
  const buildCmd = /\bdocker\s+(?:image\s+)?build\b|\bbuildx\s+(?:build|bake)\b|\bdocker\s+(?:image\s+)?(?:commit|import)\b/;
  const registryWrite = /\bdocker\s+(?:image\s+)?push\b|\bimagetools\s+create\b|\b(?:skopeo|crane|regctl|oras)\s+(?:copy|cp|push|tag|image\s+copy|index\s+create)\b|--push\b/;
  for (const [name, job] of Object.entries(jobs)) {
    const steps = job.steps ?? [];
    if (name !== "build-image" && (steps.some(isBuild) || steps.some((st) => buildCmd.test(code(st)))))
      out.push(name + ": builds an image; only build-image may, so the image that ships is built once");
    if (name !== "publish-docker" && steps.some((st) => registryWrite.test(code(st))))
      out.push(name + ": writes to a registry from a run: step; only publish-docker tags, and build-image pushes through its build step alone");
    const p = permOf(name);
    if ((p === "write-all" || p?.packages === "write") && name !== "build-image" && name !== "publish-docker")
      out.push(name + ": holds packages: write; only build-image (untagged push) and publish-docker (tags) may");
  }
  // build-image: the one build, twice spelled, cold, attested.
  const bi = stepsOf("build-image");
  const b = bi.find((st) => st.id === "build");
  const d = bi.find((st) => st.id === "build-dry");
  const REAL_OUT = "type=image,name=ghcr.io/${{ github.repository }},push-by-digest=true,name-canonical=true,push=true";
  const DRY_OUT = "type=oci,dest=${{ runner.temp }}/release-image.oci.tar";
  if (!jobs["build-image"]) out.push("no build-image job");
  else if (!b || !d || !isBuild(b) || !isBuild(d)) out.push("build-image: needs a build step with id build and one with id build-dry");
  else {
    if (bi.filter(isBuild).length !== 2) out.push("build-image: has " + bi.filter(isBuild).length + " build steps, not exactly the real one and its dry-run twin");
    if (b.if !== "env.DRY_RUN != \x27true\x27" || d.if !== "env.DRY_RUN == \x27true\x27")
      out.push("build-image: the two builds must run under env.DRY_RUN != and == \x27true\x27 (got " + JSON.stringify([b.if, d.if]) + ")");
    if (b.uses !== d.uses) out.push("build-image: the two builds use different actions");
    const rest = (st) => JSON.stringify(Object.fromEntries(Object.entries(st.with ?? {}).filter(([k]) => k !== "outputs").sort()));
    if (rest(b) !== rest(d)) out.push("build-image: the dry-run build differs from the real one in more than outputs:, so a rehearsal no longer builds what ships: " + rest(b) + " vs " + rest(d));
    if (b.with?.outputs !== REAL_OUT) out.push("build-image: the real build must output exactly " + REAL_OUT + " (got " + JSON.stringify(b.with?.outputs) + ")");
    if (d.with?.outputs !== DRY_OUT) out.push("build-image: the dry-run build must output exactly " + DRY_OUT + ", writing nothing to a registry (got " + JSON.stringify(d.with?.outputs) + ")");
    for (const k of ["push", "load", "tags", "cache-from", "cache-to"])
      if (b.with?.[k] !== undefined) out.push("build-image: the build sets " + k + ", which push-by-digest from a cold build must not");
    if (b.with?.provenance !== "mode=max") out.push("build-image: provenance must be mode=max (got " + JSON.stringify(b.with?.provenance) + ")");
    if (b.with?.sbom !== "generator=${{ env.SBOM_GENERATOR }}") out.push("build-image: sbom must be generator=${{ env.SBOM_GENERATOR }} (got " + JSON.stringify(b.with?.sbom) + ")");
    for (const st of [b, d]) if (st["continue-on-error"] !== undefined) out.push("build-image: a build step has continue-on-error");
    // Nothing that hands the build a credential or more authority (#680
    // review): both build the checked-out directory, with no secrets, ssh,
    // extra contexts or entitlements. Without context: ., build-push-action
    // builds the git context and passes its github-token (packages: write
    // here) as a build secret any RUN step can mount.
    for (const st of [b, d]) {
      if (st.with?.context !== ".") out.push("build-image: " + st.id + " builds context " + JSON.stringify(st.with?.context) + ", not the checkout (.)");
      for (const k of ["secrets", "secret-files", "secret-envs", "ssh", "github-token", "build-contexts", "allow", "network"])
        if (st.with?.[k] !== undefined) out.push("build-image: " + st.id + " sets " + k + ", which hands the build a credential or more authority");
    }
  }
  if (jobs["build-image"]) {
    const o = jobs["build-image"].outputs ?? {};
    if (o.digest !== "${{ steps.build.outputs.digest || steps.build-dry.outputs.digest }}")
      out.push("build-image: output digest must be ${{ steps.build.outputs.digest || steps.build-dry.outputs.digest }} (got " + JSON.stringify(o.digest) + ")");
    if (o.archive_sha256 !== "${{ steps.archive.outputs.sha256 }}") out.push("build-image: output archive_sha256 must be ${{ steps.archive.outputs.sha256 }} (got " + JSON.stringify(o.archive_sha256) + ")");
    // The archive digest is taken after the dry build, and only the upload follows.
    const at = bi.findIndex((st) => st.id === "archive");
    const di = bi.indexOf(d);
    if (at < 0 || at < di || !bi.slice(at + 1).length || !bi.slice(at + 1).every((st) => lc(st).startsWith("actions/upload-artifact@")))
      out.push("build-image: the archive digest is not taken after the dry-run build with only its upload after it");
    // Never runs what it built.
    const runsImage = /\bdocker\s+(?:container\s+)?(?:run|create|start|exec|load)\b|docker-smoke\.sh/;
    if (bi.some((st) => runsImage.test(code(st))) || bi.some((st) => isBuild(st) && String(st.with?.load ?? "false") !== "false"))
      out.push("build-image: runs or loads an image in the job holding packages: write");
  }
  // smoke-image: no write scope, the reported digest pulled, the archive
  // checked by content, and the smoke test unconditional.
  const si = stepsOf("smoke-image");
  if (!jobs["smoke-image"]) out.push("no smoke-image job");
  else {
    if (writes(permOf("smoke-image"))) out.push("smoke-image: holds a write scope (" + JSON.stringify(permOf("smoke-image")) + ") in the job that runs the image");
    if (!needsOf("smoke-image").includes("build-image")) out.push("smoke-image: does not list build-image in needs, so its digest reads as empty");
    const DIG = "${{ needs.build-image.outputs.digest }}";
    const pull = si.findIndex((st) => /\bdocker\s+pull\b/.test(code(st)));
    const ps = si[pull];
    if (pull < 0) out.push("smoke-image: never pulls the pushed image");
    else {
      if (ps.if !== "env.DRY_RUN != \x27true\x27") out.push("smoke-image: the pull runs under " + JSON.stringify(ps.if) + ", not env.DRY_RUN != \x27true\x27");
      if (ps.env?.DIGEST !== DIG) out.push("smoke-image: the pull takes DIGEST from " + JSON.stringify(ps.env?.DIGEST) + ", not " + DIG);
      if (!/ref="ghcr\.io\/\$\{GITHUB_REPOSITORY,,\}@\$\{DIGEST\}"/.test(code(ps)) || !/\bdocker\s+pull\s+--platform\s+linux\/amd64\s+"\$ref"/.test(code(ps)))
        out.push("smoke-image: the pull is not docker pull --platform linux/amd64 of ghcr.io/<repo>@${DIGEST}");
      if (!/\bdocker\s+logout\s+ghcr\.io\b/.test(code(ps))) out.push("smoke-image: the registry credential stays on disk while the image runs");
    }
    const load = si.findIndex((st) => /\bdocker\s+load\b/.test(code(st)));
    const ls = si[load];
    if (load < 0) out.push("smoke-image: never loads the dry-run archive");
    else {
      if (ls.if !== "env.DRY_RUN == \x27true\x27") out.push("smoke-image: the archive load runs under " + JSON.stringify(ls.if) + ", not env.DRY_RUN == \x27true\x27");
      if (ls.env?.DIGEST !== DIG || ls.env?.ARCHIVE_SHA256 !== "${{ needs.build-image.outputs.archive_sha256 }}")
        out.push("smoke-image: the archive load does not take DIGEST and ARCHIVE_SHA256 from build-image outputs");
      const dl = si[load - 1];
      if (!dl || !lc(dl).startsWith("actions/download-artifact@") || dl.with?.name !== "release-image-oci" || dl.if !== ls.if)
        out.push("smoke-image: the archive load is not right after the release-image-oci download, under the same condition");
      const c = code(ls);
      if (!/sha256sum -c -[\s\S]*tar -xf[\s\S]*sha256sum -c -[\s\S]*sha256sum -c -[\s\S]*docker load/.test(c))
        out.push("smoke-image: the archive load does not check the archive, then the index, then the amd64 manifest, before docker load");
    }
    const sm = si.findIndex((st) => /docker-smoke\.sh\s+"\$GATE_IMAGE_TAG"/.test(code(st)));
    if (sm < 0) out.push("smoke-image: never runs docker-smoke.sh on $GATE_IMAGE_TAG");
    else {
      if (si[sm].if !== undefined || si[sm]["continue-on-error"] !== undefined) out.push("smoke-image: the smoke test can be skipped or allowed to fail");
      if (sm < pull || sm < load) out.push("smoke-image: smokes before the image is pulled or loaded");
    }
    for (const st of [ps, ls]) if (st && st["continue-on-error"] !== undefined) out.push("smoke-image: the pull or load is allowed to fail");
  }
  // publish-docker: tags that digest, builds nothing, after the approval chain.
  const pd = stepsOf("publish-docker");
  if (!jobs["publish-docker"]) out.push("no publish-docker job");
  else {
    const p = permOf("publish-docker");
    if (JSON.stringify(p) !== JSON.stringify({ packages: "write" })) out.push("publish-docker: permissions must be exactly packages: write (got " + JSON.stringify(p) + ")");
    for (const n of ["build-image", "smoke-image", "publish-brain"])
      if (!needsOf("publish-docker").includes(n)) out.push("publish-docker: does not list " + n + " in needs");
    const t = pd.find((st) => /\bimagetools\s+create\b/.test(code(st)));
    if (!t) out.push("publish-docker: never runs imagetools create");
    else {
      if (t.env?.DIGEST !== "${{ needs.build-image.outputs.digest }}") out.push("publish-docker: tags a DIGEST from " + JSON.stringify(t.env?.DIGEST) + ", not build-image");
      if (!/imagetools\s+create\s+"\$\{args\[@\]\}"\s+"\$\{image\}@\$\{DIGEST\}"/.test(code(t))) out.push("publish-docker: imagetools create does not take its source as ${image}@${DIGEST}");
      if (t.if !== undefined || t["continue-on-error"] !== undefined) out.push("publish-docker: the tag step can be skipped or allowed to fail");
    }
    if (pd.some((st) => lc(st).startsWith("actions/checkout@") || lc(st).startsWith("docker/setup-")))
      out.push("publish-docker: checks out or sets up a builder, and it builds nothing");
  }
  // The gates in front of every publisher.
  for (const j of ["sidecar", "pack-brain", "publish-brain", "publish-docker", "github-release"])
    if (jobs[j] && !upstream(j, "smoke-image")) out.push(j + ": does not run after smoke-image, so it can publish an image nobody ran");
  if (jobs["publish-docker"] && !upstream("publish-docker", "publish-brain")) out.push("publish-docker: does not run after publish-brain, the approval gate");
  if (jobs["github-release"] && !upstream("github-release", "publish-docker")) out.push("github-release: does not run after publish-docker");
  for (const j of ["build-image", "smoke-image", "publish-docker"])
    if (/\b(always|failure|cancelled)\s*\(|\bsuccess\s*\(\s*\)\s*\|\|/.test(String(jobs[j]?.if ?? ""))) out.push(j + ": can run after a failed gate (if: " + jobs[j].if + ")");
  if (out.length) console.log(out.join("\n"));
  process.exit(0);
}
if (mode === "postsign") {
  // #817: the Authenticode check runs in a job that cannot mint a token, on
  // exactly the bytes that ship, and publishing waits for it. The signer
  // defers to it, so nothing in the signer needs osslsigncode.
  const out = [];
  const file = require("node:path").basename(process.env.WORKFLOW);
  const T = file === "sidecar-release.yml"
    ? { sign: "sign-sidecar-windows", verify: "verify-sidecar-windows", publish: "publish-sidecar", artifact: "sidecar-win32-x64" }
    : file === "installer-release.yml"
      ? { sign: "sign-windows", verify: "verify-windows", publish: "publish", artifact: "installer-win32-x64" }
      : null;
  if (!T) { console.log("no post-sign verification is known for " + file); process.exit(0); }
  const stepsOf = (j) => jobs[j]?.steps ?? [];
  const calls = (j) => stepsOf(j).filter((st) => typeof st.run === "string" && /\bsign-windows\.sh\b/.test(st.run));
  const SIGNED = "needs." + T.sign + ".outputs.signed == \x27true\x27";
  // The signer: every call defers, under the readiness condition, and the
  // signer reports whether it signed.
  if (!jobs[T.sign]) out.push("no " + T.sign + " job");
  else {
    const c = calls(T.sign);
    if (!c.length) out.push(T.sign + ": never calls sign-windows.sh");
    for (const st of c) {
      if (!/\bsign-windows\.sh\s+--defer-verify\s/.test(st.run))
        out.push(T.sign + ": calls sign-windows.sh without --defer-verify, so it would verify, and need osslsigncode, in the job holding id-token");
      if (st.if !== "steps.winsign.outputs.ready == \x27true\x27")
        out.push(T.sign + ": signs under " + JSON.stringify(st.if) + ", not the readiness its signed output reports");
    }
    if (jobs[T.sign].outputs?.signed !== "${{ steps.winsign.outputs.ready }}")
      out.push(T.sign + ": output signed must be ${{ steps.winsign.outputs.ready }} (got " + JSON.stringify(jobs[T.sign].outputs?.signed) + "), or the check can be told there is nothing to verify");
  }
  const v = jobs[T.verify];
  if (!v) out.push("no " + T.verify + " job");
  else {
    const perm = v.permissions ?? doc.permissions;
    if (perm === "write-all" || (perm && typeof perm === "object" && Object.values(perm).some((x) => x === "write")))
      out.push(T.verify + ": holds a write scope or id-token (" + JSON.stringify(perm) + "); it installs a package and needs neither");
    if (!needsOf(T.verify).includes(T.sign)) out.push(T.verify + ": does not list " + T.sign + " in needs, so its outputs read as empty");
    const steps = stepsOf(T.verify);
    const dl = steps.findIndex((st) => String(st.uses ?? "").toLowerCase().startsWith("actions/download-artifact@"));
    const chk = steps[dl + 1];
    if (dl < 0 || steps[dl].with?.name !== T.artifact) out.push(T.verify + ": does not download " + T.artifact + ", the artifact that ships");
    else if (!chk || typeof chk.run !== "string" || !/\bsha256sum\b[^\n]*\s-c\b/.test(chk.run) || chk.env?.SHA256 !== "${{ needs." + T.sign + ".outputs.sha256 }}")
      out.push(T.verify + ": the step after the download is not a sha256sum -c against ${{ needs." + T.sign + ".outputs.sha256 }}, the digest of what ships");
    else if (steps[dl].if !== undefined || chk.if !== undefined || steps[dl]["continue-on-error"] !== undefined || chk["continue-on-error"] !== undefined)
      out.push(T.verify + ": its download or digest check can be skipped or allowed to fail");
    const at = steps.findIndex((st) => typeof st.run === "string" && /\bsign-windows\.sh\s+--verify-only\s/.test(st.run));
    const ver = steps[at];
    if (at < 0) out.push(T.verify + ": never runs sign-windows.sh --verify-only");
    else {
      if (at < dl + 2) out.push(T.verify + ": verifies before the digest check");
      if (ver.if !== SIGNED) out.push(T.verify + ": verifies under " + JSON.stringify(ver.if) + ", not exactly " + SIGNED);
      if (ver["continue-on-error"] !== undefined) out.push(T.verify + ": the signature check is allowed to fail");
      if (String(ver.env?.SIGN_REQUIRE_TRUSTED_CHAIN) !== "1") out.push(T.verify + ": SIGN_REQUIRE_TRUSTED_CHAIN is " + JSON.stringify(ver.env?.SIGN_REQUIRE_TRUSTED_CHAIN) + ", not \"1\"");
      if (ver.env?.SIGNING_PUBLISHER_CN !== "${{ vars.SIGNING_PUBLISHER_CN }}") out.push(T.verify + ": the publisher is not taken from vars.SIGNING_PUBLISHER_CN");
      const inst = steps.findIndex((st) => typeof st.run === "string" && /\bapt-get\s+install\b[^\n]*\bosslsigncode\b/.test(st.run));
      if (inst < 0 || inst > at || steps[inst].if !== SIGNED) out.push(T.verify + ": does not install osslsigncode, under the same condition, before the check");
    }
  }
  if (!needsOf(T.publish).includes(T.verify)) out.push(T.publish + ": does not wait for " + T.verify + ", so it can publish a signature nobody checked");
  // Job-level bypasses (#817 review): a failed check must fail the job, and
  // the publisher must not run past a failed or skipped dependency.
  for (const j of [T.sign, T.verify, T.publish])
    if (jobs[j]?.["continue-on-error"] !== undefined) out.push(j + ": continue-on-error on the job, so a failure there does not stop the publish");
  const SHOULD = "needs.resolve.outputs.should_release == \x27true\x27";
  if (v && v.if !== SHOULD) out.push(T.verify + ": runs under " + JSON.stringify(v.if) + ", not exactly " + SHOULD);
  if (/\b(?:always|failure|cancelled)\s*\(/.test(String(jobs[T.publish]?.if ?? "")))
    out.push(T.publish + ": can run after a failed dependency (if: " + jobs[T.publish].if + ")");
  if (out.length) console.log(out.join("\n"));
  process.exit(0);
}
// mode === "structure": one violation per line, nothing when clean.
const out = [];
const EXPECT_OUTPUTS = {
  tag: "${{ steps.validate.outputs.tag }}",
  version: "${{ steps.validate.outputs.version }}",
  prerelease: "${{ steps.validate.outputs.prerelease }}",
};
const EXPECT_ENV = {
  RAW_TAG: "${{ inputs.tag || github.ref_name }}",
  REF_NAME: "${{ github.ref_name }}",
  REF_TYPE: "${{ github.ref_type }}",
};
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const gate = jobs["validate-tag"];
if (!gate) out.push("no validate-tag job");
else {
  const perms = gate.permissions;
  if (!(perms && typeof perms === "object" && Object.keys(perms).length === 0))
    out.push("validate-tag must declare permissions: {} (got " + JSON.stringify(perms) + ")");
  const steps = gate.steps ?? [];
  if (steps.length !== 1 || steps[0].id !== "validate" || steps[0].uses)
    out.push("validate-tag must run exactly one step, its own `validate` run block");
  const v = steps.find((s) => s.id === "validate");
  if (v && !same(v.env, EXPECT_ENV))
    out.push("validate-tag step env must be exactly " + JSON.stringify(EXPECT_ENV) + " (got " + JSON.stringify(v.env) + ")");
  if (v && v.shell !== undefined && v.shell !== "bash")
    out.push("validate-tag step must run under bash (got shell: " + v.shell + ")");
  if (!same(gate.outputs, EXPECT_OUTPUTS))
    out.push("validate-tag outputs must forward exactly what the validator wrote: " + JSON.stringify(EXPECT_OUTPUTS) + " (got " + JSON.stringify(gate.outputs) + ")");
}
// The raw tag, in every spelling: expression syntax with dots or brackets,
// the push event payload, and the runner default env vars a `run:` can read.
const raw = /\binputs\s*(\.|\[)\s*["\x27]?tag\b|\bgithub\s*(\.|\[)\s*["\x27]?(ref|ref_name|event|event_path|workflow_ref)\b|\bGITHUB_(REF|REF_NAME|EVENT_PATH|WORKFLOW_REF)\b|\btoJSON\s*\(\s*(github|inputs)\s*\)/i;
if (raw.test(JSON.stringify(doc.env ?? {}))) out.push("workflow-level env reads the raw tag");
// The release must be created at the commit this run built, or a tag that
// vanished mid-run is re-created at the default branch tip.
const rel = (jobs["github-release"]?.steps ?? []).find((s) => String(s.uses ?? "").startsWith("softprops/action-gh-release@"));
if (!rel) out.push("github-release has no action-gh-release step");
else if (rel.with?.target_commitish !== "${{ github.sha }}")
  out.push("action-gh-release must set target_commitish: ${{ github.sha }} (got " + JSON.stringify(rel.with?.target_commitish) + ")");
const reads = /needs\s*(\.\s*validate-tag|\[\s*["\x27]validate-tag["\x27]\s*\])/;
const readKeys = /needs\s*(?:\.\s*validate-tag|\[\s*["\x27]validate-tag["\x27]\s*\])\s*\.\s*outputs\s*\.\s*([A-Za-z0-9_-]+)/g;
for (const [name, job] of Object.entries(jobs)) {
  const text = JSON.stringify(job);
  if (name !== "validate-tag" && raw.test(text))
    out.push(name + ": reads the raw tag instead of needs.validate-tag.outputs");
  for (const [i, s] of (job.steps ?? []).entries()) {
    const label = s.name ?? s.id ?? s.uses ?? String(i);
    if (typeof s.run === "string" && s.run.includes("${{"))
      out.push(name + ": step " + label + " has a ${{ }} expression inside run:");
    if (typeof s.with?.script === "string" && s.with.script.includes("${{"))
      out.push(name + ": step " + label + " has a ${{ }} expression inside a script: input");
  }
  if (name === "validate-tag" || !reads.test(text)) continue;
  if (!needsOf(name).includes("validate-tag"))
    out.push(name + ": reads needs.validate-tag.* but does not list validate-tag in needs");
  for (const m of text.matchAll(readKeys))
    if (!gate?.outputs || !(m[1] in gate.outputs))
      out.push(name + ": reads needs.validate-tag.outputs." + m[1] + ", which validate-tag does not output");
  if (/\b(always|failure|cancelled)\s*\(/.test(String(job.if ?? "")))
    out.push(name + ": reads validate-tag outputs but can run after a failed gate (if: " + job.if + ")");
}
// #645: one publish at a time, queued rather than cancelled. The group must be
// global for real publishes -- per-ref or per-run context would put two
// releases in different groups and let them race for :latest again.
const cc = doc.concurrency;
if (!cc || typeof cc !== "object") out.push("no workflow-level concurrency block (#645)");
else {
  if (cc["cancel-in-progress"] !== false)
    out.push("concurrency must set cancel-in-progress: false; cancelling a half-finished publish is worse than queueing (got " + JSON.stringify(cc["cancel-in-progress"]) + ")");
  // An allowlist, not a denylist of contexts: any expression in the group
  // can split two releases into different groups.
  if (cc.group !== "release-exec")
    out.push("concurrency group must be exactly the global release-exec (got " + JSON.stringify(cc.group) + ")");
  // The default queue holds one pending run and cancels it for the next one.
  if (cc.queue !== "max")
    out.push("concurrency must set queue: max, or a third queued release evicts the waiting one (got " + JSON.stringify(cc.queue) + ")");
}
const reaches = (j, seen = new Set()) => {
  if (j === "validate-tag") return true;
  if (seen.has(j)) return false;
  seen.add(j);
  return needsOf(j).some((n) => reaches(n, seen));
};
for (const name of Object.keys(jobs))
  if (name !== "validate-tag" && !reaches(name)) out.push(name + ": does not run downstream of validate-tag");
// #682: every job that installs dependencies runs either before the sidecar
// workflow starts (upstream of it) or after it has published (downstream).
// Running alongside it, a lifecycle script could swap a sidecar artifact
// between its upload and the download in publish-sidecar.
const upstreamOf = (j, target, seen = new Set()) => {
  if (j === target) return true;
  if (seen.has(j)) return false;
  seen.add(j);
  return needsOf(j).some((n) => upstreamOf(n, target, seen));
};
for (const [name, job] of Object.entries(jobs)) {
  const runs = (job.steps ?? []).map((st) => typeof st.run === "string" ? st.run : "").join("\n");
  const depCode = /\b(?:bun\s+(?:install|i|add|run|test|x)|bunx|npx|npm\s+(?:ci|install|i|run|run-script|test|pack|exec|x))\b/;
  if (!depCode.test(runs) || !jobs.sidecar) continue;
  if (!upstreamOf("sidecar", name) && !upstreamOf(name, "sidecar"))
    out.push(name + ": installs dependencies while the sidecar workflow may still be running (neither before nor after it)");
}
// ...and ordering covers only publish-sidecar. A job that consumes the
// sidecar-* artifacts later (github-release attaches them) checks them
// against the digests publish-sidecar recorded, which arrive as a job output.
for (const [name, job] of Object.entries(jobs)) {
  const steps = job.steps ?? [];
  // A download reaches the sidecar artifacts when it names none (that is
  // all of them) or its name or glob matches a sidecar artifact name.
  const glob = (g) => new RegExp("^" + String(g).replace(/[.+^$(){}|\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
  const reaches = (st) => {
    const w = st.with ?? {};
    if (w.name === undefined && w.pattern === undefined) return true;
    return ["sidecar-linux-x64", "sidecar-win32-x64", "sidecar-darwin-arm64"].some((n) => glob(w.pattern ?? w.name).test(n));
  };
  const dl = steps.findIndex((st) => String(st.uses ?? "").startsWith("actions/download-artifact@") && reaches(st));
  if (dl < 0) continue;
  // Same condition as the download (or none), so it cannot be switched off
  // on its own.
  const cond = steps[dl].if;
  const v = steps.findIndex((st, i) => i > dl && typeof st.run === "string" && /\bsha256sum\b[^\n]*-c\b/.test(st.run) &&
    /needs\.sidecar\.outputs\.sums/.test(JSON.stringify(st.env ?? {})) && (st.if === undefined || st.if === cond));
  if (v < 0) out.push(name + ": uses the sidecar artifacts without checking them against needs.sidecar.outputs.sums");
  else if (steps.slice(dl + 1, v).some((st) => st.run !== undefined || st.uses))
    out.push(name + ": does something with the sidecar artifacts before checking their digests");
}
// A write call to the releases API needs `contents: write`, and each job
// declares its own permissions (#646), so a step pasted into the wrong job
// gets a 403 at the END of a release -- after the tag exists and npm has
// published. #786 did exactly that: the dry-run notes step landed in
// github-release (contents: write, correct) AND in publish-docker
// (contents: read); the copy that got a 403 failed the run, which skipped the
// copy that worked. A GET is fine on read, so this keys on the method.
for (const [name, job] of Object.entries(jobs))
  for (const [i, s] of (job.steps ?? []).entries()) {
    if (typeof s.run !== "string" || !/\bgh\s+api\b/.test(s.run)) continue;
    if (!/--method\s+(POST|PUT|PATCH|DELETE)\b/.test(s.run)) continue;
    if (!/\/releases\b/.test(s.run)) continue;
    if (job.permissions?.contents !== "write")
      out.push(name + ": step " + (s.name ?? s.id ?? String(i)) +
        " writes to the releases API but its job has contents: " +
        JSON.stringify(job.permissions?.contents ?? null) + " (needs \"write\", or it 403s)");
  }
if (out.length) console.log(out.join("\n"));
' "$@"
}

VALIDATOR="$(yq validator)" || {
	echo "could not extract the validate-tag step from $WORKFLOW" >&2
	exit 1
}

echo "release tag validator (executed verbatim from the workflow)"

# The script must be runnable as extracted. If it carried a ${{ }}, executing it
# here would test text the runner never runs.
# shellcheck disable=SC2016 # a literal GitHub expression opener is the pattern.
case "$VALIDATOR" in
*'${{'*) no "the validator contains a \${{ }} expression, so this test cannot execute it as the runner would" ;;
*) ok "the validator has no \${{ }} expression, so what runs here is what runs in CI" ;;
esac

# run_validator <tag> [ref_name] [ref_type] [dry_run] [locale]: sets RC and
# OUT (the $GITHUB_OUTPUT content). Defaults model a tag push of <tag>.
run_validator() {
	local out="${WORK}/output"
	: >"$out"
	local -a envs=(PATH="$PATH" GITHUB_OUTPUT="$out"
		RAW_TAG="$1" REF_NAME="${2-$1}" REF_TYPE="${3:-tag}" DRY_RUN="${4:-false}")
	[ -n "${5:-}" ] && envs+=(LC_ALL="$5" LANG="$5")
	env -i "${envs[@]}" bash -c "$VALIDATOR" >"${WORK}/stdout" 2>&1
	RC=$?
	OUT="$(cat "$out")"
}

# accept <tag> <version> <prerelease> [ref_name] [ref_type] [dry_run]
accept() {
	local label
	label="$(printf '%q' "$1")${4+ on ${5:-tag} $(printf '%q' "$4")}${6:+ (dry_run=$6)}"
	run_validator "$1" "${4-$1}" "${5:-tag}" "${6:-false}"
	local want
	want="$(printf 'tag=v%s\nversion=%s\nprerelease=%s' "$2" "$2" "$3")"
	if [ "$RC" -eq 0 ] && [ "$OUT" = "$want" ]; then
		ok "accepts ${label} -> version=$2 prerelease=$3"
	else
		no "accepts ${label}" "exit ${RC}; GITHUB_OUTPUT was:
${OUT}
expected:
${want}
stdout/stderr:
$(cat "${WORK}/stdout")"
	fi
}

# expect_rejected <label> <error prefix>: the run just made must have exited
# non-zero, written NOTHING to $GITHUB_OUTPUT, printed exactly one workflow
# command (the ::error:: naming the problem), and created no sentinel.
expect_rejected() {
	local label="$1" prefix="$2"
	if [ "$RC" -eq 0 ]; then
		no "rejects ${label}" "exited 0; GITHUB_OUTPUT was:
${OUT}"
	elif [ -n "$OUT" ]; then
		no "rejects ${label} without writing outputs" "GITHUB_OUTPUT was:
${OUT}"
	elif ! grep -qF "::error::${prefix}" "${WORK}/stdout"; then
		no "rejects ${label} with the ::error:: '${prefix}...'" "$(cat "${WORK}/stdout")"
	elif [ "$(grep -c '^::' "${WORK}/stdout")" -ne 1 ]; then
		no "rejects ${label} with exactly one workflow command (a newline must not start another)" "$(cat "${WORK}/stdout")"
	elif [ -e "${WORK}/pwned" ]; then
		no "rejects ${label} without evaluating it" "the sentinel ${WORK}/pwned was created"
	else
		ok "rejects ${label}"
	fi
}

NOT_SEMVER='Release tag is not v<semver>'
WRONG_REF='A real release must build the tag it publishes'

# reject <tag>: rejected as malformed (on a tag push of itself).
reject() {
	rm -f "${WORK}/pwned"
	run_validator "$1"
	expect_rejected "$(printf '%q' "$1")" "$NOT_SEMVER"
}

accept 'v1.2.3' '1.2.3' false
accept 'v1.2.3-rc.1' '1.2.3-rc.1' true
# workflow_dispatch's default input: a dry run must still get past the gate.
accept 'v0.0.0-dry-run' '0.0.0-dry-run' true main branch true
accept 'v10.20.30' '10.20.30' false
# What `npm version prerelease` produces, i.e. what release.yml can dispatch.
accept 'v1.2.4-0' '1.2.4-0' true
accept 'v1.2.3-alpha-1.beta.11' '1.2.3-alpha-1.beta.11' true
accept 'v1.2.3-0a.x-y' '1.2.3-0a.x-y' true

# Sizes every publisher accepts: 16-digit components, a 128-character version
# (Docker's tag limit; npm's is 256).
accept 'v1234567890123456.0.0' '1234567890123456.0.0' false
reject 'v12345678901234567.0.0'
reject 'v1.12345678901234567.0'
LONG_OK="1.2.3-$(printf 'a%.0s' $(seq 1 122))"
accept "v${LONG_OK}" "$LONG_OK" true
reject "v${LONG_OK}a"

# No leading v: github-release uses the tag verbatim as tag_name.
reject '1.2.3'
reject ''
reject 'v'
reject 'v1.2'
reject 'v01.2.3'
reject 'vv1.2.3'
reject 'refs/tags/v1.2.3'
reject ' v1.2.3'
reject 'v1.2.3 '
# Build metadata: npm drops it, so v1.2.3+x would collide with 1.2.3.
reject 'v1.2.3-rc.1+build.5'
reject 'v1.2.3+build.5'
reject 'v1.2.3+build-5'
# Looser than SemVer 2.0 pre-release identifiers, all refused by `npm version`.
reject 'v1.2.3-'
reject 'v1.2.3-01'
reject 'v1.2.3-rc.01'
reject 'v1.2.3-.'
reject 'v1.2.3-rc..1'
reject 'v1.2.3-rc.'
# The two shapes the issue verified git accepts as ref names.
reject 'v1.0.0";id;"'
# shellcheck disable=SC2016 # the literal, unexpanded text IS the fixture.
reject 'v1.0.0$(id)'
# The same shapes with a payload that would leave evidence if evaluated.
reject "v1.0.0\$(touch ${WORK}/pwned)"
reject "v1.0.0\";touch ${WORK}/pwned;\""
reject "v1.0.0\`touch ${WORK}/pwned\`"
reject "v1.0.0-\$(touch ${WORK}/pwned)"
# Newlines: the old echo would have written a second KEY=value line, and a
# per-line regex would accept the first line.
reject $'v1.2.3\nversion=9.9.9'
reject $'v1.2.3\n'
reject $'v1.2.3\n::warning::injected'
reject $'v1.2.3\rversion=9.9.9'

# The tag must be the ref being built on a real run; a dry run is free.
rm -f "${WORK}/pwned"
run_validator 'v1.2.3' 'main' 'branch' false
expect_rejected "v1.2.3 dispatched from branch main (real run)" "$WRONG_REF"
run_validator 'v1.2.4' 'v1.2.3' 'tag' false
expect_rejected "tag input v1.2.4 on a run of tag v1.2.3 (real run)" "$WRONG_REF"
run_validator 'v1.2.3' 'v1.2.3' 'branch' false
expect_rejected "v1.2.3 on a BRANCH named v1.2.3 (real run)" "$WRONG_REF"
accept 'v1.2.3' '1.2.3' false 'main' 'branch' true

# A UTF-8 locale must not widen [A-Za-z]/[0-9] past ASCII. Under glibc's
# en_US.UTF-8 both of these matched the unguarded regex; the runner itself uses
# C.UTF-8, where they do not, which is why this pins en_US explicitly.
UTF8_LOCALE="$(locale -a 2>/dev/null | grep -im1 -E '^en_US\.utf-?8$' || true)"
if [ -z "$UTF8_LOCALE" ]; then
	echo "  skip - no en_US.UTF-8 locale on this machine, so the locale fixtures cannot run"
else
	for tag in $'v1.2.3-é' $'v١.2.3' $'v1.2.3-ａ'; do
		run_validator "$tag" "$tag" tag false "$UTF8_LOCALE"
		expect_rejected "$(printf '%q' "$tag") under ${UTF8_LOCALE}" "$NOT_SEMVER"
	done
fi

echo
echo "workflow structure"
VIOLATIONS="$(yq structure)" || {
	no "structure check ran" "the bun helper failed"
	VIOLATIONS=""
}
if [ -z "$VIOLATIONS" ]; then
	ok "no run: contains \${{ }}, the raw tag is read only by the validator, outputs and needs line up, every job is gated"
else
	no "workflow structure" "$VIOLATIONS"
fi

echo
echo "the structure check reports each hole (mutated copies of the workflow)"
# mutant <label> <exact text> <replacement> [reason]: the text must occur exactly once.
# MUTANT_FROM (default the release workflow) and MUTANT_MODE (default
# structure) pick the file and the check. The copy keeps the basename of the
# file it mutates, because the dry-run check keys on it: a copy called
# anything else would be reported for its name, whatever its content.
mutant() {
	local label="$1" from="${MUTANT_FROM:-$WORKFLOW}"
	mkdir -p "${WORK}/m"
	local copy
	copy="${WORK}/m/$(basename "$from")"
	if ! FROM="$from" TO="$copy" OLD="$2" NEW="$3" bun -e '
const s = await Bun.file(process.env.FROM).text();
const n = s.split(process.env.OLD).length - 1;
if (n !== 1) { console.error("anchor occurs " + n + " times"); process.exit(2); }
await Bun.write(process.env.TO, s.replace(process.env.OLD, process.env.NEW));
'; then
		no "mutant '${label}' could be applied (the workflow no longer has the text it mutates)"
		return
	fi
	mutant_report "$label" "$copy" "${4:-}"
}
# mutant_all <label> <exact text> <replacement>: every occurrence, at least two
# (for a hole that needs the same change in two places, such as both builds).
mutant_all() {
	local label="$1" from="${MUTANT_FROM:-$WORKFLOW}"
	mkdir -p "${WORK}/m"
	local copy
	copy="${WORK}/m/$(basename "$from")"
	if ! FROM="$from" TO="$copy" OLD="$2" NEW="$3" bun -e '
const s = await Bun.file(process.env.FROM).text();
const n = s.split(process.env.OLD).length - 1;
if (n < 2) { console.error("anchor occurs " + n + " times"); process.exit(2); }
await Bun.write(process.env.TO, s.split(process.env.OLD).join(process.env.NEW));
'; then
		no "mutant '${label}' could be applied (the workflow no longer has the text it mutates)"
		return
	fi
	mutant_report "$label" "$copy" "${4:-}"
}
# mutant_report <label> <mutated copy> [reason]: with a reason, the report
# must contain it, so a mutant that some OTHER rule happens to report
# proves nothing about the rule it was written for (#680 review).
mutant_report() {
	local label="$1" copy="$2" reason="${3:-}"
	local found
	found="$(YQ_FILE="$copy" yq "${MUTANT_MODE:-structure}")"
	if [ -n "$found" ] && [ -n "$reason" ] && ! grep -qF -- "$reason" <<<"$found"; then
		no "reports: ${label}, for the reason it exists" "wanted '${reason}', got:
${found}"
	elif [ -n "$found" ]; then
		ok "reports: ${label}"
		# MUTANT_VERBOSE=1 shows WHAT was reported, to check it is the hole
		# the mutant made and not some other complaint.
		[ -n "${MUTANT_VERBOSE:-}" ] && printf '%s\n' "$found" | sed 's/^/           /'
	else
		no "reports: ${label}" "the structure check passed a workflow with this hole"
	fi
	return 0
}
# shellcheck disable=SC2016 # every mutant is literal workflow text.
{
	mutant 'the gate forwarding the raw tag as an output' \
		'version: ${{ steps.validate.outputs.version }}' 'version: ${{ inputs.tag || github.ref_name }}'
	mutant 'a ${{ }} expression back inside a run:' \
		'run: npm version "$VERSION"' 'run: npm version "${{ needs.validate-tag.outputs.version }}"'
	mutant 'a consumer that does not list validate-tag in needs' \
		'needs: [validate-tag, pack-brain, smoke-image, sidecar]' 'needs: [pack-brain, smoke-image, sidecar]'
	mutant 'RELEASE_TAG back in the workflow env' \
		'  DRY_RUN: ${{ inputs.dry_run == true }}' '  DRY_RUN: ${{ inputs.dry_run == true }}
  RELEASE_TAG: ${{ inputs.tag || github.ref_name }}'
	mutant 'a step reading $GITHUB_REF_NAME' \
		'run: npm version "$VERSION"' 'run: npm version "${GITHUB_REF_NAME#v}"'
	mutant 'an env var bound to github.event.ref' \
		'VERSION: ${{ needs.validate-tag.outputs.version }}
        run: npm version' 'VERSION: ${{ github.event.ref }}
        run: npm version'
	mutant 'bracket syntax for the raw tag' \
		'tag_name: ${{ needs.validate-tag.outputs.tag }}' "tag_name: \${{ github['ref_name'] }}"
	mutant 'a step reading the event payload file' \
		'run: npm version "$VERSION"' 'run: npm version "$(jq -r .ref "$GITHUB_EVENT_PATH")"'
	mutant 'the whole github context serialised into an env var' \
		'VERSION: ${{ needs.validate-tag.outputs.version }}
        run: npm version' 'VERSION: ${{ toJSON(github) }}
        run: npm version'
	mutant 'the release no longer pinned to the built commit' \
		'          target_commitish: ${{ github.sha }}
' ''
	mutant 'a token scope on the gate' \
		'    permissions: {}
    timeout-minutes: 5' '    permissions:
      contents: read
    timeout-minutes: 5'
	mutant 'the validator fed something other than the tag' \
		'RAW_TAG: ${{ inputs.tag || github.ref_name }}' 'RAW_TAG: ${{ github.event.head_commit.message }}'
	mutant 'a second step in the gate' \
		'      - name: Validate the release tag' '      - uses: actions/checkout@v5
      - name: Validate the release tag'
	mutant 'a consumer that runs after a failed gate' \
		'    needs: [validate-tag, publish-docker, sidecar]' '    needs: [validate-tag, publish-docker, sidecar]
    if: always()'
	mutant 'a misspelt output name' \
		'enable=${{ needs.validate-tag.outputs.prerelease' 'enable=${{ needs.validate-tag.outputs.prerelaese'
	mutant 'a per-ref concurrency group (#645)' \
		"group: release-exec" 'group: release-exec-${{ github.ref }}'
	mutant 'a releases-API write in a job that only has contents: read (#786)' \
		'which needs no token scope.
    permissions:
      contents: write' 'which needs no token scope.
    permissions:
      contents: read'
	mutant 'a dry-run-split concurrency group (#645)' \
		'  group: release-exec
' "  group: release-exec\${{ inputs.dry_run && '-dry-run' || '' }}
"
	mutant 'the default single-pending queue (#645)' \
		'  queue: max
' ''
	mutant 'cancel-in-progress on the publish group (#645)' \
		'  cancel-in-progress: false' '  cancel-in-progress: true'
	mutant 'the brain build running alongside the sidecar workflow (#682)' \
		'    needs: [validate-tag, test, smoke-image, sidecar]' '    needs: [validate-tag, test, smoke-image]'
	mutant 'the GitHub Release attaching sidecar binaries without checking their digests (#682)' \
		"printf '%s' \"\$SUMS\" | base64 -d | sha256sum --strict -c -" "true"
	mutant 'the sidecar digest check switched off on its own (#682)' \
		$'      - name: Verify sidecar binaries\n        if: needs.sidecar.outputs.released == \'true\'' $'      - name: Verify sidecar binaries\n        if: false'
	mutant 'a download of every artifact attached without a digest check (#682)' \
		$'          path: artifacts\n          pattern: sidecar-*\n\n      # Exactly the bytes' $'          path: artifacts\n\n      - run: ls artifacts\n\n      # Exactly the bytes'
	mutant 'a job no longer downstream of the gate' \
		'  test:
    needs: validate-tag' '  test:'
}

echo
echo "the release image is built once, smoke-tested by digest and tagged from that digest (#680)"
found="$(yq image)" || {
	no "image structure check ran" "the bun helper failed"
	found=""
}
if [ -z "$found" ]; then
	ok "one build in build-image, smoke-image runs its digest with no write scope, publish-docker tags it after the approval chain"
else
	no "release image built once" "$found"
fi
# shellcheck disable=SC2016 # every mutant is literal workflow text.
{
	MUTANT_MODE=image
	mutant 'a second build of the image, in the job that tags it (#680)' \
		'      - name: Point the release tags at the smoked digest' $'      - uses: docker/build-push-action@c3c9e263c25d99ce0380d002d59b67737d91b0dc # v7.4.0\n        with:\n          push: true\n      - name: Point the release tags at the smoked digest'
	mutant 'a rebuild by command line in the smoke job (#680)' \
		'      - name: Smoke-test the image (run it like a user does)' $'      - run: docker buildx build --load -t "$GATE_IMAGE_TAG" .\n      - name: Smoke-test the image (run it like a user does)'
	mutant 'the dry-run build drifting from the real one (#680)' \
		$'          sbom: generator=${{ env.SBOM_GENERATOR }}\n          outputs: type=oci' $'          sbom: false\n          outputs: type=oci'
	mutant 'the dry-run build pushing to a registry (#680)' \
		'          outputs: type=oci,dest=${{ runner.temp }}/release-image.oci.tar' '          outputs: type=image,name=ghcr.io/${{ github.repository }},push=true'
	mutant 'the real build pushing a tag of its own (#680)' \
		'          outputs: type=image,name=ghcr.io/${{ github.repository }},push-by-digest=true,name-canonical=true,push=true' $'          outputs: type=image,name=ghcr.io/${{ github.repository }},push-by-digest=true,name-canonical=true,push=true\n          tags: ghcr.io/${{ github.repository }}:latest'
	mutant 'both builds running on a real release (#680)' \
		$'        id: build-dry\n        if: env.DRY_RUN == \'true\'' $'        id: build-dry\n        if: always()'
	mutant 'provenance dropped from the build that ships (#680)' \
		$'          provenance: mode=max\n          sbom: generator=${{ env.SBOM_GENERATOR }}\n          outputs: type=image' $'          provenance: false\n          sbom: generator=${{ env.SBOM_GENERATOR }}\n          outputs: type=image'
	mutant 'the digest output read from the wrong step (#680)' \
		'      digest: ${{ steps.build.outputs.digest || steps.build-dry.outputs.digest }}' '      digest: ${{ steps.meta.outputs.digest }}'
	mutant 'the image run in the job holding packages: write (#680)' \
		'      - name: Upload the dry-run archive' $'      - run: docker run --rm alpine true\n      - name: Upload the dry-run archive'
	mutant 'a write scope on the job that runs the image (#680)' \
		$'    permissions:\n      contents: read\n      packages: read\n' $'    permissions:\n      contents: read\n      packages: write\n'
	mutant 'the smoke job pulling by tag instead of by digest (#680)' \
		'          ref="ghcr.io/${GITHUB_REPOSITORY,,}@${DIGEST}"' '          ref="ghcr.io/${GITHUB_REPOSITORY,,}:latest"'
	mutant 'the registry credential left on disk while the image runs (#680)' \
		'          docker logout ghcr.io' '          true'
	mutant 'the smoke test switched off on its own (#680)' \
		$'      - name: Smoke-test the image (run it like a user does)\n' $'      - name: Smoke-test the image (run it like a user does)\n        if: env.DRY_RUN == \'true\'\n'
	mutant 'the dry-run archive loaded without its content checks (#680)' \
		'          echo "${DIGEST#sha256:}  $(blob "$DIGEST")" | sha256sum -c -' '          true'
	mutant 'the smoke job not waiting for build-image (#680)' \
		'    needs: [validate-tag, build-image]' '    needs: [validate-tag, test]'
	mutant 'the tags taken from a digest other than the one smoked (#680)' \
		$'          DIGEST: ${{ needs.build-image.outputs.digest }}\n          TAGS:' $'          DIGEST: ${{ needs.smoke-image.outputs.digest }}\n          TAGS:'
	mutant 'publish-docker tagging before the approval chain (#680)' \
		'    needs: [validate-tag, build-image, smoke-image, sidecar, publish-brain]' '    needs: [validate-tag, build-image, smoke-image]'
	mutant 'publish-docker given contents: write as well (#680)' \
		$'    permissions:\n      packages: write\n    timeout-minutes: 15' $'    permissions:\n      contents: write\n      packages: write\n    timeout-minutes: 15'
	mutant 'a third job holding packages: write (#680)' \
		$'  github-release:\n    needs: [validate-tag, publish-docker, sidecar]\n    runs-on: ubuntu-latest\n    # Creating the release (and its generated notes) is a contents write. The\n    # sidecar artifacts come from this same run, which needs no token scope.\n    permissions:\n      contents: write' \
		$'  github-release:\n    needs: [validate-tag, publish-docker, sidecar]\n    runs-on: ubuntu-latest\n    # Creating the release (and its generated notes) is a contents write. The\n    # sidecar artifacts come from this same run, which needs no token scope.\n    permissions:\n      contents: write\n      packages: write'
	mutant 'a tag created outside publish-docker (#680)' \
		'          docker tag "$ref" "$GATE_IMAGE_TAG"' $'          docker tag "$ref" "$GATE_IMAGE_TAG"\n          docker buildx imagetools create -t ghcr.io/o/r:latest "$ref"'
	mutant 'the sidecar no longer gated on the smoke test (#680)' \
		'    needs: [test, smoke-image]' '    needs: [test, build-image]'
	mutant 'the tag job allowed to run after a failed smoke test (#680)' \
		$'  publish-docker:\n    needs: [validate-tag, build-image, smoke-image, sidecar, publish-brain]\n' $'  publish-docker:\n    needs: [validate-tag, build-image, smoke-image, sidecar, publish-brain]\n    if: ${{ !cancelled() && needs.build-image.result == \'success\' }}\n'
	mutant 'a third build step in build-image (#680)' \
		'      - name: Digest the dry-run archive' $'      - uses: docker/build-push-action@c3c9e263c25d99ce0380d002d59b67737d91b0dc # v7.4.0\n        if: env.DRY_RUN == \'true\'\n      - name: Digest the dry-run archive'
	mutant 'the dry-run twin on another action version (#680)' \
		$'        id: build-dry\n        if: env.DRY_RUN == \'true\'\n        uses: docker/build-push-action@c3c9e263c25d99ce0380d002d59b67737d91b0dc' $'        id: build-dry\n        if: env.DRY_RUN == \'true\'\n        uses: docker/build-push-action@0000000000000000000000000000000000000000'
	mutant_all 'the SBOM dropped from both builds alike, so they still agree (#680)' \
		$'          sbom: generator=${{ env.SBOM_GENERATOR }}\n' ''
	mutant 'the build that ships allowed to fail (#680)' \
		$'        id: build\n' $'        id: build\n        continue-on-error: true\n'
	mutant 'the real build losing push-by-digest (#680)' \
		'name=ghcr.io/${{ github.repository }},push-by-digest=true,name-canonical=true,push=true' 'name=ghcr.io/${{ github.repository }},push=true'
	mutant 'the archive digest output taken from the wrong step (#680)' \
		'      archive_sha256: ${{ steps.archive.outputs.sha256 }}' '      archive_sha256: ${{ steps.build-dry.outputs.digest }}'
	mutant 'a docker push from a run: step in the build job (#680)' \
		'      - name: Upload the dry-run archive' $'      - run: docker push ghcr.io/vierisid/jarvis:latest\n      - name: Upload the dry-run archive'
	mutant 'the pull running on a dry run too (#680)' \
		$'      - name: Pull the pushed image by digest\n        if: env.DRY_RUN != \'true\'\n' $'      - name: Pull the pushed image by digest\n'
	mutant 'the pull taking its digest from somewhere else (#680)' \
		$'          DIGEST: ${{ needs.build-image.outputs.digest }}\n        run: |\n          set -euo pipefail\n          export LC_ALL=C\n          [[ "$DIGEST" =~ ^sha256:[0-9a-f]{64}$ ]] || { echo "::error::build-image reported no image digest"; exit 1; }\n          ref=' \
		$'          DIGEST: ${{ vars.RELEASE_DIGEST }}\n        run: |\n          set -euo pipefail\n          export LC_ALL=C\n          [[ "$DIGEST" =~ ^sha256:[0-9a-f]{64}$ ]] || { echo "::error::build-image reported no image digest"; exit 1; }\n          ref='
	mutant 'the archive load running on a real release too (#680)' \
		$'      - name: Load the dry-run image from its archive\n        if: env.DRY_RUN == \'true\'\n' $'      - name: Load the dry-run image from its archive\n'
	mutant 'the archive checked against a digest from somewhere else (#680)' \
		'          ARCHIVE_SHA256: ${{ needs.build-image.outputs.archive_sha256 }}' '          ARCHIVE_SHA256: ${{ vars.ARCHIVE_SHA256 }}'
	mutant 'a step between the archive download and its checks (#680)' \
		'      - name: Load the dry-run image from its archive' $'      - run: ls "$RUNNER_TEMP"\n        if: env.DRY_RUN == \'true\'\n      - name: Load the dry-run image from its archive'
	mutant 'the smoke test run before the image is in place (#680)' \
		'      - name: Pull the pushed image by digest' $'      - run: ./.github/scripts/docker-smoke.sh "$GATE_IMAGE_TAG"\n      - name: Pull the pushed image by digest'
	mutant 'a checkout in the tag job, which builds nothing (#680)' \
		'      - name: Point the release tags at the smoked digest' $'      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1\n        with:\n          persist-credentials: false\n      - name: Point the release tags at the smoked digest'
	mutant 'the tag step switched off on its own (#680)' \
		$'      - name: Point the release tags at the smoked digest\n' $'      - name: Point the release tags at the smoked digest\n        if: env.DRY_RUN == \'true\'\n'
	mutant 'the tags created from a tag rather than the smoked digest (#680)' \
		'docker buildx imagetools create "${args[@]}" "${image}@${DIGEST}"' 'docker buildx imagetools create "${args[@]}" "${image}:edge"'
	mutant 'the GitHub Release no longer after the image tags (#680)' \
		'    needs: [validate-tag, publish-docker, sidecar]' '    needs: [validate-tag, publish-brain, sidecar]'
	mutant_all 'both builds exporting to the shared gha cache again (#680)' \
		$'          provenance: mode=max\n' $'          provenance: mode=max\n          cache-to: type=gha,mode=max\n'
	mutant 'the pull allowed to fail (#680)' \
		$'      - name: Pull the pushed image by digest\n' $'      - name: Pull the pushed image by digest\n        continue-on-error: true\n'
	mutant 'publish-docker not waiting for the smoke test (#680)' \
		'    needs: [validate-tag, build-image, smoke-image, sidecar, publish-brain]' '    needs: [validate-tag, build-image, sidecar, publish-brain]'
	# Each of these is caught by its own rule and no other (#680 review): the
	# run: steps go before the login, away from the archive ordering rule,
	# and the build changes go into both builds, away from the drift rule.
	mutant 'the image run in the job holding packages: write, on its own (#680 review)' \
		'      # Only when something will be pushed (#682): a dry run has no use for' $'      - run: docker run --rm alpine true\n      # Only when something will be pushed (#682): a dry run has no use for' \
		'build-image: runs or loads an image in the job holding packages: write'
	mutant 'a docker push from a run: step in the build job, on its own (#680 review)' \
		'      # Only when something will be pushed (#682): a dry run has no use for' $'      - run: docker push ghcr.io/vierisid/jarvis:latest\n      # Only when something will be pushed (#682): a dry run has no use for' \
		'build-image: writes to a registry from a run: step'
	mutant_all 'both builds tagging the image themselves (#680 review)' \
		$'          provenance: mode=max\n' $'          provenance: mode=max\n          tags: ghcr.io/vierisid/jarvis:latest\n' \
		'build-image: the build sets tags'
	mutant_all 'provenance dropped from both builds alike (#680 review)' \
		'          provenance: mode=max' '          provenance: false' \
		'build-image: provenance must be mode=max'
	mutant_all 'the github token handed to both builds as a secret (#680 review)' \
		$'          provenance: mode=max\n' $'          provenance: mode=max\n          secrets: GIT_AUTH_TOKEN=${{ github.token }}\n' \
		'build-image: build sets secrets'
	mutant_all 'both builds off the checkout, onto the git context and its token (#680 review)' \
		$'          context: .\n          file: ./Dockerfile\n          platforms: linux/amd64,linux/arm64\n          labels:' $'          file: ./Dockerfile\n          platforms: linux/amd64,linux/arm64\n          labels:' \
		'build-image: build builds context undefined'
	mutant_all 'both builds granted an insecure entitlement (#680 review)' \
		$'          provenance: mode=max\n' $'          provenance: mode=max\n          allow: security.insecure\n' \
		'build-image: build sets allow'
	mutant 'the push allowed after a failed test gate (#680)' \
		$'  build-image:\n    needs: [validate-tag, test]\n' $'  build-image:\n    needs: [validate-tag, test]\n    if: always()\n'
	unset MUTANT_MODE
}

# The three scripts on this path, executed verbatim with a docker stub that
# records its argv and answers what a registry would.
PUBTAG="$(yq step publish-docker 'Point the release tags at the smoked digest')" || PUBTAG=""
PULL="$(yq step smoke-image 'Pull the pushed image by digest')" || PULL=""
LOAD="$(yq step smoke-image 'Load the dry-run image from its archive')" || LOAD=""
if [ -z "$PUBTAG" ] || [ -z "$PULL" ] || [ -z "$LOAD" ]; then
	no "found the publish-docker tag step and the smoke-image pull and load steps"
else
	mkdir -p "${WORK}/dbin"
	# docker stub: records each call; `imagetools inspect` answers
	# $STUB_INSPECT; `load -i x` computes the image ID docker would (the
	# sha256 of the config named in manifest.json) and `image inspect`
	# returns it, or $STUB_ID when set.
	cat >"${WORK}/dbin/docker" <<'EOF'
#!/usr/bin/env bash
printf '%s\n' "$*" >>"$DOCKER_LOG"
if [ "$1 $2 $3" = "buildx imagetools inspect" ]; then printf '%s\n' "$STUB_INSPECT"; exit 0; fi
# create --dry-run prints the index it would write; "index" hashes to D1.
if [ "$1 $2 $3 $4" = "buildx imagetools create --dry-run" ]; then printf '%s\n' "${STUB_PLANNED-index}"; exit 0; fi
if [ "$1" = load ]; then
	t="$(mktemp -d)"
	tar -xf "$3" -C "$t" || exit 1
	cfg="$(jq -r '.[0].Config' "$t/manifest.json")" || exit 1
	printf 'sha256:%s\n' "$(sha256sum "$t/$cfg" | cut -d' ' -f1)" >"$DOCKER_STATE"
	exit 0
fi
if [ "$1 $2" = "image inspect" ]; then
	if [ -n "${STUB_ID:-}" ]; then printf '%s\n' "$STUB_ID"; else cat "$DOCKER_STATE"; fi
	exit 0
fi
exit 0
EOF
	chmod +x "${WORK}/dbin/docker"
	D1="sha256:$(printf 'index' | sha256sum | cut -d' ' -f1)"
	# pubtag <want 0|1> <label> <dry run> <version> <prerelease> <tags> [digest] [inspect answer]
	pubtag() {
		local want="$1" label="$2"
		: >"${WORK}/docker.log"
		(cd "$WORK" && env -i PATH="${WORK}/dbin:$PATH" DOCKER_LOG="${WORK}/docker.log" GITHUB_REPOSITORY=Vierisid/Jarvis \
			DRY_RUN="$3" VERSION="$4" PRERELEASE="$5" TAGS="$6" DIGEST="${7-$D1}" STUB_INSPECT="${8-\"${7-$D1}\"}" \
			${STUB_PLANNED+STUB_PLANNED="$STUB_PLANNED"} \
			bash -e -c "$PUBTAG") >"${WORK}/pub.out" 2>&1
		local rc=$?
		if { [ "$want" = 0 ] && [ "$rc" -eq 0 ]; } || { [ "$want" != 0 ] && [ "$rc" -ne 0 ]; }; then
			ok "publish-docker: $label"
		else
			no "publish-docker: $label" "exit ${rc}: $(cat "${WORK}/pub.out")
docker calls: $(cat "${WORK}/docker.log")"
		fi
	}
	I=ghcr.io/vierisid/jarvis
	REL_TAGS="$(printf '%s\n' "$I:1.2.3" "$I:1.2" "$I:latest")"
	pubtag 0 "tags a release with its version, major.minor and latest" false 1.2.3 false "$REL_TAGS"
	if [ "$(sed -n 1p "${WORK}/docker.log")" = "buildx imagetools create --dry-run -t $I:1.2.3 -t $I:1.2 -t $I:latest $I@$D1" ] &&
		[ "$(sed -n 2p "${WORK}/docker.log")" = "buildx imagetools create -t $I:1.2.3 -t $I:1.2 -t $I:latest $I@$D1" ] &&
		[ "$(grep -c '^buildx imagetools inspect' "${WORK}/docker.log")" = 3 ]; then
		ok "publish-docker: creates exactly those three tags from ${I}@<digest>, then checks each one"
	else
		no "publish-docker: creates exactly those three tags from the digest, then checks each one" "$(cat "${WORK}/docker.log")"
	fi
	# What metadata-action really emits for a release: latest TWICE, once
	# from the semver flavor and once from the raw latest rule (the v0.15.0
	# publish-docker log, run 36728949586, lists ghcr.io/vierisid/jarvis:latest
	# on two lines). The tag set is what counts, and each tag is created once.
	pubtag 0 "accepts the tags metadata-action emits for a release, latest listed twice" false 1.2.3 false "$(printf '%s\n' "$I:1.2.3" "$I:1.2" "$I:latest" "$I:latest")"
	if [ "$(sed -n 2p "${WORK}/docker.log")" = "buildx imagetools create -t $I:1.2.3 -t $I:1.2 -t $I:latest $I@$D1" ]; then
		ok "publish-docker: creates each of those tags once"
	else
		no "publish-docker: creates each of those tags once" "$(cat "${WORK}/docker.log")"
	fi
	pubtag 0 "tags a prerelease with its version only" false 1.2.3-rc.1 true "$I:1.2.3-rc.1"
	pubtag 1 "refuses latest on a prerelease" false 1.2.3-rc.1 true "$(printf '%s\n' "$I:1.2.3-rc.1" "$I:latest")"
	pubtag 1 "refuses a tag on another image" false 1.2.3 false "$(printf '%s\n' "$I:1.2.3" "$I:1.2" "ghcr.io/evil/jarvis:latest")"
	pubtag 1 "refuses a missing tag" false 1.2.3 false "$(printf '%s\n' "$I:1.2.3" "$I:1.2")"
	pubtag 1 "refuses an empty digest" false 1.2.3 false "$REL_TAGS" ""
	pubtag 1 "refuses a digest that is not sha256" false 1.2.3 false "$REL_TAGS" "sha256:abc"
	pubtag 1 "refuses a tag that came out pointing elsewhere" false 1.2.3 false "$REL_TAGS" "$D1" "\"sha256:$(printf 'other' | sha256sum | cut -d' ' -f1)\""
	STUB_PLANNED='{"re-serialised":true}' pubtag 1 "refuses before tagging when create would write a different index" false 1.2.3 false "$REL_TAGS"
	if [ "$(grep -c '^buildx imagetools create -t' "${WORK}/docker.log")" = 0 ]; then
		ok "publish-docker: moves no tag when the planned index is not the smoked one"
	else
		no "publish-docker: moves no tag when the planned index is not the smoked one" "$(cat "${WORK}/docker.log")"
	fi
	pubtag 0 "on a dry run, validates and prints" true 1.2.3 false "$REL_TAGS"
	if [ ! -s "${WORK}/docker.log" ] && grep -qF "DRY RUN -- no tag created" "${WORK}/pub.out"; then
		ok "publish-docker: a dry run calls docker not at all"
	else
		no "publish-docker: a dry run calls docker not at all" "$(cat "${WORK}/docker.log")"
	fi
	pubtag 1 "a dry run still refuses wrong tags" true 1.2.3-rc.1 true "$(printf '%s\n' "$I:1.2.3-rc.1" "$I:latest")"
	: >"${WORK}/docker.log"
	pubtag 1 "refuses an empty digest without calling docker" false 1.2.3 false "$REL_TAGS" ""
	if [ ! -s "${WORK}/docker.log" ]; then ok "publish-docker: nothing reaches docker once the digest is refused"; else no "publish-docker: nothing reaches docker once the digest is refused" "$(cat "${WORK}/docker.log")"; fi

	# The pull.
	: >"${WORK}/docker.log"
	(cd "$WORK" && env -i PATH="${WORK}/dbin:$PATH" DOCKER_LOG="${WORK}/docker.log" GITHUB_REPOSITORY=Vierisid/Jarvis \
		DIGEST="$D1" GATE_IMAGE_TAG=jarvis:gate bash -e -c "$PULL") >"${WORK}/pull.out" 2>&1
	if [ "$(cat "${WORK}/docker.log")" = "$(printf '%s\n' "pull --platform linux/amd64 $I@$D1" "logout ghcr.io" "tag $I@$D1 jarvis:gate")" ]; then
		ok "smoke-image: pulls the amd64 image by digest, logs out, then tags it locally"
	else
		no "smoke-image: pulls the amd64 image by digest, logs out, then tags it locally" "$(cat "${WORK}/docker.log") / $(cat "${WORK}/pull.out")"
	fi
	: >"${WORK}/docker.log"
	if (cd "$WORK" && env -i PATH="${WORK}/dbin:$PATH" DOCKER_LOG="${WORK}/docker.log" GITHUB_REPOSITORY=o/r DIGEST="latest" GATE_IMAGE_TAG=jarvis:gate bash -e -c "$PULL") >/dev/null 2>&1 ||
		[ -s "${WORK}/docker.log" ]; then
		no "smoke-image: refuses a digest that is not sha256, before any pull"
	else
		ok "smoke-image: refuses a digest that is not sha256, before any pull"
	fi

	# The archive load, against a hand-built two-platform OCI layout.
	# make_layout [amd64 count]: writes ${WORK}/oci/release-image.oci.tar and
	# sets IDX (the index digest), CFG (the amd64 config digest), ARC (the
	# archive sha256).
	make_layout() {
		local n="${1:-1}" L="${WORK}/oci/l"
		rm -rf "${WORK}/oci" && mkdir -p "$L/blobs/sha256"
		put() { local h; h="$(printf '%s' "$1" | sha256sum | cut -d' ' -f1)"; printf '%s' "$1" >"$L/blobs/sha256/$h"; printf 'sha256:%s' "$h"; }
		local layer cfg man arm i entries=""
		layer="$(put 'layer bytes')"
		cfg="$(put '{"architecture":"amd64","os":"linux","rootfs":{"type":"layers","diff_ids":[]}}')"
		man="$(put "{\"schemaVersion\":2,\"config\":{\"digest\":\"$cfg\"},\"layers\":[{\"digest\":\"$layer\"}]}")"
		arm="$(put "{\"schemaVersion\":2,\"config\":{\"digest\":\"$cfg\"},\"layers\":[]}")"
		for i in $(seq 1 "$n"); do entries+="{\"digest\":\"$man\",\"platform\":{\"os\":\"linux\",\"architecture\":\"amd64\"}},"; done
		IDX="$(put "{\"schemaVersion\":2,\"manifests\":[${entries}{\"digest\":\"$arm\",\"platform\":{\"os\":\"linux\",\"architecture\":\"arm64\"}}]}")"
		CFG="$cfg"
		printf '{"manifests":[{"digest":"%s"}]}' "$IDX" >"$L/index.json"
		tar -cf "${WORK}/oci/release-image.oci.tar" -C "$L" index.json blobs
		ARC="$(sha256sum "${WORK}/oci/release-image.oci.tar" | cut -d' ' -f1)"
	}
	# run_load <want 0|1> <label> [STUB_ID]
	run_load() {
		local want="$1" label="$2"
		rm -rf "${WORK}/rt" && mkdir -p "${WORK}/rt/release-image"
		cp "${WORK}/oci/release-image.oci.tar" "${WORK}/rt/release-image/"
		: >"${WORK}/docker.log"
		(cd "$WORK" && env -i PATH="${WORK}/dbin:$PATH" DOCKER_LOG="${WORK}/docker.log" DOCKER_STATE="${WORK}/docker.state" \
			RUNNER_TEMP="${WORK}/rt" DIGEST="$IDX" ARCHIVE_SHA256="$ARC" GATE_IMAGE_TAG=jarvis:gate STUB_ID="${3:-}" \
			bash -e -c "$LOAD") >"${WORK}/load.out" 2>&1
		local rc=$?
		if { [ "$want" = 0 ] && [ "$rc" -eq 0 ]; } || { [ "$want" != 0 ] && [ "$rc" -ne 0 ]; }; then
			ok "smoke-image dry run: $label"
		else
			no "smoke-image dry run: $label" "exit ${rc}: $(cat "${WORK}/load.out")"
		fi
	}
	make_layout
	run_load 0 "loads the amd64 image of the reported index"
	if grep -q '^load -i ' "${WORK}/docker.log" && [ "$(cat "${WORK}/docker.state")" = "$CFG" ]; then
		ok "smoke-image dry run: what reaches docker load is exactly the amd64 config of that index"
	else
		no "smoke-image dry run: what reaches docker load is exactly the amd64 config of that index" "$(cat "${WORK}/docker.log")"
	fi
	make_layout
	ARC="$(printf 'other' | sha256sum | cut -d' ' -f1)"
	run_load 1 "refuses an archive other than the one build-image hashed"
	if ! grep -q '^load' "${WORK}/docker.log"; then ok "smoke-image dry run: nothing is loaded from a refused archive"; else no "smoke-image dry run: nothing is loaded from a refused archive"; fi
	make_layout
	IDX="sha256:$(printf 'not the index' | sha256sum | cut -d' ' -f1)"
	run_load 1 "refuses an archive without the reported index"
	make_layout 2
	run_load 1 "refuses an index with two amd64 images"
	make_layout
	run_load 1 "refuses a loaded image that is not the amd64 config" "sha256:$(printf 'x' | sha256sum | cut -d' ' -f1)"
	make_layout
	ARC=""
	run_load 1 "refuses an empty archive digest"
	# A tampered blob inside an archive whose outer digest was recomputed to
	# match: the archive check passes, the content checks must not.
	make_layout
	m_blob="$(find "${WORK}/oci/l/blobs/sha256" -type f -exec grep -l '"layers":\[{' {} +)"
	printf '%s' '{"schemaVersion":2,"config":{"digest":"sha256:0000000000000000000000000000000000000000000000000000000000000000"},"layers":[]}' >"$m_blob"
	tar -cf "${WORK}/oci/release-image.oci.tar" -C "${WORK}/oci/l" index.json blobs
	ARC="$(sha256sum "${WORK}/oci/release-image.oci.tar" | cut -d' ' -f1)"
	run_load 1 "refuses a manifest blob swapped inside a re-hashed archive"
fi

echo
echo "one dry-run decision, evaluated, in both release workflows (#685)"
SIDECAR_WORKFLOW="${SIDECAR_RELEASE_WORKFLOW:-${HERE}/../workflows/sidecar-release.yml}"
for f in "$WORKFLOW" "$SIDECAR_WORKFLOW"; do
	found="$(YQ_FILE="$f" yq dry-run)" || {
		no "$(basename "$f"): dry-run check ran" "the bun helper failed"
		continue
	}
	if [ -z "$found" ]; then
		ok "$(basename "$f"): every dry-run site reads inputs.dry_run == true and they agree on a push, a real dispatch and a dry dispatch"
	else
		no "$(basename "$f"): one dry-run decision" "$found"
	fi
done
# The evaluator against what GitHub gives (expression docs: mixed types
# compare as numbers, strings case-insensitively, && and || return an
# operand, ! binds tighter than ==). If it were wrong, the agreement check
# above could pass sites that disagree on GitHub.
# shellcheck disable=SC2016 # GitHub expressions, not shell.
for c in \
	'${{ inputs.dry_run == true }}@@null@@false' \
	'${{ inputs.dry_run == false }}@@null@@true' \
	'${{ inputs.dry_run == true }}@@true@@true' \
	"\${{ inputs.dry_run == 'true' }}@@true@@false" \
	"\${{ 'Release' == 'release' }}@@null@@true" \
	"\${{ inputs.dry_run && 'release-dry-run' || 'release' }}@@null@@\"release\"" \
	"\${{ inputs.dry_run && 'release-dry-run' || 'release' }}@@true@@\"release-dry-run\"" \
	'${{ !inputs.dry_run }}@@null@@true' \
	"\${{ !inputs.dry_run == 'release' }}@@false@@false" \
	'${{ !(inputs.dry_run == true) }}@@true@@false' \
	'${{ inputs.dry_run || false }}@@null@@false'; do
	expr="${c%%@@*}"
	rest="${c#*@@}"
	value="${rest%%@@*}"
	want="${rest#*@@}"
	got="$(EVAL_EXPR="$expr" EVAL_VALUE="$value" YQ_FILE="$WORKFLOW" yq dry-run)"
	if [ "$got" = "$want" ]; then
		ok "evaluator: ${expr} with dry_run=${value} is ${want}"
	else
		no "evaluator: ${expr} with dry_run=${value}" "got ${got}, GitHub gives ${want}"
	fi
done
# shellcheck disable=SC2016 # every mutant is literal workflow text.
{
	MUTANT_MODE=dry-run
	mutant 'discord-notify inverted, announcing only dry runs (#685)' \
		'    if: ${{ inputs.dry_run != true }}' '    if: ${{ inputs.dry_run }}'
	mutant 'DRY_RUN compared with the string, so a dry dispatch publishes (#685)' \
		'  DRY_RUN: ${{ inputs.dry_run == true }}' "  DRY_RUN: \${{ inputs.dry_run == 'true' }}"
	mutant 'the sidecar told a constant instead of the input (#685)' \
		'      dry_run: ${{ inputs.dry_run == true }}' '      dry_run: ${{ false }}'
	mutant 'the sidecar dry-run input dropped, so it defaults to a real publish (#685)' \
		$'    with:\n      dry_run: ${{ inputs.dry_run == true }}\n' ''
	mutant 'a real-run environment on a dry dispatch (#685)' \
		"      name: \${{ inputs.dry_run == true && 'release-dry-run' || 'release' }}" "      name: \${{ inputs.dry_run == false && 'release-dry-run' || 'release' }}"
	mutant 'an equivalent but second spelling of the decision (#685)' \
		'    if: ${{ inputs.dry_run != true }}' '    if: ${{ !inputs.dry_run }}'
	mutant 'a step deciding dry run from the event payload (#685)' \
		$'      - name: Dry-run summary\n        if: env.DRY_RUN == \'true\'\n        env:\n          VERSION:' \
		$'      - name: Dry-run summary\n        if: github.event.inputs.dry_run == \'true\'\n        env:\n          VERSION:'
	mutant 'a step testing DRY_RUN for truthiness, which "false" passes (#685)' \
		$'      - name: Dry-run summary\n        if: env.DRY_RUN == \'true\'\n        env:\n          VERSION:' \
		$'      - name: Dry-run summary\n        if: env.DRY_RUN\n        env:\n          VERSION:'
	mutant 'a script testing DRY_RUN some other way (#685)' \
		'if [ "$DRY_RUN" = "true" ]; then flags+=(--dry-run); fi' 'if [ "$DRY_RUN" != false ]; then flags+=(--dry-run); fi'
	mutant 'a job redefining DRY_RUN (#685)' \
		'      GATE_IMAGE_TAG: jarvis:release-gate-' $'      DRY_RUN: "false"\n      GATE_IMAGE_TAG: jarvis:release-gate-'
	MUTANT_FROM="$SIDECAR_WORKFLOW"
	mutant 'sidecar-release.yml: the env decision loosened to truthiness (#685)' \
		'  DRY_RUN: ${{ inputs.dry_run == true }}' '  DRY_RUN: ${{ inputs.dry_run || false }}'
	mutant 'sidecar-release.yml: the environment name inverted (#685)' \
		"      name: \${{ inputs.dry_run == true && 'release-dry-run' || 'release' }}" "      name: \${{ inputs.dry_run != true && 'release-dry-run' || 'release' }}"
	unset MUTANT_MODE MUTANT_FROM
}

echo
echo "sidecar-release.yml and installer-release.yml: no \${{ }} inside run: (#684, #818)"
# The reusable sidecar workflow runs in the same release, and its publish job
# holds id-token too. Its versions come from sidecar/VERSION rather than the
# tag, so the gate above does not cover them; the structure rule does. The
# installer release reads sidecar/installer/VERSION the same way, and its
# publish job holds contents: write (#818).
SIDECAR_WORKFLOW="${SIDECAR_RELEASE_WORKFLOW:-${HERE}/../workflows/sidecar-release.yml}"
INSTALLER_WORKFLOW="${INSTALLER_RELEASE_WORKFLOW:-${HERE}/../workflows/installer-release.yml}"
for f in "$SIDECAR_WORKFLOW" "$INSTALLER_WORKFLOW"; do
	found="$(YQ_FILE="$f" yq run-expressions)" || {
		no "$(basename "$f") run-expression check ran" "the bun helper failed"
		found=""
	}
	if [ -z "$found" ]; then
		ok "$(basename "$f"): every run: takes its values through env:"
	else
		no "$(basename "$f"): every run: takes its values through env:" "$found"
	fi
done
# run_expression_mutant <file> <exact text> <replacement>
run_expression_mutant() {
	local copy="${WORK}/run-expression-mutant.yml"
	rm -f "$copy"
	# shellcheck disable=SC2016 # JavaScript source, not shell.
	FROM="$1" TO="$copy" OLD="$2" NEW="$3" bun -e '
const s = await Bun.file(process.env.FROM).text();
if (!s.includes(process.env.OLD)) process.exit(2);
await Bun.write(process.env.TO, s.replace(process.env.OLD, process.env.NEW));
' || no "the $(basename "$1") mutant could be applied (the workflow no longer has the text it mutates)"
	if [ -f "$copy" ] && [ -n "$(YQ_FILE="$copy" yq run-expressions)" ]; then
		ok "reports: a \${{ }} expression back inside a $(basename "$1") run:"
	else
		no "reports: a \${{ }} expression back inside a $(basename "$1") run:"
	fi
}
# shellcheck disable=SC2016 # literal workflow text, not shell.
{
	run_expression_mutant "$SIDECAR_WORKFLOW" \
		'npm version "${VERSION}" --no-git-tag-version --allow-same-version' \
		'npm version "${{ needs.resolve.outputs.version }}" --no-git-tag-version --allow-same-version'
	run_expression_mutant "$INSTALLER_WORKFLOW" \
		'echo "::notice::DRY RUN -- built and signed installer v${INSTALLER_VERSION} without publishing"' \
		'echo "::notice::DRY RUN -- built and signed installer v${{ needs.resolve.outputs.version }} without publishing"'
}

echo
echo "sidecar artifacts cross into publish-sidecar with their digests (#781)"
found="$(YQ_FILE="$SIDECAR_WORKFLOW" yq sidecar-digests)" || {
	no "sidecar digest structure check ran" "the bun helper failed"
	found=""
}
if [ -z "$found" ]; then
	ok "every build leg and the signer output a digest taken last, and publish-sidecar checks all five first"
else
	no "sidecar artifact digests" "$found"
fi
# shellcheck disable=SC2016 # every mutant is literal workflow text.
{
	MUTANT_MODE=sidecar-digests
	MUTANT_FROM="$SIDECAR_WORKFLOW"
	mutant 'publish-sidecar no longer checking the artifacts it publishes (#781)' \
		'      - name: Verify sidecar artifacts' $'      - run: ls artifacts\n      - name: Verify sidecar artifacts'
	mutant 'one leg left out of the check (#781)' \
		'          SHA_LINUX_ARM64: ${{ needs.build-sidecar-linux-arm64.outputs.sha256 }}' ''
	mutant 'two legs crossed over in the check (#781)' \
		'          SHA_LINUX_ARM64: ${{ needs.build-sidecar-linux-arm64.outputs.sha256 }}' '          SHA_LINUX_ARM64: ${{ needs.build-sidecar-linux-x64.outputs.sha256 }}'
	mutant 'the signed Windows binary unchecked (#781)' \
		'          SHA_WIN32_X64: ${{ needs.sign-sidecar-windows.outputs.sha256 }}' ''
	mutant 'two legs back in one matrix, sharing one outputs block (#781 review)' \
		$'            npm_pkg: linux-x64\n            runner: ubuntu-latest\n            setup: linux\n' \
		$'            npm_pkg: linux-x64\n            runner: ubuntu-latest\n            setup: linux\n          - goos: linux\n            goarch: arm64\n            npm_pkg: linux-arm64\n            runner: ubuntu-24.04-arm\n            setup: linux\n'
	mutant 'a second matrix axis beside the one include entry, two legs again (#781 re-review)' \
		$'            npm_pkg: linux-x64\n            runner: ubuntu-latest\n            setup: linux\n' \
		$'            npm_pkg: linux-x64\n            runner: ubuntu-latest\n            setup: linux\n        shard: [a, b]\n'
	mutant 'a leg job whose output is not its digest step (#781)' \
		$'  build-sidecar-linux-arm64:\n    needs: resolve\n    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ${{ matrix.runner }}\n    permissions:\n      contents: read\n    outputs:\n      sha256: ${{ steps.digest.outputs.sha256 }}' \
		$'  build-sidecar-linux-arm64:\n    needs: resolve\n    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ${{ matrix.runner }}\n    permissions:\n      contents: read\n    outputs:\n      sha256: ${{ steps.other.outputs.sha256 }}'
	mutant 'publish-sidecar not waiting for one leg, so its digest reads empty (#781)' \
		' build-sidecar-darwin-x64, sign-sidecar-windows]' ' sign-sidecar-windows]'
	mutant 'the digest taken before the bundle is packaged (#781)' \
		'      # tar the bundle before upload' $'      - id: digest\n        run: "true"\n      # tar the bundle before upload'
	mutant 'the signer digest dropped, so the signed binary has none (#781)' \
		$'    outputs:\n      sha256: ${{ steps.digest.outputs.sha256 }}\n      # Whether the signing step ran, so verify-sidecar-windows' $'    outputs:\n      # Whether the signing step ran, so verify-sidecar-windows'
	mutant 'the artifact check switched off on its own (#781)' \
		$'      - name: Verify sidecar artifacts\n        env:' $'      - name: Verify sidecar artifacts\n        if: false\n        env:'
	mutant 'the artifact check allowed to fail (#781 review)' \
		$'      - name: Verify sidecar artifacts\n        env:' $'      - name: Verify sidecar artifacts\n        continue-on-error: true\n        env:'
	unset MUTANT_MODE MUTANT_FROM
}

# The check itself, executed verbatim against artifact fixtures.
VERIFY="$(YQ_FILE="$SIDECAR_WORKFLOW" yq step publish-sidecar 'Verify sidecar artifacts')" || VERIFY=""
if [ -z "$VERIFY" ]; then
	no "found publish-sidecar's 'Verify sidecar artifacts' step"
else
	# fixture: lay out the five artifacts as download-artifact does, and set
	# SUM_<LEG> to each digest.
	fixture() {
		rm -rf "${WORK}/pub" && mkdir -p "${WORK}/pub/artifacts"
		local leg file
		for leg in linux-x64:jarvis linux-arm64:jarvis darwin-arm64:jarvis-app.tar.gz darwin-x64:jarvis-app.tar.gz win32-x64:jarvis.exe; do
			file="${leg#*:}"
			leg="${leg%%:*}"
			mkdir -p "${WORK}/pub/artifacts/sidecar-${leg}"
			printf 'payload for %s\n' "$leg" >"${WORK}/pub/artifacts/sidecar-${leg}/${file}"
		done
		SUM_LINUX_X64="$(sha256sum "${WORK}/pub/artifacts/sidecar-linux-x64/jarvis" | cut -d' ' -f1)"
		SUM_LINUX_ARM64="$(sha256sum "${WORK}/pub/artifacts/sidecar-linux-arm64/jarvis" | cut -d' ' -f1)"
		SUM_DARWIN_ARM64="$(sha256sum "${WORK}/pub/artifacts/sidecar-darwin-arm64/jarvis-app.tar.gz" | cut -d' ' -f1)"
		SUM_DARWIN_X64="$(sha256sum "${WORK}/pub/artifacts/sidecar-darwin-x64/jarvis-app.tar.gz" | cut -d' ' -f1)"
		SUM_WIN32_X64="$(sha256sum "${WORK}/pub/artifacts/sidecar-win32-x64/jarvis.exe" | cut -d' ' -f1)"
	}
	# run_verify: run the step as the runner would; sets RC.
	run_verify() {
		(cd "${WORK}/pub" && env -i PATH="$PATH" SIDECAR_BIN=jarvis \
			SHA_LINUX_X64="$SUM_LINUX_X64" SHA_LINUX_ARM64="$SUM_LINUX_ARM64" \
			SHA_DARWIN_ARM64="$SUM_DARWIN_ARM64" SHA_DARWIN_X64="$SUM_DARWIN_X64" \
			SHA_WIN32_X64="$SUM_WIN32_X64" bash -c "$VERIFY") >"${WORK}/pub.log" 2>&1
		RC=$?
	}
	fixture
	run_verify
	if [ "$RC" -eq 0 ]; then
		ok "the artifact check passes the five artifacts the build jobs hashed"
	else
		no "the artifact check passes the five artifacts the build jobs hashed" "$(cat "${WORK}/pub.log")"
	fi
	# expect_refused <label> <::error:: text or empty>
	expect_refused() {
		run_verify
		if [ "$RC" -eq 0 ]; then
			no "the artifact check refuses ${1}" "exited 0: $(cat "${WORK}/pub.log")"
		elif [ -n "$2" ] && ! grep -qF "$2" "${WORK}/pub.log"; then
			no "the artifact check refuses ${1} with '${2}'" "$(cat "${WORK}/pub.log")"
		else
			ok "the artifact check refuses ${1}"
		fi
	}
	fixture
	printf 'swapped\n' >"${WORK}/pub/artifacts/sidecar-linux-arm64/jarvis"
	expect_refused "a leg replaced after its build hashed it" "FAILED"
	fixture
	printf 'swapped\n' >"${WORK}/pub/artifacts/sidecar-win32-x64/jarvis.exe"
	expect_refused "the signed Windows binary replaced after signing" "FAILED"
	fixture
	SUM_DARWIN_X64=""
	expect_refused "a leg that reported no digest" "::error::no digest was reported for sidecar-darwin-x64/jarvis-app.tar.gz"
	fixture
	mkdir -p "${WORK}/pub/artifacts/sidecar-evil" && printf 'x\n' >"${WORK}/pub/artifacts/sidecar-evil/jarvis"
	expect_refused "an extra sidecar-* artifact in the download" "not exactly the five"
	fixture
	printf 'x\n' >"${WORK}/pub/artifacts/sidecar-linux-x64/extra"
	expect_refused "an extra file inside a leg (Prepare copies the whole directory)" "not exactly the five"
	fixture
	rm "${WORK}/pub/artifacts/sidecar-darwin-arm64/jarvis-app.tar.gz"
	expect_refused "a missing artifact" "not exactly the five"
	fixture
	mv "${WORK}/pub/artifacts/sidecar-linux-x64/jarvis" "${WORK}/pub/real"
	ln -s "${WORK}/pub/real" "${WORK}/pub/artifacts/sidecar-linux-x64/jarvis"
	expect_refused "a link in place of a file" "other than files and directories"
	fixture
	tmp="$SUM_LINUX_X64"
	SUM_LINUX_X64="$SUM_LINUX_ARM64"
	SUM_LINUX_ARM64="$tmp"
	expect_refused "two legs digests crossed over" "FAILED"
fi
# The other three digest checks on the release path, executed verbatim too
# (#781 re-review): the structure rules see their shape, and only running
# them shows a tampered file actually stops the job.
# verbatim_case <label> <0|nonzero> <dir> <script> [VAR=value ...]
verbatim_case() {
	local label="$1" want="$2" dir="$3" script="$4"
	shift 4
	# bash -e, no pipefail: what GitHub runs for a step with no shell: key.
	(cd "$dir" && env -i PATH="$PATH" "$@" bash -e -c "$script") >"${WORK}/v.log" 2>&1
	local rc=$?
	if { [ "$want" = 0 ] && [ "$rc" -eq 0 ]; } || { [ "$want" != 0 ] && [ "$rc" -ne 0 ]; }; then
		ok "$label"
	else
		no "$label" "exit ${rc}: $(cat "${WORK}/v.log")"
	fi
}
# inbox_suite <job> <script> <inbox under RUNNER_TEMP> <file> <copies yes|no> [VAR=value ...]
# The signing inputs arrive in a directory of their own, not the checkout
# (#817 review): the script must take exactly that one regular file, by its
# digest, and copy nothing into the working directory when it refuses. An
# artifact that also carries scripts/sign-windows.sh is the attack this
# exists for.
inbox_suite() {
	local job="$1" script="$2" box="$3" file="$4" copies="$5"
	shift 5
	local d="${WORK}/inbox" sum
	reset_inbox() { rm -rf "$d" && mkdir -p "$d/rt/$box" "$d/cwd" && printf 'payload\n' >"$d/rt/$box/$file"; }
	reset_inbox
	sum="$(sha256sum "$d/rt/$box/$file" | cut -d' ' -f1)"
	verbatim_case "$job accepts the one file it was given the digest of" 0 "$d/cwd" "$script" SHA256="$sum" RUNNER_TEMP="$d/rt" "$@"
	if [ "$copies" = yes ]; then
		if cmp -s "$d/rt/$box/$file" "$d/cwd/$file"; then ok "$job copies the checked file into place"; else no "$job copies the checked file into place"; fi
	fi
	reset_inbox
	verbatim_case "$job refuses an empty digest" 1 "$d/cwd" "$script" SHA256= RUNNER_TEMP="$d/rt" "$@"
	reset_inbox
	printf 'swapped\n' >"$d/rt/$box/$file"
	verbatim_case "$job refuses a file replaced after it was hashed" 1 "$d/cwd" "$script" SHA256="$sum" RUNNER_TEMP="$d/rt" "$@"
	reset_inbox
	mkdir -p "$d/rt/$box/scripts" && printf 'evil\n' >"$d/rt/$box/scripts/sign-windows.sh"
	verbatim_case "$job refuses an artifact that also carries a replacement script" 1 "$d/cwd" "$script" SHA256="$sum" RUNNER_TEMP="$d/rt" "$@"
	if [ -e "$d/cwd/$file" ]; then no "$job copies nothing into place when it refuses"; else ok "$job copies nothing into place when it refuses"; fi
	reset_inbox
	mv "$d/rt/$box/$file" "$d/real" && ln -s "$d/real" "$d/rt/$box/$file"
	verbatim_case "$job refuses a link in place of the file" 1 "$d/cwd" "$script" SHA256="$sum" RUNNER_TEMP="$d/rt" "$@"
}
SIGNV="$(YQ_FILE="$SIDECAR_WORKFLOW" yq step sign-sidecar-windows 'Verify the binary')" || SIGNV=""
BRAINV="$(yq step publish-brain 'Verify the tarball')" || BRAINV=""
RELV="$(yq step github-release 'Verify sidecar binaries')" || RELV=""
if [ -z "$SIGNV" ] || [ -z "$BRAINV" ] || [ -z "$RELV" ]; then
	no "found the three remaining digest checks (sign-sidecar-windows, publish-brain, github-release)"
else
	inbox_suite sign-sidecar-windows "$SIGNV" unsigned jarvis.exe yes SIDECAR_BIN=jarvis
	d="${WORK}/v" && rm -rf "$d" && mkdir -p "$d/tmp/brain-pack" "$d/rel/artifacts/sidecar-linux-x64"

	tgz=usejarvis-brain-1.2.3.tgz
	printf 'tarball\n' >"$d/tmp/brain-pack/$tgz"
	tgz_sum="$(sha256sum "$d/tmp/brain-pack/$tgz" | cut -d' ' -f1)"
	verbatim_case "publish-brain accepts the tarball pack-brain hashed" 0 "$d" "$BRAINV" TARBALL="$tgz" SHA256="$tgz_sum" RUNNER_TEMP="$d/tmp"
	verbatim_case "publish-brain refuses an empty digest" 1 "$d" "$BRAINV" TARBALL="$tgz" SHA256= RUNNER_TEMP="$d/tmp"
	verbatim_case "publish-brain refuses a tarball name outside the package" 1 "$d" "$BRAINV" TARBALL="../evil.tgz" SHA256="$tgz_sum" RUNNER_TEMP="$d/tmp"
	printf 'swapped\n' >"$d/tmp/brain-pack/$tgz"
	verbatim_case "publish-brain refuses a tarball replaced after packing" 1 "$d" "$BRAINV" TARBALL="$tgz" SHA256="$tgz_sum" RUNNER_TEMP="$d/tmp"

	printf 'linux binary\n' >"$d/rel/artifacts/sidecar-linux-x64/jarvis"
	sums="$(cd "$d/rel/artifacts" && sha256sum ./sidecar-linux-x64/jarvis | base64 -w0)"
	verbatim_case "github-release accepts the binaries publish-sidecar published" 0 "$d/rel" "$RELV" SUMS="$sums"
	verbatim_case "github-release refuses when the sidecar reported no digests" 1 "$d/rel" "$RELV" SUMS=
	printf 'swapped\n' >"$d/rel/artifacts/sidecar-linux-x64/jarvis"
	verbatim_case "github-release refuses a binary replaced after publish-sidecar" 1 "$d/rel" "$RELV" SUMS="$sums"
fi
# The leg side, run as the runner would.
LEGDIGEST="$(YQ_FILE="$SIDECAR_WORKFLOW" yq step build-sidecar-darwin-arm64 digest)" || LEGDIGEST=""
if [ -z "$LEGDIGEST" ]; then
	no "found build-sidecar-darwin-arm64's digest step"
else
	rm -rf "${WORK}/leg" && mkdir -p "${WORK}/leg"
	printf 'a darwin bundle\n' >"${WORK}/leg/jarvis-app.tar.gz"
	: >"${WORK}/leg/out"
	(cd "${WORK}/leg" && env -i PATH="$PATH" GITHUB_OUTPUT="${WORK}/leg/out" FILE=jarvis-app.tar.gz LEG=darwin-arm64 bash -c "$LEGDIGEST") >/dev/null 2>&1
	want="sha256=$(sha256sum "${WORK}/leg/jarvis-app.tar.gz" | cut -d' ' -f1)"
	if [ "$(cat "${WORK}/leg/out")" = "$want" ]; then
		ok "a leg job writes exactly its own digest output"
	else
		no "a leg job writes exactly its own digest output" "got: $(cat "${WORK}/leg/out"); want: ${want}"
	fi
fi

echo
echo "installer-release.yml: the signer and the publisher take artifacts only by digest (#779)"
# The installer build was split from its signing like the sidecar (#779),
# so the unsigned installer crosses build-windows -> sign-windows, and the
# signed one and the DMG cross into publish, each by a job-output digest.
# Both checks executed verbatim against fixtures.
INSTALLER_WORKFLOW="${INSTALLER_RELEASE_WORKFLOW:-${HERE}/../workflows/installer-release.yml}"
found="$(YQ_FILE="$INSTALLER_WORKFLOW" yq installer-digests)" || {
	no "installer digest structure check ran" "the bun helper failed"
	found=""
}
if [ -z "$found" ]; then
	ok "build-windows, sign-windows and build-macos output a digest taken last, and each consumer checks the right one first"
else
	no "installer artifact digests" "$found"
fi
# shellcheck disable=SC2016 # every mutant is literal workflow text.
{
	MUTANT_MODE=installer-digests
	MUTANT_FROM="$INSTALLER_WORKFLOW"
	mutant 'publish checking the Windows installer against the UNSIGNED build digest (#779)' \
		'          SHA_WIN32_X64: ${{ needs.sign-windows.outputs.sha256 }}' '          SHA_WIN32_X64: ${{ needs.build-windows.outputs.sha256 }}'
	mutant 'publish not waiting for the signer, so its digest reads empty (#779)' \
		'    needs: [resolve, sign-windows, verify-windows, build-macos]' '    needs: [resolve, build-windows, verify-windows, build-macos]'
	mutant 'the DMG digest dropped from build-macos (#779)' \
		$'    outputs:\n      sha256: ${{ steps.digest.outputs.sha256 }}\n    steps:\n      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1\n        with:\n          persist-credentials: false\n      - uses: actions/setup-go@b7ad1dad31e06c5925ef5d2fc7ad053ef454303e # v7.0.0\n        with:\n          # The Actions cache is writable by any run on main, and Go reuses\n          # cached modules and build output without re-verifying them (#681).\n          cache: false\n          go-version-file: sidecar/go.mod\n          cache-dependency-path: sidecar/go.sum\n\n      - name: Build universal' \
		$'    steps:\n      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1\n        with:\n          persist-credentials: false\n      - uses: actions/setup-go@b7ad1dad31e06c5925ef5d2fc7ad053ef454303e # v7.0.0\n        with:\n          # The Actions cache is writable by any run on main, and Go reuses\n          # cached modules and build output without re-verifying them (#681).\n          cache: false\n          go-version-file: sidecar/go.mod\n          cache-dependency-path: sidecar/go.sum\n\n      - name: Build universal'
	mutant 'the signed digest taken before signing (#779)' \
		'      - name: Sign installer (Cloud KMS)' $'      - id: digest\n        run: "true"\n      - name: Sign installer (Cloud KMS)'
	mutant 'a matrix on the macOS installer build, sharing its digest output (#779 re-review)' \
		$'    runs-on: macos-latest\n    env:\n      HAVE_APPLE_SIGNING' $'    runs-on: macos-latest\n    strategy:\n      matrix:\n        include:\n          - arch: universal\n        shard: [a, b]\n    env:\n      HAVE_APPLE_SIGNING'
	mutant 'the signed digest step allowed to fail (#779 re-review)' \
		$'      # The SIGNED installer\'s digest: signing changes the bytes, and publish\n      # takes the artifact only by this.\n      - name: Digest\n        id: digest\n' $'      # The SIGNED installer\'s digest: signing changes the bytes, and publish\n      # takes the artifact only by this.\n      - name: Digest\n        id: digest\n        continue-on-error: true\n'
	mutant 'the publish check switched off on its own (#779)' \
		$'      - name: Verify the installers\n        env:' $'      - name: Verify the installers\n        if: false\n        env:'
	unset MUTANT_MODE MUTANT_FROM
}
SIGNCHECK="$(YQ_FILE="$INSTALLER_WORKFLOW" yq step sign-windows 'Verify the installer')" || SIGNCHECK=""
PUBCHECK="$(YQ_FILE="$INSTALLER_WORKFLOW" yq step publish 'Verify the installers')" || PUBCHECK=""
if [ -z "$SIGNCHECK" ]; then
	no "found installer-release.yml sign-windows step 'Verify the installer'"
else
	inbox_suite sign-windows "$SIGNCHECK" unsigned Jarvis-Setup.exe yes
	# The refusal names what was missing.
	rm -rf "${WORK}/inst" && mkdir -p "${WORK}/inst/rt/unsigned" "${WORK}/inst/cwd"
	(cd "${WORK}/inst/cwd" && env -i PATH="$PATH" SHA256= RUNNER_TEMP="${WORK}/inst/rt" bash -c "$SIGNCHECK") >"${WORK}/inst.log" 2>&1
	if grep -qF "::error::build-windows reported no digest" "${WORK}/inst.log"; then ok "sign-windows names a missing build-windows digest"; else no "sign-windows names a missing build-windows digest" "$(cat "${WORK}/inst.log")"; fi
fi
if [ -z "$PUBCHECK" ]; then
	no "found installer-release.yml publish step 'Verify the installers'"
else
	inst_fixture() {
		rm -rf "${WORK}/ipub" && mkdir -p "${WORK}/ipub/artifacts/installer-win32-x64" "${WORK}/ipub/artifacts/installer-darwin"
		printf 'signed exe\n' >"${WORK}/ipub/artifacts/installer-win32-x64/Jarvis-Setup.exe"
		printf 'dmg\n' >"${WORK}/ipub/artifacts/installer-darwin/Install-Jarvis.dmg"
		SUM_WIN="$(sha256sum "${WORK}/ipub/artifacts/installer-win32-x64/Jarvis-Setup.exe" | cut -d' ' -f1)"
		SUM_DMG="$(sha256sum "${WORK}/ipub/artifacts/installer-darwin/Install-Jarvis.dmg" | cut -d' ' -f1)"
	}
	pub_check() {
		(cd "${WORK}/ipub" && env -i PATH="$PATH" SHA_WIN32_X64="$SUM_WIN" SHA_DARWIN="$SUM_DMG" bash -c "$PUBCHECK") >"${WORK}/ipub.log" 2>&1
		RC=$?
	}
	# pub_refused <label> <expected text>
	pub_refused() {
		pub_check
		if [ "$RC" -ne 0 ] && grep -qF -- "$2" "${WORK}/ipub.log"; then
			ok "publish refuses ${1}"
		else
			no "publish refuses ${1} with '${2}'" "exit ${RC}: $(cat "${WORK}/ipub.log")"
		fi
	}
	inst_fixture
	pub_check
	if [ "$RC" -eq 0 ]; then ok "publish accepts the two installers their jobs hashed"; else no "publish accepts the two installers their jobs hashed" "$(cat "${WORK}/ipub.log")"; fi
	inst_fixture
	printf 'unsigned\n' >"${WORK}/ipub/artifacts/installer-win32-x64/Jarvis-Setup.exe"
	pub_refused "a Windows installer replaced after signing" "FAILED"
	inst_fixture
	printf 'other\n' >"${WORK}/ipub/artifacts/installer-darwin/Install-Jarvis.dmg"
	pub_refused "a DMG replaced after its build" "FAILED"
	inst_fixture
	SUM_DMG=""
	pub_refused "a DMG with no digest" "::error::no digest was reported for DARWIN"
	inst_fixture
	mkdir -p "${WORK}/ipub/artifacts/installer-evil" && printf 'x\n' >"${WORK}/ipub/artifacts/installer-evil/Jarvis-Setup.exe"
	pub_refused "an extra installer-* artifact" "not exactly the two"
	inst_fixture
	rm "${WORK}/ipub/artifacts/installer-darwin/Install-Jarvis.dmg"
	pub_refused "a missing DMG" "not exactly the two"
	inst_fixture
	tmp="$SUM_WIN"; SUM_WIN="$SUM_DMG"; SUM_DMG="$tmp"
	pub_refused "the two digests crossed over" "FAILED"
fi

echo
echo "post-sign verification runs without id-token, on what ships, before publishing (#817)"
for f in "$SIDECAR_WORKFLOW" "$INSTALLER_WORKFLOW"; do
	found="$(YQ_FILE="$f" yq postsign)" || {
		no "$(basename "$f"): post-sign check ran" "the bun helper failed"
		continue
	}
	if [ -z "$found" ]; then
		ok "$(basename "$f"): the signer defers, the verify job holds no token, checks the shipped digest, and gates the publish"
	else
		no "$(basename "$f"): post-sign verification" "$found"
	fi
done
# shellcheck disable=SC2016 # every mutant is literal workflow text.
{
	MUTANT_MODE=postsign
	MUTANT_FROM="$SIDECAR_WORKFLOW"
	mutant 'publish-sidecar not waiting for the signature check (#817)' \
		'    needs: [resolve, verify-sidecar-windows, build-sidecar-linux-x64,' '    needs: [resolve, build-sidecar-linux-x64,'
	mutant 'the sidecar signer verifying in place again, in the job holding id-token (#817)' \
		'scripts/sign-windows.sh --defer-verify "${SIDECAR_BIN}.exe"' 'scripts/sign-windows.sh "${SIDECAR_BIN}.exe"'
	mutant 'the sidecar signature check given id-token (#817)' \
		$'  verify-sidecar-windows:\n    needs: [resolve, sign-sidecar-windows]\n    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n' \
		$'  verify-sidecar-windows:\n    needs: [resolve, sign-sidecar-windows]\n    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n      id-token: write\n'
	mutant 'the sidecar signer reporting it never signs, so the check always skips (#817)' \
		'      signed: ${{ steps.winsign.outputs.ready }}' '      signed: "false"'
	mutant 'the sidecar signature check verifying an artifact other than the one that ships (#817)' \
		$'          name: sidecar-win32-x64\n          path: ${{ runner.temp }}/signed\n' $'          name: unsigned-win32-x64\n          path: ${{ runner.temp }}/signed\n'
	mutant 'the sidecar signature check job allowed to fail as a whole (#817 review)' \
		$'  verify-sidecar-windows:\n    needs: [resolve, sign-sidecar-windows]\n' $'  verify-sidecar-windows:\n    needs: [resolve, sign-sidecar-windows]\n    continue-on-error: true\n'
	mutant 'publish-sidecar running past a failed signature check (#817 review)' \
		$'    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n      id-token: write\n    outputs:\n      sums:' \
		$'    if: ${{ !cancelled() && needs.resolve.outputs.should_release == \'true\' }}\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n      id-token: write\n    outputs:\n      sums:'
	mutant 'the sidecar signature check job run under a condition of its own (#817 review)' \
		$'  verify-sidecar-windows:\n    needs: [resolve, sign-sidecar-windows]\n    if: needs.resolve.outputs.should_release == \'true\'\n' $'  verify-sidecar-windows:\n    needs: [resolve, sign-sidecar-windows]\n    if: always()\n'
	mutant 'the sidecar signature check relaxed to an untrusted chain (#817)' \
		$'          SIGN_REQUIRE_TRUSTED_CHAIN: "1"\n        run: |\n          if [ -z "${SIGNING_PUBLISHER_CN}" ]' $'          SIGN_REQUIRE_TRUSTED_CHAIN: "0"\n        run: |\n          if [ -z "${SIGNING_PUBLISHER_CN}" ]'
	MUTANT_FROM="$INSTALLER_WORKFLOW"
	mutant 'the installer publish not waiting for the signature check (#817)' \
		'    needs: [resolve, sign-windows, verify-windows, build-macos]' '    needs: [resolve, sign-windows, build-macos]'
	mutant 'the installer signature check against the UNSIGNED build digest (#817)' \
		'          SHA256: ${{ needs.sign-windows.outputs.sha256 }}' '          SHA256: ${{ needs.build-windows.outputs.sha256 }}'
	mutant 'the installer signature check switched off on its own (#817)' \
		$'      - name: Verify the Authenticode signature\n        if: needs.sign-windows.outputs.signed == \'true\'' $'      - name: Verify the Authenticode signature\n        if: false'
	mutant 'the installer signature check allowed to fail (#817)' \
		$'      - name: Verify the Authenticode signature\n        if: needs.sign-windows.outputs.signed == \'true\'' $'      - name: Verify the Authenticode signature\n        continue-on-error: true\n        if: needs.sign-windows.outputs.signed == \'true\''
	mutant 'the installer signature check given a write scope (#817)' \
		$'  verify-windows:\n    needs: [resolve, sign-windows]\n    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ubuntu-latest\n    permissions:\n      contents: read\n' \
		$'  verify-windows:\n    needs: [resolve, sign-windows]\n    if: needs.resolve.outputs.should_release == \'true\'\n    runs-on: ubuntu-latest\n    permissions:\n      contents: write\n'
	mutant 'the installer signature check run without its publisher pin (#817)' \
		$'          SIGNING_PUBLISHER_CN: ${{ vars.SIGNING_PUBLISHER_CN }}\n          # Sectigo' $'          # Sectigo'
	mutant 'the installer signer allowed to fail as a whole (#817 review)' \
		$'  sign-windows:\n    needs: [resolve, build-windows]\n' $'  sign-windows:\n    needs: [resolve, build-windows]\n    continue-on-error: true\n'
	mutant 'the installer publish running after a failure (#817 review)' \
		$'    needs: [resolve, sign-windows, verify-windows, build-macos]\n    if: needs.resolve.outputs.should_release == \'true\'' $'    needs: [resolve, sign-windows, verify-windows, build-macos]\n    if: always() && needs.resolve.outputs.should_release == \'true\''
	mutant 'the installer digest check made skippable (#817)' \
		$'      - name: Verify the signed installer digest\n' $'      - name: Verify the signed installer digest\n        if: false\n'
	unset MUTANT_MODE MUTANT_FROM
}
# The two digest checks, executed verbatim.
SIDEV="$(YQ_FILE="$SIDECAR_WORKFLOW" yq step verify-sidecar-windows 'Verify the signed binary digest')" || SIDEV=""
INSTV="$(YQ_FILE="$INSTALLER_WORKFLOW" yq step verify-windows 'Verify the signed installer digest')" || INSTV=""
if [ -z "$SIDEV" ] || [ -z "$INSTV" ]; then
	no "found the two post-sign digest checks (verify-sidecar-windows, verify-windows)"
else
	inbox_suite verify-sidecar-windows "$SIDEV" signed jarvis.exe no SIDECAR_BIN=jarvis
	inbox_suite verify-windows "$INSTV" signed Jarvis-Setup.exe no
fi

echo
echo "sink executed without the gate in front of it"
# The brain's `npm version` is the line #644 named (in publish-brain then,
# in pack-brain since #682 split the build out of the OIDC job). Run its
# script with a hostile VERSION in env and an npm stub that records its argv:
# the value must arrive as one literal argument and run nothing.
SINK="$(yq step pack-brain 'Set package version')" || SINK=""
if [ -z "$SINK" ]; then
	no "found pack-brain's 'Set package version' step"
else
	mkdir -p "${WORK}/bin"
	cat >"${WORK}/bin/npm" <<'EOF'
#!/usr/bin/env bash
printf '%s\n' "$@" >"$NPM_ARGV"
EOF
	chmod +x "${WORK}/bin/npm"
	rm -f "${WORK}/pwned"
	hostile="1.0.0\";touch ${WORK}/pwned;\"\$(touch ${WORK}/pwned)"
	env -i PATH="${WORK}/bin:$PATH" NPM_ARGV="${WORK}/argv" VERSION="$hostile" bash -c "$SINK" >/dev/null 2>&1
	first="$(head -n1 "${WORK}/argv" 2>/dev/null)"
	second="$(sed -n 2p "${WORK}/argv" 2>/dev/null)"
	if [ -e "${WORK}/pwned" ]; then
		no "the npm version step does not evaluate VERSION" "sentinel created"
	elif [ "$first" != "version" ] || [ "$second" != "$hostile" ]; then
		no "the npm version step passes VERSION as one literal argument" "argv was:
$(cat "${WORK}/argv" 2>/dev/null)"
	else
		ok "the npm version step passes a hostile VERSION as one literal argument and runs nothing"
	fi
fi

echo
echo "sidecar version gate (sidecar-release.yml resolve step, executed verbatim)"
# #684. The sidecar version comes from sidecar/VERSION, not the tag, so the
# gate above never sees it. resolve now checks it before it becomes an output;
# run that script against hostile file contents (dry run, so it never reaches
# npm) and check what reaches $GITHUB_OUTPUT.
RESOLVE="$(YQ_FILE="$SIDECAR_WORKFLOW" yq step resolve v)" || RESOLVE=""
if [ -z "$RESOLVE" ]; then
	no "found sidecar-release.yml's resolve step"
else
	# sidecar_resolve <file contents>: sets RC and OUT.
	# sidecar_resolve <file contents> [locale]
	sidecar_resolve() {
		rm -rf "${WORK}/sc" && mkdir -p "${WORK}/sc/sidecar"
		printf '%s' "$1" >"${WORK}/sc/sidecar/VERSION"
		: >"${WORK}/sc/out"
		local -a envs=(PATH="$PATH" GITHUB_OUTPUT="${WORK}/sc/out" DRY_RUN=true)
		[ -n "${2:-}" ] && envs+=(LC_ALL="$2" LANG="$2")
		(cd "${WORK}/sc" && env -i "${envs[@]}" bash -c "$RESOLVE") >"${WORK}/sc/log" 2>&1
		RC=$?
		OUT="$(cat "${WORK}/sc/out")"
	}
	for v in 0.10.0 $'0.10.0\n' 1.2.3-rc.1 1.2.3-alpha-1.beta.11 10.20.30; do
		sidecar_resolve "$v"
		# The file normally ends in a newline, which $(cat) drops.
		if [ "$RC" -eq 0 ] && [ "$OUT" = "$(printf 'version=%s\nshould_release=true' "${v%$'\n'}")" ]; then
			ok "sidecar resolve accepts $(printf '%q' "$v")"
		else
			no "sidecar resolve accepts $(printf '%q' "$v")" "exit ${RC}; output: ${OUT}; log: $(cat "${WORK}/sc/log")"
		fi
	done
	for v in '' '1.2' '01.2.3' '1.2.3+build' $'1.2.3\nshould_release=false' "1.2.3\$(touch ${WORK}/pwned)" \
		"1.2.3\";touch ${WORK}/pwned;\"" '1.2.3|x' '1.2.3/x' '1.2.3-' "1.2.3-rc.1 " '1.2.3-01' '1.2.3-rc..1'; do
		rm -f "${WORK}/pwned"
		sidecar_resolve "$v"
		if [ "$RC" -ne 0 ] && [ -z "$OUT" ] && [ ! -e "${WORK}/pwned" ] && grep -qF '::error::sidecar/VERSION is not a plain semver' "${WORK}/sc/log"; then
			ok "sidecar resolve rejects $(printf '%q' "$v") without writing outputs"
		else
			no "sidecar resolve rejects $(printf '%q' "$v")" "exit ${RC}; output: ${OUT}; log: $(cat "${WORK}/sc/log")"
		fi
	done
	# Under a UTF-8 locale glibc's [A-Za-z] and [0-9] match more than ASCII;
	# the step pins LC_ALL=C, as the tag gate does.
	if [ -z "$UTF8_LOCALE" ]; then
		echo "  skip - no en_US.UTF-8 locale on this machine, so the sidecar locale fixtures cannot run"
	else
		for v in $'1.2.3-\u00e9' $'\u0661.2.3' $'1.2.3-\uff41'; do
			sidecar_resolve "$v" "$UTF8_LOCALE"
			if [ "$RC" -ne 0 ] && [ -z "$OUT" ]; then
				ok "sidecar resolve rejects $(printf '%q' "$v") under ${UTF8_LOCALE}"
			else
				no "sidecar resolve rejects $(printf '%q' "$v") under ${UTF8_LOCALE}" "exit ${RC}; output: ${OUT}"
			fi
		done
	fi
fi

echo
echo "installer version gate (installer-release.yml resolve step, executed verbatim) (#818)"
# The installer version comes from sidecar/installer/VERSION, which no tag gate
# sees. resolve checks it before it becomes an output, as the sidecar resolve
# does (#684); run that script against hostile file contents and check what
# reaches $GITHUB_OUTPUT. A stub gh answers "not released" for the real-run
# cases, so nothing here touches the network.
IRESOLVE="$(YQ_FILE="$INSTALLER_WORKFLOW" yq step resolve v)" || IRESOLVE=""
if [ -z "$IRESOLVE" ]; then
	no "found installer-release.yml's resolve step"
else
	mkdir -p "${WORK}/ibin"
	printf '#!/usr/bin/env bash\nexit 1\n' >"${WORK}/ibin/gh"
	chmod +x "${WORK}/ibin/gh"
	# installer_resolve <file contents> [event] [ref name] [dry run] [locale]: sets RC and OUT.
	installer_resolve() {
		rm -rf "${WORK}/ir" && mkdir -p "${WORK}/ir/sidecar/installer"
		printf '%s' "$1" >"${WORK}/ir/sidecar/installer/VERSION"
		: >"${WORK}/ir/out"
		local -a envs=(PATH="${WORK}/ibin:$PATH" GITHUB_OUTPUT="${WORK}/ir/out" GITHUB_REPOSITORY=o/r
			GITHUB_EVENT_NAME="${2:-workflow_dispatch}" GITHUB_REF_NAME="${3:-main}" DRY_RUN="${4:-true}")
		[ -n "${5:-}" ] && envs+=(LC_ALL="$5" LANG="$5")
		(cd "${WORK}/ir" && env -i "${envs[@]}" bash -e -c "$IRESOLVE") >"${WORK}/ir/log" 2>&1
		RC=$?
		OUT="$(cat "${WORK}/ir/out")"
	}
	for v in 0.3.0 $'0.3.0\n' 1.2.3-rc.1 1.2.3-alpha-1.beta.11 10.20.30; do
		installer_resolve "$v"
		if [ "$RC" -eq 0 ] && [ "$OUT" = "$(printf 'version=%s\nshould_release=true' "${v%$'\n'}")" ]; then
			ok "installer resolve accepts $(printf '%q' "$v")"
		else
			no "installer resolve accepts $(printf '%q' "$v")" "exit ${RC}; output: ${OUT}; log: $(cat "${WORK}/ir/log")"
		fi
	done
	for v in '' '1.2' '01.2.3' '1.2.3+build' $'1.2.3\nshould_release=true' $'1.2.3\nversion=9.9.9' "1.2.3\$(touch ${WORK}/pwned)" \
		"1.2.3\";touch ${WORK}/pwned;\"" '1.2.3|x' '1.2.3/x' '1.2.3-' "1.2.3-rc.1 " '1.2.3-01' '1.2.3-rc..1' $'1.2.3\n::warning::injected'; do
		rm -f "${WORK}/pwned"
		installer_resolve "$v"
		if [ "$RC" -ne 0 ] && [ -z "$OUT" ] && [ ! -e "${WORK}/pwned" ] && grep -qF '::error::sidecar/installer/VERSION is not a plain semver' "${WORK}/ir/log" &&
			[ "$(grep -c '^::' "${WORK}/ir/log")" -eq 1 ]; then
			ok "installer resolve rejects $(printf '%q' "$v") without writing outputs"
		else
			no "installer resolve rejects $(printf '%q' "$v")" "exit ${RC}; output: ${OUT}; log: $(cat "${WORK}/ir/log")"
		fi
	done
	# A tag push must name the version in the file; it is compared only once
	# the file has passed the check above.
	installer_resolve 1.2.3 push installer-v1.2.3 false
	if [ "$RC" -eq 0 ] && [ "$OUT" = "$(printf 'version=1.2.3\nshould_release=true')" ]; then
		ok "installer resolve accepts a tag push that matches the file"
	else
		no "installer resolve accepts a tag push that matches the file" "exit ${RC}; output: ${OUT}; log: $(cat "${WORK}/ir/log")"
	fi
	installer_resolve 1.2.3 push installer-v1.2.4 false
	if [ "$RC" -ne 0 ] && grep -qF 'does not match sidecar/installer/VERSION' "${WORK}/ir/log" && ! grep -q '^should_release=' "${WORK}/ir/out"; then
		ok "installer resolve refuses a tag push that does not match the file"
	else
		no "installer resolve refuses a tag push that does not match the file" "exit ${RC}; output: ${OUT}; log: $(cat "${WORK}/ir/log")"
	fi
	if [ -z "$UTF8_LOCALE" ]; then
		echo "  skip - no en_US.UTF-8 locale on this machine, so the installer locale fixtures cannot run"
	else
		for v in $'1.2.3-é' $'١.2.3' $'1.2.3-ａ'; do
			installer_resolve "$v" workflow_dispatch main true "$UTF8_LOCALE"
			if [ "$RC" -ne 0 ] && [ -z "$OUT" ]; then
				ok "installer resolve rejects $(printf '%q' "$v") under ${UTF8_LOCALE}"
			else
				no "installer resolve rejects $(printf '%q' "$v") under ${UTF8_LOCALE}" "exit ${RC}; output: ${OUT}"
			fi
		done
	fi
fi

echo
echo "${pass} passed, ${fail} failed"
[ "$fail" -eq 0 ]
