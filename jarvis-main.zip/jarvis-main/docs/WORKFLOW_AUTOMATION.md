# Jarvis Workflow Automation

A contributor-facing guide to the workflow system: what it is, how it runs, and where every moving part lives. Read this before touching anything under `src/workflows/`.

> **Heads up:** this system was rewritten from scratch on the `feat/workflows` branch. The old in-process executor, the 50-node hand-rolled registry, and `src/vault/workflows.ts` are gone. The runtime now sits on a vendored copy of the [Activepieces](https://github.com/activepieces/activepieces) engine spawned as a sandboxed child process. If you find a doc or comment that still describes "topo sort + self-heal + NLBuilder", it's stale; refer to this file.

## Reading order

A new contributor should read these, in order:

1. This file -- the architecture overview and the source-tree map.
2. [`PIECE_VERIFICATION.md`](./PIECE_VERIFICATION.md) -- the end-to-end "is my piece wired correctly" checklist. Required reading before adding or editing any piece.
3. [`src/workflows/activepieces/UPSTREAM.md`](../src/workflows/activepieces/UPSTREAM.md) -- which upstream commit we vendor, the license posture, and what we deliberately exclude.
4. [`src/workflows/pieces-library/README.md`](../src/workflows/pieces-library/README.md) -- how community pieces are curated, signed off, and installed at runtime.

Looking for why a workflow step's tool result is not wrapped in the
untrusted-content delimiters the way a chat turn's is? See
[A step's tool result is NOT framed as untrusted content](#a-steps-tool-result-is-not-framed-as-untrusted-content).

## What this is

The workflow runtime lets a user describe an automation (in natural language or visually), persist it as a versioned flow, and execute it on a schedule, on a webhook, or on demand. Every flow is a tree of steps. Every step is either an action or a trigger from a piece. A piece is a self-contained npm package that ships an action's `run()` function and the JSON-schema for its inputs.

The runtime guarantees:

- Steps run inside an engine subprocess, never in the daemon's main loop.
- Step output is checkpointed; a paused flow survives daemon restarts via a zstd execution-state backup.
- Connection secrets are encrypted at rest with AES-256-GCM.
- Every piece's metadata (props, output sample, auth shape) is extracted directly from its compiled bundle, not from a hand-maintained registry.

What it deliberately is NOT:

- Not multi-tenant. One daemon, one user. No projects table: every row carries the constant `DEFAULT_IDS.project` (`jrv_proj_default`).
- Not distributed. The job queue is SQLite-backed; the worker concurrency is 1 by default.
- Not a marketplace. The set of installable pieces is the curated catalog under `src/workflows/pieces-library/` plus the Jarvis-authored pieces in the vendored tree. Users cannot side-load arbitrary npm packages.

## Upgrade notes

### Workflow effects now pass an Authority boundary

Every `/v1/jarvis/*` call a step makes -- `tools`, `notify`, `agent`, `workflows`,
`context` and `llm` -- goes through a daemon-owned gate before it dispatches.
Practical consequences:

- A denied Authority category, an emergency pause, or an emergency kill stops the
  step instead of letting it run. The failure names the category that blocked it.
- A category the user put under approval parks the run at a waitpoint and delivers
  an approval request. The run resumes on approval and fails on denial or expiry.
  This is why `jarvis-context` reads can now answer `202` instead of `200`.
- Each effect is recorded in `workflow_effect` with its frozen arguments, target,
  decision and outcome, readable at `GET /api/workflow-runs/:runId/effects`.
- A tool that fails reports a typed outcome rather than a result that happens to
  read like an error: `blocked` (a known prerequisite, e.g. the machine is
  offline) answers `409`, `error` (the remote handler reported failure) `422`,
  and `unknown` (completion could not be established) `502`. `jarvis-tool`
  requires success by default and asserts the outcome itself, so an HTTP `200`
  alone cannot satisfy a step. Clearing its `Require successful action` box is
  for an explicit availability probe: the call answers `200` with the unchanged
  failure outcome so the graph can route on `{{step.outcome.status}}` or its
  stable `code`. It changes how the reply is reported, never what is dispatched,
  and it does not bypass Authority, emergency state, cancellation or approval.
  Every one of these is a terminal receipt: repeating the step, or restarting
  the daemon, returns the same failure without dispatching again.
- `jarvis-tool` only invokes tools with a bounded, declared Authority action (see
  `BOUNDED_TOOLS` in `src/workflows/runtime/effect-capabilities.ts`). Tools whose
  effect is a script or a click sequence -- `run_command`, `browser_click`,
  `desktop_type` and friends -- need a typed `ToolDefinition.workflowEffect`
  adapter first. A flow that called one of those directly now fails with
  "Unsupported direct workflow capability".
- `run_skill` is the one click sequence a flow may invoke, because a skill is
  reviewed content with its own per-step classification (`GATED_TOOLS` in the
  same file). A step `{ toolName: "run_skill", params: { name, params } }` is
  gated on every category the skill's stored steps reach, worst case first (a
  click on Send in a mail app is `send_email`); the approval card reads what
  will actually happen with the resolved parameter values; the effect target
  records the skill's name and version and pins the run to one machine, so a
  skill re-recorded after review, or a different computer, blocks dispatch. A
  skill that cannot run (unknown, disabled, integrity failed, bad parameters)
  is a `blocked` outcome with nothing started; a skill that stops part way is
  an `error` outcome whose earlier steps may have run. Recording and deleting
  skills stay chat-side.
- Community pieces are unaffected by the gate: they run in the engine and never
  reach the daemon's tool surface. See `Governed pieces` below for the verified
  ten, and `src/workflows/pieces-library/README.md` for the curation path.

### A step's tool result is NOT framed as untrusted content

In a chat turn, a tool that reads outside content has its result wrapped in the
untrusted-content delimiters (`markUntrustedToolResult`, `src/roles/untrusted.ts`)
and most of those tools also taint the turn, so the next governed action needs
approval. A `jarvis-tool` step does neither. That is a decision (#573), not an
oversight.

Eight of the tools a step can name are untrusted sources: `read_file`,
`get_clipboard`, `browser_snapshot`, `browser_screenshot`, `desktop_snapshot`,
`desktop_find_element`, `desktop_list_windows` and `run_skill`. None is framed
on this path.

Worth knowing that framing them would have meant two entry points, not one:
`browser_screenshot` returns text and image content blocks rather than a string,
and `markUntrustedToolResult` is string-only -- the chat path frames that shape
through `markUntrustedToolBlocks`. (`capture_screen` and `desktop_screenshot` are
reachable and return blocks too, but are not untrusted sources even in chat.) The
decision declines both entry points deliberately.

**The rule is: frame where content enters a MODEL's context, not where it leaves
a tool.** In a chat turn those are the same place, which is why the framing sits
on the tool, and why reasoning across by analogy feels right. In a workflow they
come apart -- a step's result goes into the flow graph as **data**, read by
`{{ }}` expressions and by other steps -- so framing the tool boundary here puts
the frame in the one place with no model behind it. `src/goals/rhythm.ts` already
does it the other way round for workflow content: it frames a failed step's error
message at the **prompt**, and says so in its own note.

Framing the data plane would not be a cost paid for safety, it would be silent
corruption:

- `read_file` -> `write_file` in a flow would write the preamble and delimiters
  **into the file**, deterministically, every run, unattended. The chat path
  accepts a weaker form of this (see `wrapUntrusted`) only because a model
  re-renders the content and a person is watching.
- Any step routing on file or clipboard contents breaks.
- **The author could not repair it.** `{{ }}` is a data interpreter with no
  method calls -- `safe-expression.ts` rejects any call expression with
  "function calls or other executable syntax" -- so there is no supported way to
  strip a preamble from a string. The only escape is a `CODE` step, which runs
  arbitrary JavaScript with this machine's privileges and is off by default. So
  framing would push flow authors to enable code execution in order to clean up
  a mitigation.
- The value is also merged into `flow_version.sample_data` after a successful run
  and replayed as step **input** for test-from-here runs, so a frame would reach
  future runs' inputs, not just this one's replay.

Against that, the benefit is the weakest form of the chat benefit: there is no
taint gate on this path, and the approval card that does exist reviews the frozen
**arguments** before dispatch, so it never sees a result.

**What is protected.** The other *tool-result* route from an untrusted source
into a workflow -- a delegated sub-agent (`jarvis-agent`) -- is fully covered:
tool calls made
inside the sub-agent are framed by `sub-agent-runner.ts`, taint is recorded per
call, carried across checkpoints by `m7-agent-delegator.ts` and persisted on the
delegation row, and a taint-gated call in a workflow delegation becomes a durable
pause rather than a silent pass. So a workflow does have a framing-and-taint
path; it is the agent path, and the unframed adapter path is the data path.

**What a step CAN still do.** `browser_navigate` and `run_command` are refused as
opaque, but `run_skill` is admitted as a governed adapter and a recorded skill
step may `navigate` with a caller-supplied value. A flow can therefore point the
browser somewhere and read the page with a following `browser_snapshot`; it is
gated rather than refused -- by an approval card when the resolved category is
above the run's authority floor, so a permissive configuration may dispatch it
with no card. And the webhook trigger ingress is public and unauthenticated by
design, so `{{trigger.*}}` is attacker-influenceable and flows into tool
parameters and prompts.

**Corrections to #573's own premises**, since a reader coming from the issue will
hit all four:

- `ui_snapshot` is listed there as reachable. It is not -- nor is `ui_act`, which
  is an untrusted source in chat and would be the obvious next request. Neither is
  in `BOUNDED_TOOLS` or `GATED_TOOLS` and neither declares a `workflowEffect`, so
  `toolEffectCapability` refuses both. The reachable set is the 14 names in
  `untrusted-reach.test.ts`, of which 8 are untrusted sources.
- "Nothing in `src/workflows/` imports from `src/roles/untrusted.ts` at all" is
  stale: #567 added two importers, `adapters/tool-registry.ts` and
  `runtime/service-backends.ts`.
- "A workflow has no approval card mid-run" is false: the effect boundary creates
  a real approval request with `executionMode: 'workflow'` and a MANUAL
  waitpoint, and `/v1/jarvis/tools/invoke` answers 202 while the step waits. The
  true and narrower point is that the card reviews the frozen **arguments**
  before dispatch, so it never sees a result -- framing still buys no gate, just
  not for the stated reason.
- "No taint gate" is true of this path only. The delegation path has a full one,
  described above.

**Still open, and NOT yet filed as their own issues** -- do that before relying on
this section:

- An author-composed `jarvis-ask` prompt interpolating `{{step.result}}` (or
  `{{trigger.*}}`) sends outside content to a model unframed. The fix is at the
  prompt boundary with provenance, and provenance does not survive the sandbox
  today.

*(A third item stood here -- `withInstructions` burning its redelivery TTL on a
process-wide singleton, so a workflow `browser_snapshot` suppressed the webapp
playbook for the chat model. It was filed as #586 and is fixed; the delivery
tracker is scoped, and this path runs with delivery off. See the note below.)*

Both premises this decision rests on -- the reachable tool set, and the list of
readers that carry step output out of the data plane -- are pinned by
`src/workflows/adapters/untrusted-reach.test.ts`, derived from source. Widening
either fails that test and sends you back to this section.

One related correctness note: the adapter **drops** a carrier's trusted trailer
rather than concatenating it. A trailer is repo-authored instructions to a model
(the webapp template playbook, reachable here via `browser_snapshot`), and a flow
has no model to read one, so concatenating would write the playbook into files by
the same route as above and would put page text directly against repo-authored
instructions with no boundary between them. It also removes #572's lever from the
workflow data plane as a side effect: the template is chosen by regexing
page-controlled text for a URL, so a page could influence *which* playbook was
attached, and now none is.

And the step runs with site-playbook delivery **off** (#586), which is the other
half of that same decision. Dropping the trailer keeps the playbook away from a
consumer that cannot use it, but a delivery is recorded when the tool *offers*
one, and the tracker's 30-minute memory is shared with the chat model: one
`ToolRegistry` is built at daemon startup and the module-level browser tools go
into it, so a workflow step, every chat conversation, the approval executor and
every delegated sub-agent all held the same memory. A step's snapshot therefore
used to leave the chat model with no playbook for the next half hour -- one
context silently suppressing another's prompt content, which is the defect
whichever way round it happens. A workflow step now counts as **no scope at
all**: `actions/tools/template-delivery-scope.ts` is entered at the adapter, and
`withInstructions` checks it before it resolves a template and before it records
anything, so the step cannot spend a slot it was never going to use.

A workflow AGENT step is not a workflow tool step: it is a sub-agent with its own
model reading its own results, so its **non-governed** reads deliver under that
run's own scope (`browser_snapshot` takes no approval card). A **governed**
dispatch is different -- it crosses the durable effect boundary, which collapses
the carrier into one string for the receipt, so it is suppressed there for the
same reason the approval executor is. Since `browser_navigate` is always governed
(`authority/ui-intent.ts`), a workflow agent step's playbook arrives with its
first snapshot rather than with its navigation.

One upgrade wrinkle from that drop: a `sample_data` cell captured before this
change still holds the old concatenated page-plus-playbook value, and
`mergeRunOutputsIntoSampleData` only fills cells that are currently empty, so it
is not backfilled. An existing flow's test-from-here run therefore replays the
playbook-laden value as step input until that cell is cleared, while its live runs
produce the page alone. Nothing is corrupted; the two just differ.

That wrinkle survives #582 and is now disclaimed rather than silent. A
pre-#581 cell reaches the chat model inside a framed block like any other
captured output, so the stale playbook it carries is presented as data -- the
safe direction by this module's own polarity, since a disclaimed playbook only
loses a playbook. It is still not backfilled.

### The chat tool frames what it hands the model (#582)

The three `manage_workflow` READ actions that carry captured step output --
`get_run` (`steps`), `list_runs` (`failedStep`, which carries a failing skill's
on-screen field text) and a plain `get` (`sample_data`, riding inside the whole
`FlowVersion`) -- each return **one framed block wrapping that action's JSON**.
This is the model boundary the decision above defers the frame to, and
`goals/rhythm.ts` is the shape it follows.

Four things about it are load bearing:

- **One block per action, not `wrapUntrusted` per field.** `list_runs` returns
  25 runs by default, each with its own `failedStep`; an empty block costs 229
  characters of preamble and delimiters with a one-character label, and 267 with
  the label this action passes, so 25 of them come to ~6,675 before a single
  character of payload -- past the 6000-character dispatch cap. And a framed
  block used as a JSON field *value* is escaped by `JSON.stringify`, which costs
  the delimiters their own lines -- the nonce still holds, but the boundary stops
  being visible.
- **The payload is capped inside the tool.** Every dispatch caps a tool result at
  `MAX_TOOL_RESULT_CHARS` (6000) *before* framing it, which is what normally
  keeps a block whole. A tool that frames its own return inverts that order, so
  the cap would slice the closing delimiter off the end and leave the model an
  unterminated block -- worse than the bug. `FRAMED_PAYLOAD_MAX_CHARS` in
  `actions/tools/manage-workflow.ts` keeps the whole return clear of it, and a
  test reads both copies of `MAX_TOOL_RESULT_CHARS` out of the source and
  asserts the real return of each framed read stays within the smaller one --
  so the dispatch never enters its slice branch at all, and lowering or
  renaming either constant fails that test.

  Two costs of capping here, worth knowing before raising it: the effective
  budget for these reads drops from 6,000 to 4,000 characters, and a truncated
  payload is no longer valid JSON. Capping the captured-output *fields* before
  `JSON.stringify` (per-field *capping*, which is not the per-field *framing*
  rejected above) would keep the document parseable inside one block; it is not
  done today.
- **Framed at read time, so the run record and `sample_data` never gain a
  marker.** Markers carry a per-message nonce (#567), and a framed string
  written into either would replay a stale nonce as step input forever. That is
  the claim, and it is deliberately narrower than "nothing persists one": the
  delegation effect record does (a `jarvis-agent` step's sub-agent may call this
  tool, since `runtime/service-backends.ts` refuses only opaque and gated names,
  and `runtime/effect-boundary.ts` saves the result for replay), and so does
  `tasks.paused_conversation`. Both are benign -- each replays one complete
  block with one nonce, so nothing is reused for a different block, and the
  payload's author never learns the nonce drawn after it.
- **No `UNTRUSTED_TOOL_NAMES` change**, so `outsideReach`, `FRAMED_ACTORS` and
  the tool filter's I1 union repair are untouched, and `manage_workflow` stays at
  reach `fetch`. Taint was decided separately and **against**: these are reads of
  stored data, `isTaintSourceTool` keys on the tool NAME (one name over eleven
  actions, so the reads cannot be tainted without tainting `publish` and
  `delete`), the approval card reviews frozen arguments and never sees a result,
  and a card on every workflow read is exactly the frequency problem
  `TAINT_EXEMPT_TOOLS` exists for.

### The other six actions frame the same way (#598)

The two boundaries #582 enumerated and left open are now closed, and they were
the more routine exposure of the two.

`summarizeFlow`'s `metadata` and `name` ride on `list`, `create`, `enable`,
`disable`, `publish` and `compose`. `metadata` is a raw `JSON.parse` of a column
that `workflows/api/routes.ts` wrote unvalidated and uncapped (bounded since by
#598, and a run's `triggeredBy` and `environment` by #649), so whatever an API caller put there arrived as
trusted-looking tool output on every `list` -- a far more frequent call than
`get_run`. `name` is a `displayName`, and not simply operator-written either:
two of its three writers were that same uncapped `POST /api/workflows` body and
the composer LLM's own `displayName` on `compose`.

All six now return **one framed block wrapping the action's JSON**, which is
#582's shape unchanged and makes the per-field question moot -- the whole
document is inside the block however each field was written. Nine of the eleven
actions frame now. It subsumes, for free, the three lower-value boundaries #582
deferred (`publish`'s `warnings`, `compose`'s `errors` / `rawResponse`) plus one
it did not enumerate at all: `compose`'s `suggestedInstalls`, whose
`displayName` is third-party package metadata from the community piece catalog.

Taint stays **against** and `UNTRUSTED_TOOL_NAMES` is **unchanged**, for #582's
reasons exactly; `manage_workflow` stays at reach `fetch`.

Three things about #598 are load bearing beyond the frame itself:

- **Both caller-written fields are capped at both ends.** On the way in, the
  write routes reject a `metadata` that is not an object, carries a top-level
  `__proto__` / `constructor` / `prototype` key, or exceeds 16 KB, and reject a
  `displayName` that is not a non-empty string or exceeds 512 characters. All of
  that is close to free, because no shipped caller writes `metadata` at all (the
  dashboard POSTs `{ displayName }`, PATCHes `{ status }`, and keeps its editor
  state in `flow_version_ui_meta`) and no real workflow name is that long. A
  256 KB body cap sits in front of the two FLOW-LEVEL routes, checked on
  `content-length` and then on the read text before anything is parsed, the way
  the waitpoint ingress does it -- the two version routes still parse unbounded
  and are left for their own issue, because they carry the whole step graph and a
  limit sized for a flow row would be a guess there. (#609 has since bounded them
  at a measured 4,000,000 bytes; see "Request limits" under "API surface".)
  On the way out, `summarizeFlow` withholds a `metadata` over 512 characters
  behind a **sibling** `metadataOmitted: { chars }`, and truncates a `name` over
  200 characters behind a sibling `nameTruncated: { chars }`.

  Both ends are needed: a write cap does nothing for a row already over it, and
  the read cap is what keeps a legacy row out of the prompt. Rows already over
  the write cap are left exactly as they are -- no migration -- and are still
  served in full to the API, the dashboard and the flow engine, because the read
  caps live in `summarizeFlow`, which nothing outside the chat tool calls.
  `parseFlowMetadata` is also defensive now: a column that is not valid JSON, or
  parses to something that is not an object, reads back as `null` instead of
  being cast to an object it is not. The notices are siblings rather than keys
  inside `metadata` because the writer controls that object's contents and could
  otherwise forge them. `chars`, not `bytes`, because the comparison is against
  a UTF-16 length.
- **`list` is bounded by construction.** It emits whole rows until a character
  budget is spent and returns `{ returned, total, truncated, flows }`. Without
  it, framing would have sliced the listing MID-OBJECT at somewhere between 12
  and 27 workflows and handed the model a severed JSON document.

  Two details are load bearing, and both come from getting this wrong first.
  Bounding a row needs BOTH caller-written fields capped: while `name` was
  uncapped, a single 20,000-character `displayName` overran the budget on the
  first row, and a version write bumps `flow.updated` through `touchFlow`, so one
  request both set the long name and moved the row to the head of `ORDER BY
  updated DESC`. And the counters are emitted BEFORE `flows`, because
  `JSON.stringify` preserves insertion order -- counters after the array are the
  first thing any truncation deletes.

  `truncated` / `total` is what defuses a **listing-suppression** primitive:
  `listFlows` is `ORDER BY updated DESC`, and both a metadata write and a version
  write bump `updated`, so an API caller can push their own rows to the head of
  the listing and shove legitimate flows off the end. That is true today at the
  6000-char dispatch cap; being told rows were withheld is what stops it being
  silent, which is exactly what a truncation that ate the counters would have
  undone. The flow listing route's `limit` is clamped to 100 for the related
  reason that `serializeFlow` emits every row's full, unmigrated metadata.
- **The throw paths were the one thing left open** here, and #628 has since
  closed them: `manage_workflow` declares `failureIsOutsideContent`, and the
  orchestrator frames and caps its failure text where the model reads it. The
  original reasoning, kept for the record: `assertVersionReady` / `assertFlowReady` raise a
  `WorkflowReadinessError` interpolating a step name, and
  `assertCodeStepsAllowed` raises `refusalMessage(flowId, intent, stepNames)`;
  step names come from the composer LLM or an uncapped
  `POST /api/workflows/:id/versions` body, which is the same writer class as
  `metadata`. They reach the model unframed because `markUntrustedToolFailure`
  is inert for a tool outside `UNTRUSTED_TOOL_NAMES`. Deferred on blast radius,
  not cost: framing a throw means catching it and returning the text, which
  changes what `registry.execute` promises and contradicts a dozen deliberate
  `rejects.toThrow` assertions.

One residual this section recorded, now resolved: both slice sites below go
through `boundedReceiptText` (`roles/untrusted.ts`), which rewrites the
delimiters to their inert spelling before it cuts, so no prefix of those rows can
hold half a block (#609). What follows is the original analysis.

It was a **truncation** hazard rather than a
boundary one. Two consumers persist a 2000-character prefix of a tool result,
which lands *inside* a ~4300-character framed return: it keeps the open
delimiter and drops the close.

**#598 widens this, and says so rather than inheriting it quietly.** Block
overhead is ~267-327 characters at these labels, so a 2000-character prefix
holds a complete block only while the payload stays under ~1,700. For #582's
three reads a half block was a large-payload edge case; for `list` it is the
ordinary case on any real install (~1,700 characters is about 8 flow summaries).
All nine framed actions travel that path, reads included -- the floor is
`write_data`, which is taint-governed, and the gate returns null for the reads so
they pay the floor -- so the taint floor is not a discriminator between them;
`list`'s payload size is. Accepted with the trade stated: bounding `list` under ~1,650
would show the model about 8 of its own workflows, and the alternative is the
slice-site fix below. The cost stays the integrity nuisance described here and
never a boundary escape.

- `authority/deferred-executor.ts` writes `result.slice(0, 2000)` to
  `approval_requests.execution_result`, and `manage_workflow`'s floor
  (`write_data`) is taint-governed, so a read taken on a tainted turn goes
  through the approval path and lands there.
- `runtime/effect-boundary.ts` writes
  `canonicalJson({ effectId, result }).slice(0, 2000)` through the same
  `markExecuted`.

What a dangling open delimiter costs is *not* the tail of its own payload --
nothing of that payload survives the cut. It is whatever the **consumer**
concatenates afterwards: the receipt is replayed as a tool message, and
`daemon/commitment-executor.ts` joins `execution_result` values into a
commitment `result` that `actions/tools/commitments.ts` renders into a
multi-item listing, unframed, so one item's dangling open line disclaims the
other items' text. That is an integrity nuisance -- trusted text downstream
reads as data -- and never a boundary escape: no attacker text lands outside a
block, and a per-message nonce cannot be replayed into closing a fresh one. It
is not a regression either, since those rows carry the same captured output
today with no frame at all.

Fixing it properly meant truncating without halving a block at the two
`slice(0, 2000)` call sites. The fix that landed does not **locate** an open
line at all -- it defangs every delimiter and then cuts -- so it needed no
exception to the rule `roles/untrusted-import-guard.test.ts` enforces against
locating one in production code (#560).

### `jarvis-ask` answers with a typed outcome

A step that asks for JSON no longer gets the reply text back as if it had
succeeded when the reply is not JSON. `/v1/jarvis/llm/chat` answers
`{ text, parsed?, outcome }`:

- `outcome` is present on every completed call and uses the shared action
  outcome vocabulary in `src/actions/action-outcome.ts`. `parsed` exists only
  when JSON was requested and the outcome is `succeeded`.
- `INVALID_JSON_OUTPUT` means the reply did not parse. `OUTPUT_SCHEMA_MISMATCH`
  means it parsed but missed the declared schema, and the message names the
  paths that failed. Both are `error` with effect `may_have_occurred`: the
  provider was called and answered, so the receipt is a completed effect whose
  result carries the failed contract, and a restarted run reads that receipt
  instead of calling the model again. This is the receipt rule every adapter
  follows: an effect that completed records `succeeded` with its qualified
  outcome inside `result`; an effect that did not complete records `failed`,
  `blocked` or `unknown` with the outcome at the top level of the receipt.
- By default a failed contract answers 422 and the step fails, so nothing
  downstream runs. Turn `Require valid output` off (`requireSuccess: false`)
  only when a later step routes on `{{step.outcome.status}}` and handles the
  failure. That step still gets `text`; it never gets `parsed`.
- `Output schema (JSON)` is a closed JSON Schema subset: `type`, `properties`,
  `required`, `additionalProperties` (boolean), `items`, `enum`, `minItems`,
  `maxItems`, `minLength`, `maxLength`, `minimum`, `maximum`. Any other keyword
  is refused with 400 before the prompt is sent, so a constraint is never
  skipped and then reported as met. The schema checks the reply; it does not
  change the prompt, so ask for the shape in the prompt as well.
- Flows that already had `Parse JSON` on now fail on a reply that is not bare
  JSON, where they used to continue with the text and an empty `parsed`. That
  was the silent path this closes. A flow that meant to tolerate it needs the
  handled-result flag and a router branch on the outcome.

### `jarvis-agent` pauses on approvals and declares its outcome

A tool call inside a delegated sub-agent that needs approval no longer ends
as a denial in the conversation. It becomes an `agent-tool:N` workflow
effect judged as the sub-agent itself, the run parks on its approval, and
after the decision the same step runs again and the conversation continues
where it stopped, in this process or the next. The sub-agent's message log is
checkpointed in `workflow_delegation` after every turn and while it waits,
dropped when it finishes or the run is cancelled; a step the engine runs
again after that answers from the record. A declined approval becomes
`[APPROVAL DENIED]` in the conversation and the tool never runs. A tool the
direct tool piece refuses as opaque (`run_command`, browser clicks and
typing) is refused here too when it would need approval; one the sub-agent's
Authority allows outright runs inside the sub-agent as before.

The step's `outcome` is its business contract. `Required tools` names the
tools that must complete; `succeeded` means the conversation finished and
each of them has a result and no error. Without them, `succeeded` only says
the agent finished cleanly. A failed outcome (`REQUIRED_TOOL_NOT_COMPLETED`,
`AGENT_INCOMPLETE`, `AGENT_ERROR`) answers 422 and stops the step; turn
`Require the declared outcome` off to route on `{{step.outcome.status}}`
instead. The sub-agent's audit rows now record what happened: a call that
needed approval is `approval_required` and not executed, and an allowed call
is recorded after it ran.

### Governed pieces

The ten verified pieces -- gmail, slack, notion, openai, github, google-calendar,
google-drive, discord, telegram-bot, claude -- carry a typed governed adapter in
`src/workflows/runtime/piece-effects.ts`. Before one of their actions runs, the
engine asks the daemon at `/v1/jarvis/pieces/authorize`, and the answer comes
from the same Authority boundary every other effect passes: emergency and
cancellation fences, a durable `workflow_effect` row, an audit row, and an
approval waitpoint when the category is governed. The approval card carries the
step's resolved input and the resolved target -- the recipient, file or endpoint
the action will touch -- never the connection credential, which is stripped in
the engine before the input is sent and again on arrival.

Categories are per action, not per piece: `gmail_search_mail` is `read_data`,
`gmail_create_draft` is `write_data`, `send_email` is `send_email`, and
`gmail_delete_draft` is `delete_data`. An action the table does not name --
one added by a later upstream release, or `custom_api_call`, which can reach any
endpoint of that API -- takes the piece's worst-case category, never `read_data`.

What this does NOT do:

- It does not close the catalogue. Every other piece stays installable and
  runnable exactly as before; a piece with no adapter is reported ungoverned and
  the step proceeds untouched. The verified set grows by landing an adapter.
- It does not govern `CODE` steps, which run in a spawned child process with host
  privileges and make their own calls. They are not governed, they are gated:
  a flow containing one is refused at publish unless CODE was enabled for that
  flow. See `CODE steps need a per-flow opt-in` above.
- It does not make the daemon the caller. The piece's own HTTPS request still
  happens in the engine subprocess after the daemon authorizes it, so the
  recorded outcome is a dispatch authorization, not a delivery receipt. The gate
  holds against an untrusted composed `FlowVersion`, which is the threat it was
  built for; it does not hold against a malicious piece, which is why it covers
  only pieces that have been read and vetted.
- It does not cover triggers. Polling triggers run on a different engine path.

### `CODE` steps need a per-flow opt-in

A `CODE` step is not a sandboxed expression and not an isolate. The engine
writes the step's `sourceCode` bundle to disk and runs it in the engine
subprocess: `AP_EXECUTION_MODE=SANDBOX_PROCESS` is a CHILD PROCESS, so that
JavaScript has every privilege the daemon's user has -- the whole filesystem,
the network, the shell. None of it comes back through the daemon, so none of it
is visible to the Authority boundary above. That is the whole reason for the
gate: a flow is not always hand-authored, `manage_workflow compose` builds a
`FlowVersion` out of an LLM plan, and LLM output is untrusted here.

So CODE is off by default, and the permission is granted PER FLOW:

```
POST /api/workflows/<flowId>/code-steps   {"enabled": true}
```

A global switch would be the wrong shape: turning CODE on for one automation
would turn it on for every flow composed afterwards, which is the thing the
gate exists to prevent.

The refusal happens at AUTHORING time, never per execution:

- `POST /api/workflows/:id/publish` and `manage_workflow publish` refuse with
  403 and change nothing -- the version is not locked, not attached, and the
  flow is not enabled.
- Enabling a flow refuses the same way (`PATCH /api/workflows/:id` with
  `status: "ENABLED"`, `manage_workflow enable`), because the trigger manager
  registers an ENABLED flow's cron against `published ?? latest draft`: without
  this, a flow could start firing on a schedule without ever being published.
- Asking for a run directly refuses too (`POST /api/workflows/:id/run`,
  `manage_workflow run`, and a nested `run_workflow` step). This is defence in
  depth, not the primary gate, and it can only ever refuse an UNPUBLISHED
  draft: publish already requires the grant, so a published flow carries it.
- Writing a CODE step INTO the draft an ENABLED flow is already running is
  refused as well. A flow that is ENABLED with nothing published runs its
  latest draft, and a draft row is mutated in place, so that save is a deploy:
  without this the graph behind a registered cron could pick up a CODE step
  after the enable gate had passed. `createDraftVersion` and
  `updateDraftVersion` are the only two writers of `flow_version.trigger`, so
  both carry the check. Editing a draft on a DISABLED flow, or on one that has
  a published version, stays completely free -- publish is still ahead of it.
- Finally, `TriggerManager` declines to register a subscription for a version
  with an ungranted CODE step, and logs why. Registration happens at boot and
  on refresh, not per execution, so this is not #459's run-time refusal; it is
  the backstop for the one thing the authoring gates cannot see, namely that
  "latest draft" moves with any write that bumps a draft's `updated`, so a
  CODE draft that was not live when the flow was enabled can become live
  later. A published flow always carries the grant, so this can only ever
  decline a flow that was never publishable.

Nothing is refused per execution. That was the flaw in the allowlist cut from
#459: it refused at run time, so a cron- or webhook-triggered flow published
successfully and then failed on every fire with nobody there to read why.

The message names what was refused, which step caused it, and the call that
grants the permission. A CODE step is found wherever it is -- the walker in
`src/workflows/db/flow-graph.ts` follows `nextAction`, a LOOP's
`firstLoopAction` and every ROUTER branch in `children`, so a step parked
inside a loop or behind a branch is not missed.

**Existing flows are grandfathered, visibly.** On the first boot that adds the
column, any flow that is already runnable (ENABLED, or carrying a published
version) whose runnable version actually contains a CODE step gets the
permission, stamped `grantedBy: "upgrade"`. An automation that has been running
a CODE step on a cron for months does not stop because the daemon restarted on
a newer build, and the grant is not silent: `GET /api/workflows` reports
`codeSteps: { enabled, grantedBy, grantedAt }` per flow, so the dashboard can
say the permission was inherited rather than chosen, and the user can revoke it
with `{"enabled": false}`. Every other flow -- including one holding an
unpublished CODE draft -- starts at OFF.

Revoking with `{"enabled": false}` takes the permission away from the next
publish, enable, run or draft write, and from the next trigger registration --
so a live schedule keeps firing until the daemon restarts or the flow is
refreshed, and then stops. It does not unpublish the version and it does not
stop a run already in flight. Disabling the flow is what stops a schedule
immediately. The grant is not handed back later: the upgrade backfill is keyed
on the columns being introduced, so a revoked permission stays revoked across
restarts. The other side of that key is that a build rolled back below this
version and then rolled forward again will not re-grandfather a flow published
in between; such a flow needs the opt-in like any other.

Three deliberate omissions:

- `manage_workflow` has no action that grants the permission. The threat is an
  untrusted LLM-authored `FlowVersion`; a tool action that let the model grant
  itself CODE would be the gate writing its own exception.
- Piece admission is untouched. All 657 catalogue entries stay installable and
  runnable. This gate is CODE steps only.
- A linked work item (`startWorkItemRun`, `src/goals/workflow-bridge.ts`) is not
  gated. It runs one LOCKED version that the user personally accepted on an
  approval card, which is a per-version consent signal stronger than the
  per-flow flag, and gating it would break an accepted proposal mid-flight on
  upgrade.

Also worth knowing: `manage_workflow compose` cannot emit a CODE step at all.
Its validator accepts `PIECE`, `LOOP_ON_ITEMS` and `ROUTER` for action steps
and nothing else, so the LLM path produces CODE-free flows and the gate is
never in the composer's way.

### A CODE step imports only what its package.json declares (#837)

A CODE step used to `require()` any package at all: with no `node_modules`
above the step, Bun auto-installed the name from the npm registry at its
latest version and ran it. Now:

- Only the `dependencies` field of the step's `package.json` is read. Each
  entry must be a registry version, range or dist-tag (`1.2.3`, `^4.0.0`,
  `>=1 <2`, `latest`). `file:`, `link:`, `workspace:`, `npm:` aliases, git,
  URL, GitHub `user/repo`, folder (`.`, `..`) and local tarball specs are
  refused, and so is a manifest that is not valid JSON. Readiness reports a
  refused manifest on the step when the flow is saved.
- Before the run, the daemon installs exactly those dependencies beside the
  step from a manifest it writes itself (the step's own `scripts`,
  `overrides` or `workspaces` never reach the install), with
  `--ignore-scripts` and a 5 minute limit. One install runs at a time.
- The step itself runs with `--no-install`. Requiring a package the manifest
  does not declare fails the step with
  `CODE step requires package "<name>", which its package.json does not declare`.
  Nothing is fetched at run time.

### `{{ ... }}` expressions are data, not JavaScript

The vendored engine's expression evaluator used `Function(...)`, so any inline
expression ran arbitrary code inside the engine subprocess with host privileges.
It is now a bounded data interpreter (`src/workflows/runtime/safe-expression.ts`).

Supported: property references, dot/bracket/optional access, primitive literals,
arrays and objects, arithmetic, comparisons, logical and nullish operators,
ternaries, and `flattenNestedKeys(data, path)`.

Not supported: method calls (`.map`, `.split`, `.toUpperCase`), constructors
(`new Date()`), `JSON.parse`, assignment, spread, globals, and prototype access.

An unsupported expression now **fails the step loudly** instead of silently
resolving to an empty string, and the error quotes the expression that failed.
Flows that relied on a JavaScript method in an input need the value reshaped
upstream -- by the step that produces it, or by a piece that returns the shape
you want.

Limits per expression: 16,384 source characters, 2,048 tokens, depth 64, 10,000
evaluation visits, and 1,048,576 accumulated output characters.

### A run is pinned to one computer and one connection

A workflow run used to pick a machine per step. If the chosen computer dropped
between two steps, the next step re-ran auto-selection and landed on whichever
other sidecar happened to be connected -- and recorded that as a success. A
click, a keystroke or a command could therefore execute on a machine nobody
reviewed.

The first machine operation in a run now pins the run to one computer and to
that computer's exact control socket, durably, in
`workflow_run_machine_binding`. `GET /api/workflow-runs/:runId` exposes it as
`machineBinding`. The binding is written once inside an immediate transaction
and is never rewritten: there is no in-place retarget, no automatic retry and
no fallback to another sidecar.

Later dispatches -- including delegated-agent tool calls, approval resumes and
the RPC send inside `SidecarManager` itself -- are checked against it. What was
a silent switch is now a typed `blocked` outcome with `effect: 'not_started'`:

- `WORKFLOW_MACHINE_OFFLINE` -- the bound computer is offline or no longer
  enrolled.
- `WORKFLOW_SESSION_CHANGED` -- it reconnected, so this is a different socket
  than the one the work was reviewed against. A daemon restart has the same
  effect for local execution.
- `WORKFLOW_CAPABILITY_UNAVAILABLE` -- the bound computer no longer advertises
  the capability the step needs.
- `WORKFLOW_RETARGET_REQUIRED` -- the step asked for a different computer than
  the run is bound to.
- `WORKFLOW_TARGET_AMBIGUOUS` -- an explicit name matched no device or several.
- `WORKFLOW_MACHINE_UNAVAILABLE` -- nothing capable is connected and local
  execution is disabled.
- `WORKFLOW_BINDING_LEGACY` -- the run already did machine work under an older
  binary, so it has no verifiable connection generation to adopt.

Every one of these says no action was dispatched. Earlier receipts in the same
run keep their results, including a result that arrives after the machine
dropped, so recovery is to review the recorded effects and start a new run with
an explicit target and fresh approvals -- not to replay completed work. A
workflow that deliberately used two different computers in one run needs two
reviewed runs.

Only steps that touch a machine bind one, so a flow that never leaves the
daemon is unaffected, and ordinary chat routing is untouched.

### Previews resolve saved samples, but not for perception steps

Testing a single step reuses the version's saved sample data for the steps it
depends on. Those samples have no trusted machine or connection provenance: a
window id or element id captured from an earlier preview may name something on
a machine that is gone, or something that has since moved.

A preview of a desktop, browser or screenshot step is therefore refused with
`WORKFLOW_SAMPLE_BINDING_UNKNOWN` when the step's input references another
step's saved output. The guard reads the dispatching step's expressions -- the
child a router or loop actually runs, the run's frozen input override, and
nested and loop-derived references, taking both branches of a ternary -- and it
only looks at which steps an expression names, never at what the sample
contains. Fields inside a sample's JSON cannot claim provenance for it.

What still works unchanged: unrelated saved samples, the tested step's own
auto-captured output, literal inputs, the current trigger payload, and every
non-machine preview. To get past the refusal, run the perception step again in
a full run.

## Architecture

```
+------------------------------------------------------------------------------+
|                       Jarvis daemon (Bun, single process)                    |
|                                                                              |
|  Existing services (Agent, Vault, Observers, Channels, ...)                  |
|        |                                                                     |
|        v                                                                     |
|  src/workflows/                                                              |
|    runtime/                                                                  |
|      engine-bootstrap.ts: build engine + compile pieces + start SandboxApi   |
|      service-backends.ts: glues daemon services into /v1/jarvis/* fns        |
|      event-bus.ts + event-buffer.ts: in-process pub/sub for jarvis-trigger   |
|      piece-catalog.ts: engine-extracted catalog + on-disk cache              |
|                                                                              |
|    sandbox-api/   loopback HTTP+WS server (random port, 127.0.0.1)           |
|      socket.io /worker/ws + /v1/* HTTP routes                                |
|        - /v1/worker/{project,app-connections}                                |
|        - /v1/store-entries, /v1/step-files, /v1/waitpoints                   |
|        - /v1/engine/populated-flows, /v1/logs/:runId                         |
|        - /v1/jarvis/{llm,tools,notify,context,agent,events,workflows,        |
|          pieces}                                                             |
|                                                                              |
|    runner/                                                                   |
|      handler.ts: RUN_FLOW JobHandler                                         |
|      engine-runtime/                                                         |
|        engine-runtime.ts: spawn + warm pool (idle TTL 5min)                  |
|        engine-flow-executor.ts: FlowExecutor over EngineHandle               |
|        flow-version-adapter.ts: Jarvis flow shape -> upstream shape          |
|        operation-builder.ts: BEGIN / RESUME / EXTRACT_PIECE_METADATA /       |
|                              EXECUTE_TRIGGER_HOOK                            |
|      triggers/                                                               |
|        manager.ts: cron + webhook + ON_ENABLE/ON_DISABLE routing             |
|        cron.ts: 5-field cron + sub-minute `@every Ns` extension              |
|        webhook.ts: registers `/api/webhooks/<flowId>`                        |
|                                                                              |
|    queue/      SQLite-backed job queue + worker dispatcher                   |
|    db/         schemas + repos (flow, version, run, connection, store,      |
|                waitpoint, workflow_file, job) + AES-256-GCM at-rest enc      |
|    api/        /api/workflows/* HTTP routes                                  |
|    activepieces/  vendored upstream subset (engine, pieces/framework,        |
|                   pieces/common, pieces/jarvis/*)                            |
|    pieces-library/  curated community catalog + installer + reconciler       |
|    credentials/  JarvisConnectionSource adapters (jarvis:google, etc.)       |
|                                                                              |
+------------------------------------------------------------------------------+
                              |
                  spawn child Bun process (engine bundle)
                              v
+------------------------------------------------------------------------------+
| Engine subprocess (one warm process; idle TTL evicts after 5min)             |
|  AP_EXECUTION_MODE=SANDBOX_PROCESS                                           |
|  AP_SANDBOX_WS_PORT=...        SANDBOX_ID=...                                |
|  -> connects to daemon's SandboxApi /worker/ws                               |
|  -> imports vendored pieces dynamically (dev-pieces mode for Jarvis pieces,  |
|     node_modules resolution for community pieces)                            |
|  -> calls back to /v1/* for store, connections, step-files, llm, tools, ... |
+------------------------------------------------------------------------------+
```

## Source tree map

```
src/workflows/
  activepieces/                 Vendored Activepieces source. See UPSTREAM.md.
    LICENSE.activepieces        MIT license preserved verbatim.
    UPSTREAM.md                 Pinned commit + license posture + exclusions.
    packages/
      shared/                   Upstream shared types (BranchOperator, etc.)
      pieces/
        framework/              Upstream `createPiece`, `createAction`, `Property`
        common/                 Upstream helpers (http, auth)
        jarvis/                 Our pieces (ask, tool, notify, context, agent,
                                trigger, regex, test, validate)
      server/engine/            Upstream engine source (we build this into a CJS
                                bundle and spawn it as a child process)

  runtime/                      Daemon-side orchestration above the engine
    engine-bootstrap.ts         Daemon startup: build bundle, compile pieces,
                                spin up SandboxApi, build PieceCatalog
    service-backends.ts         Wraps LLMManager / ToolRegistry / ChannelService
                                / etc. into the function shape /v1/jarvis/*
                                routes expect
    piece-catalog.ts            Engine-extracted catalog + on-disk cache at
                                `~/.jarvis/cache/piece-metadata.json`
    piece-input.ts              Typed input-field schema shared by the catalog,
                                the editor and the composer
    effect-boundary.ts          Authority boundary every workflow effect passes
    effect-capabilities.ts      Maps a tool to its bounded Authority category
    piece-effects.ts            Governed-piece adapter table and projection
                                (compiled into the engine bundle)
    piece-effect-receipt.ts     Daemon-only defang of that projection
    machine-binding.ts          Pins a run to one computer and connection
    safe-expression.ts          The `{{ }}` expression evaluator
    workflow-readiness.ts       Readiness: what makes a version runnable
    cancellation.ts             Dispatch fence: assert / scope / abort helpers
                                every run's next action is checked against
    cancellation-signals.ts     In-process bus that wakes the active executor
                                once the fence commits
    event-bus.ts                Pub/sub used by `jarvis-trigger:on_event`
    event-buffer.ts             Recent-event ring buffer surfaced over /v1
    test-fixtures.ts            Catalog snapshot used by composer tests
    test-fixtures-drift.test.ts Drift test: rebuild catalog vs committed fixture

  sandbox-api/                  Loopback HTTP+WS API the engine subprocess hits
    server.ts                   Bun.serve HTTP listener for the engine; starts
                                the socket.io RPC server (worker-rpc.ts)
    config.ts                   Side-file locations (`~/.jarvis/workflow-files/`,
                                `~/.jarvis/workflow-logs/`, `JARVIS_WORKFLOW_DATA_DIR`)
    engine-token.ts             Token mint + verify (engine -> daemon auth)
    sandbox-registry.ts         Maps sandboxId -> runId/flowId for /v1 routes
    rpc.ts + worker-rpc.ts      WorkerContract bridge (engine -> daemon RPC)
    routes/                     One file per /v1 surface:
      connections.ts            Read-only connection resolve for the engine
                                (`/v1/worker/app-connections/:externalId`)
      files.ts                  /v1/step-files binary uploads/downloads
      flows.ts                  /v1/engine/populated-flows (resolves a runtime
                                version + execution context for the engine)
      jarvis-agent.ts           /v1/jarvis/agent  -> agent-delegator
      jarvis-context.ts         /v1/jarvis/context -> vault/awareness/commitments
      jarvis-events.ts          /v1/jarvis/events -> event buffer poll
      jarvis-llm.ts             /v1/jarvis/llm    -> LLMManager.chat
      jarvis-notify.ts          /v1/jarvis/notify -> ChannelService + desktop
      jarvis-pieces.ts          /v1/jarvis/pieces/authorize -> governed-piece admission
      effect-context.ts         (helper, no route) reads a request's step name
                                and execution path headers
      jarvis-tools.ts           /v1/jarvis/tools  -> ToolRegistry.invoke
      jarvis-workflows.ts       /v1/jarvis/workflows -> workflow runner
      logs.ts                   /v1/logs/:runId zstd execution-state backup
      store.ts                  /v1/store-entries (engine's KV store)
      waitpoints.ts             `/v1/waitpoints` (the public resume route,
                                `/api/webhooks/waitpoints/:id`, is in api/routes.ts)

  runner/                       Things that run a flow
    handler.ts                  RUN_FLOW JobHandler -- the worker's entry point
    engine-runtime/
      build.ts                  Builds the engine into a CJS bundle. The bundle
                                is content-addressed; cache lives in
                                `~/.jarvis/cache/engine/<hash>/`
      build-pieces.ts           Walks packages/pieces/jarvis/* and esbuilds each
                                into its own `dist/` (`dist/src/index.js`).
                                Content-hash skip on rebuild via
                                `dist/.source-hash`.
      engine-runtime.ts         Spawns + warms the engine subprocess; manages
                                the single-slot pool with 5min idle TTL
      engine-flow-executor.ts   Implements FlowExecutor by routing every step
                                through EngineHandle.executeFlow
      flow-version-adapter.ts   Maps our FlowVersion DB row -> upstream's shape
      operation-builder.ts      BEGIN / RESUME / EXTRACT_PIECE_METADATA /
                                EXECUTE_TRIGGER_HOOK / EXECUTE_PROPERTY
      execution-state-loader.ts Rehydrates RESUME state from the zstd backup
      code-materialize.ts       CODE pieces materialize source onto disk for
                                the engine to require()
      spawn.ts                  Low-level child_process spawn helpers
    triggers/
      manager.ts                Coordinator: enable/disable a flow's triggers,
                                routes to cron / webhook / engine
      cron.ts                   Re-export shim over `src/lib/cron-scheduler.ts`
                                (5-field cron + `@every 10s`)
      webhook.ts                `/api/webhooks/<flowId>` registry

  queue/                        SQLite-backed job queue
    worker.ts                   `Worker`: drains jobs, calls handler.ts
    retry-policy.ts             One attempt per RUN_FLOW job + operator guidance
    queue.test.ts               Drain semantics + race-tolerant terminal-status

  db/                           Persistence
    schema.ts                   All SQLite tables (flow, flow_version,
                                flow_version_ui_meta, flow_run,
                                workflow_run_cancellation,
                                workflow_run_machine_binding,
                                workflow_effect, workflow_delegation,
                                workflow_composition, app_connection,
                                trigger_event, store_entry, waitpoint,
                                workflow_file, workflow_job)
    encryption.ts               AES-256-GCM at-rest for app_connection.value
    repos/                      Thin CRUD over bun:sqlite, mostly one file per
                                table, plus flow-readiness, flow-publication,
                                flow-code-steps and flow-version-ownership
    flow-graph.ts               Whole-graph walk of a version (every edge) and
                                the CODE-step scan the publish gate uses
    credential-migration.ts     Converts legacy credential rows to the bound
                                envelope

  api/                          HTTP routes mounted under /api/workflows/*
    routes.ts                   Route table + handlers (see "API surface" below)

  pieces-library/               Curated community-pieces catalog + installer
    catalog.ts                  Tiered registry (Verified / Community)
    catalog-generated.ts        Auto-synced from npm (do not edit)
    catalog-overrides.ts        Hand-maintained verified set + pins
    installer.ts                Writes ~/.jarvis/pieces/installed.json and runs
                                bun install (metadata is re-extracted by the
                                routes' `onPieceLibraryChanged` callback)
    reconciler.ts               Idempotent reconcile (install/uninstall delta)

  credentials/                  JarvisConnectionSource adapters that bridge
                                Jarvis's existing OAuth/state into pieces
    adapter.ts                  Registry of sources by `jarvis:*` external id
    google-source.ts            jarvis:google -> existing Google OAuth tokens
    telegram-source.ts          jarvis:telegram -> daemon's bot token

  adapters/                     Daemon-side service shims invoked by /v1/jarvis
    agent-delegator.ts          Backs jarvis-agent.delegate
    m7-agent-delegator.ts       The M7 sub-agent loop behind it
    context-provider.ts         Backs jarvis-context (vault/awareness reads)
    llm-client.ts               Backs jarvis-ask via LLMManager.chat
    notifier.ts                 Backs jarvis-notify -- per-channel routing
    tool-registry.ts            Backs jarvis-tool -- invoke a Jarvis tool
    workflow-runner.ts          Backs jarvis-trigger.run_workflow

  jarvis-pieces/
    types.ts                    Shared types for the Jarvis pieces' services

  evaluation/                   Workflow-quality evaluation harness

ui/src/v2/rooms/workflows/      The visual editor and runs panel
  WorkflowsRoom.tsx             List view; run history; new workflow
  WorkflowEditor.tsx            xyflow canvas + settings popovers
  useWorkflowEditor.ts          Editor state machine; persistence; auto-layout
  useFlowRuns.ts                Runs panel state + adaptive polling
  useConnections.ts             Connection management
  useLibrary.ts                 Pieces library install/uninstall
  tree.ts                       Tree algebra (insert/delete/wire branches)
  variable-rows.ts              Predecessor-output variable picker source
```

Build scripts and tooling:

```
scripts/
  build-engine.ts               Builds the engine bundle into a content-hashed
                                dir in ~/.jarvis/cache/engine/<hash>/
  build-pieces.ts               Builds every Jarvis-authored piece (content-hash
                                cached)
  build-workflows.ts            Umbrella: bundle + pieces
  sync-activepieces.ts          Pulls a pinned upstream SHA into the vendored
                                tree and re-applies the PATCH_INSERTIONS layer
  sync-pieces-catalog.ts        Refreshes catalog-generated.ts from npm; run by
                                .github/workflows/sync-pieces-catalog.yml
  audit-piece-outputs.ts        Reports which actions declare outputSample (the
                                shape the variable picker depends on)
  check-no-ee-imports.ts        CI guard: refuses any /ee/ path from the vendor
                                tree
  rotate-encryption-key.ts      Decrypt-old + re-encrypt-new + atomic keychain
                                swap for the workflow encryption key
```

## Bootstrap flow

When the daemon starts, `src/workflows/runtime/engine-bootstrap.ts` runs in parallel with the other services. The sequence:

1. `buildEngineBundle()` checks `~/.jarvis/cache/engine/<hash>/main.js`. If the hash matches current sources, returns immediately. Otherwise rebuilds (~700ms cold) and caches.
2. `buildAllJarvisPieces()` walks `packages/pieces/jarvis/*` and esbuilds each piece into its dist dir. Unchanged pieces skip on hash hit (~2ms each).
3. `SandboxApi.start()` binds a random port on `127.0.0.1` with `Bun.serve` and starts the socket.io RPC server beside it.
4. `EngineRuntime.acquire()` is left to the worker (lazy spawn on first job). The pool holds one warm engine after release; idle TTL evicts after 5 min.
5. `buildPieceCatalog()` runs `EXTRACT_PIECE_METADATA` for every known piece (Jarvis + installed community). Failures don't block successful entries: partial cache writes persist what extracted. The cache key includes `CATALOG_SCHEMA_VERSION` so daemon-side projection changes invalidate it.
6. The bootstrap returns `{ api, runtime, catalog, failures, bundleHash, catalogCacheKey, shutdown }`, which the daemon hands to the queue `Worker`, `TriggerManager` and the API routes.

If bootstrap fails (e.g. esbuild error in a piece), the daemon logs a warning and falls back to "no workflows" mode -- the rest of Jarvis comes up clean. The Workflows room shows an empty-catalog notice.

## Runtime walkthrough -- one flow run

Following a single run from a user click to a SUCCEEDED row:

1. User clicks **Run** in the editor. UI calls `POST /api/workflows/:id/run`.
2. `createFlowRun()` writes a `flow_run` row in QUEUED state; `enqueue()` adds a `RUN_FLOW` job.
3. The worker drains the job. `RUN_FLOW` resolves the flow version, materializes any CODE pieces onto disk, then calls `EngineFlowExecutor.executeFlow()`.
4. `EngineRuntime.acquire()` either picks up the warm engine or spawns a fresh one. Spawn passes `AP_SANDBOX_WS_PORT` + an engine token in env.
5. The engine subprocess imports the populated flow's pieces (Jarvis pieces via dev-pieces resolution, community pieces via `node_modules`), runs the trigger payload through each step, and streams `WorkerContract.updateStepProgress` events back over the WS for every step boundary.
6. The UI's runs panel polls `/api/workflows/:id/runs` adaptively (faster while a run is RUNNING). The overlay on the canvas reflects the latest step status.
7. On terminal status, the engine sends `WorkerContract.updateRunProgress(SUCCEEDED|FAILED|PAUSED)` plus `uploadRunLog` (zstd execution-state). The handler updates the row and releases the engine back to the pool.

Cancellation (`POST /api/workflow-runs/:runId/cancel`) is a durable dispatch fence, not a remote undo. One SQLite transaction writes a `workflow_run_cancellation` row, marks the run STOPPED, and cancels every active `RUN_FLOW` job for it; only after that commit is the active executor signaled, which aborts the engine RPC and kills the subprocess instead of returning it to the warm pool. The fence outlives a restart and a workflow deletion: `enqueue`, `createWaitpoint` and every `/v1/jarvis/*` action route re-check it, and `updateRun` lets a late result add step evidence but never revoke STOPPED. An effect already dispatched may still land, so the run reports `inFlightMayHaveCompleted` and the dashboard says so.

If a step calls `context.run.pause()` (e.g. waiting on a webhook), the engine sends PAUSED + the zstd backup. The daemon writes a `waitpoint` row and the run hangs. A later `POST /api/webhooks/waitpoints/:id` enqueues a `RESUME` job; the worker loads the backup, restores execution state via `execution-state-loader.ts`, and the engine picks up exactly where it paused.

### Run status lifecycle

`FlowRunStatus` (`src/workflows/db/repos/flow-run.ts`) has eleven values. Only two are non-final for a given attempt:

```
QUEUED --claim--> RUNNING --+--> SUCCEEDED
                            |
                            +--> PAUSED --resume--> RUNNING --> ...
                            |
                            +--> FAILED | INTERNAL_ERROR | TIMEOUT | STOPPED
                                 | QUOTA_EXCEEDED | MEMORY_LIMIT_EXCEEDED
                                 | SCHEDULE_FAILURE
```

A **queue job** and a **run** finish on different clocks. A `RUN_FLOW` job covers one execution slice; when that slice ends at a waitpoint the job is SUCCEEDED and the run stays PAUSED. `FlowExecutorResult.status` carries that distinction out of the executor so `createRunFlowHandler` can persist the pause instead of overwriting it with SUCCEEDED:

- On PAUSED the handler persists `steps` + `steps_count`, sets `finish_time` to NULL, and skips sample-data auto-capture. `finish_time` stays NULL for the whole pause, so nothing reports a paused run as finished or computes a duration for it.
- Each job clears `finish_time` when it flips the run to RUNNING, so a RESUME never carries a stale finish time left behind by an earlier slice. `start_time` is preserved across resumes.
- A resume re-enters the same run id with a new `RUN_FLOW` job carrying `executionType: "RESUME"`. The handler refuses a BEGIN for a run that is not QUEUED and a RESUME for a run that is not PAUSED, so a durable PAUSED row is what makes the continuation legal -- see "Failure and restart" below.

Two things produce that resume job, both server-side:

- `POST /api/webhooks/waitpoints/:id` for WEBHOOK/MANUAL waitpoints. It refuses anything but a PAUSED run (409) and an already-resumed waitpoint (410).
- `TimerWaitpointScheduler` (`src/workflows/timer-scheduler.ts`) for TIMER waitpoints, which have no external trigger. It ticks every 15s plus once at boot, so a delay that elapsed entirely during downtime still fires. Marking the waitpoint resumed and enqueueing the job happen in one transaction, so a crash between them cannot strand the run.

The scheduler's eligibility query (`listDueTimerWaitpoints`) skips waitpoints whose run is still QUEUED or RUNNING, *before* applying its 100-row batch limit. The engine creates the waitpoint row before it publishes PAUSED, so a short delay can come due inside that window; retiring the timer there would strand the run PAUSED with nothing left to wake it. Deferring instead also keeps those rows from filling a scan and starving later PAUSED runs. Missing and terminal runs still get their timers retired.

The one transition not shown above is boot recovery: an orphaned run whose job died mid-flight is retired to FAILED rather than replayed, again covered in "Failure and restart" below. A run that had durably PAUSED is the exception and stays PAUSED, which is what lets its timer or webhook still fire after a restart.

## Failure and restart: no automatic replay

A flow step can deliver a real effect (send a message, hit an API, write a
file) and the queue has no receipt for it, so `RUN_FLOW` is never retried
automatically. `src/workflows/queue/retry-policy.ts` pins every `RUN_FLOW`
job -- BEGIN and RESUME alike -- to a single attempt, whatever the caller
asked for, and an expired `RUN_FLOW` lease is never stolen by another claim.
Other job types keep the default three attempts with backoff.

What that means in practice:

- A step failure ends the run `FAILED` once. The reason lands in
  `flow_run.failed_step.errorMessage` (chat `get_run`, the runs API and the
  editor's run banner all read it) with guidance to check which effects
  already completed before starting a new run.
- A daemon crash or an over-deadline drain leaves the job `RUNNING`. The next
  boot's `recoverOrphanedJobs()` retires it: the job goes `FAILED` and its
  unfinished run goes `FAILED` too, in one transaction, keeping whatever step
  outputs were recorded. It is NOT resumed -- the effects of the interrupted
  step are unknown.
- A run that had durably PAUSED is the exception: if it still has an open
  waitpoint, or a fresh single-attempt `RESUME` job already queued for it,
  boot recovery leaves it `PAUSED` so the planned continuation still fires.
- Re-running is a user decision. A new run is a new `flow_run`; nothing in the
  queue treats a fresh job as permission to replay an existing run, and the
  handler refuses a BEGIN for a run that is not `QUEUED` or a RESUME for a run
  that is not `PAUSED`.

Durable per-effect receipts and reconciliation-based recovery are follow-up
work; this policy is containment, not exactly-once execution.

## Pieces

Two flavors:

- **Jarvis-authored** pieces live in `src/workflows/activepieces/packages/pieces/jarvis/`. They use the same `createPiece` / `createAction` API as upstream Activepieces. They're auto-discovered: drop a directory with a valid `package.json` and the next daemon restart finds it, builds it, and surfaces it in the library.
- **Community** pieces ship as npm packages. They install at runtime via the pieces library UI -- the installer writes `~/.jarvis/pieces/installed.json`, runs `bun install`, and asks the engine to extract metadata. They are picked from a curated catalog (Verified or Community tier).

Before adding or editing any piece, walk the checklist in [`PIECE_VERIFICATION.md`](./PIECE_VERIFICATION.md). That doc covers the 8 stages from source shape to test layers.

For the community-pieces curation flow (how a piece reaches the Verified tier, sync action, version pinning), read [`src/workflows/pieces-library/README.md`](../src/workflows/pieces-library/README.md).

## Triggers

`TriggerManager` reconciles which triggers are active for which published flow. Three trigger types:

| Source | How it's wired |
|---|---|
| `schedule` | Routed to `CronScheduler`. Supports the standard 5-field cron plus a `@every Ns` sub-minute extension. Job ID is `flow:{flowId}`. |
| `webhook` | Routed to `WebhookManager`. Registers `/api/webhooks/<flowId>`. GET and POST both fire; pieces that need HMAC verify inside their handler. |
| Engine-managed (anything else) | The piece's trigger logic runs in the engine. `EXECUTE_TRIGGER_HOOK(ON_ENABLE)` returns either `scheduleOptions` (registered with `CronScheduler`) or `listeners` (registered with `WebhookManager`). On disable, `EXECUTE_TRIGGER_HOOK(ON_DISABLE)` runs first; persistent state clears even if the engine call fails. |

Polling triggers (e.g. Gmail's watch) live in this third category: the engine schedules a cron-driven `RUN` of the trigger's polling logic and emits new items.

## API surface

Mounted under `/api/workflows/*`. Source: `src/workflows/api/routes.ts`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/workflows` | List flows. `?status=ENABLED\|DISABLED`, `?limit` (default 100, max 100), `?offset`. Bare array |
| POST | `/api/workflows` | Create a flow and its first draft. `{ displayName, externalId?, metadata? }` |
| GET | `/api/workflows/readiness` | Readiness of every ENABLED flow's executable version. `?limit` (default 100, max 100), `?offset`; answers `{ items, nextOffset }` |
| GET | `/api/workflows/:id` | Flow + latest draft + published version + the editable version's `uiMeta` |
| PATCH | `/api/workflows/:id` | Enable / disable (`status`) and set `metadata`. Renaming is a version write, not this |
| DELETE | `/api/workflows/:id` | Delete flow + cascade |
| GET | `/api/workflows/:id/versions` | Version history |
| POST | `/api/workflows/:id/versions` | New draft version. `{ displayName, trigger?, uiMeta? }` |
| GET | `/api/workflows/:id/versions/:vid` | Get version + its `uiMeta` |
| PATCH | `/api/workflows/:id/versions/:vid` | Edit a draft: `displayName`, `trigger`, `connectionIds`, `agentIds`, `uiMeta` (picked, not spread; other keys are ignored). Refused for a LOCKED version (409) |
| GET | `/api/workflows/:id/versions/:vid/readiness` | Readiness report for one version |
| POST | `/api/workflows/:id/versions/:vid/lock` | Freeze a draft (DRAFT -> LOCKED). Gated on readiness (422 with the readiness report); may answer with `osWarnings`. Does not publish and does not refresh triggers |
| PATCH | `/api/workflows/:id/versions/:vid/sample-data/:step` | Set one step's sample output, `{ output }`; `output` absent or null removes the entry |
| DELETE | `/api/workflows/:id/versions/:vid/sample-data/:step` | Clear the version's WHOLE sample-data map. `:step` is required by the path and ignored. Refused for a LOCKED version (409) |
| PATCH | `/api/workflows/:id/versions/:vid/sample-input/:step` | Set one step's sample input override, `{ input }` (a JSON object; absent or null removes it) |
| POST | `/api/workflows/:id/publish` | Publish the latest draft, or `{ versionId }` (403 when the version has a CODE step and CODE is off for the flow) |
| POST | `/api/workflows/:id/code-steps` | Grant or revoke this flow's CODE-step permission (`{"enabled": bool}`, required) |
| POST | `/api/workflows/:id/run` | Enqueue a run, 202. `{ environment?, triggeredBy?, stepNameToTest?, payload? }`, or `{ workItemId }` alone |
| GET | `/api/workflows/:id/runs` | Run history, newest first. `?status`, `?limit` (default 50, max 100), `?offset`; answers `{ items, nextOffset }` |
| GET | `/api/workflow-runs/:runId` | One run, including its machine binding and cancellation |
| GET | `/api/workflow-runs/:runId/effects` | The run's governed effect records, `{ runId, effects }` |
| GET | `/api/workflow-runs/:runId/waitpoints` | The run's active waitpoints with resume URLs |
| POST | `/api/workflow-runs/:runId/cancel` | Close the run's dispatch fence (idempotent; `accepted: false` once finished) |
| GET | `/api/workflows/pieces` | Engine-extracted catalog |
| GET | `/api/workflows/pieces/library` | Catalog of installable community pieces |
| POST | `/api/workflows/pieces/library/:id/install` | Install or update a community piece |
| DELETE | `/api/workflows/pieces/library/:id` | Uninstall a community piece |
| GET | `/api/workflows/connections` | Connections in the default project (no secrets) plus the registered Jarvis sources: `{ connections, jarvisSources }` |
| POST | `/api/workflows/connections` | Create, or replace by `(pieceName, externalId)`, a connection (encrypted). `{ externalId, displayName, type, pieceName, pieceVersion?, value }` |
| PATCH | `/api/workflows/connections/:id` | Update that connection in place: `displayName`, `value` (full replacement), `status`. Rotates a token without the delete-then-recreate gap. 404 for an id outside the default project, the same as for an id that does not exist |
| DELETE | `/api/workflows/connections/:id` | Delete the stored connection. Revokes nothing at the provider. 404 for an id outside the default project, the same as for an id that does not exist |
| GET | `/api/workflows/triggers` | Active trigger registrations |
| GET | `/api/workflows/events/buffer-stats` | Event buffer health (dropped count, capacity) |
| GET, POST | `/api/webhooks/:flowId` | Engine-managed webhook trigger fan-in (503 when webhooks are not enabled in the build) |
| POST | `/api/webhooks/waitpoints/:id` | Resume a paused flow (idempotent: 410 on second hit) |

### Pagination

The three paged listings clamp `limit` to 1..100 (a negative, fractional or
non-numeric value lands inside that range rather than reaching SQLite) and
floor `offset` at 0. `/readiness` and `/:id/runs` answer `{ items, nextOffset }`:
`nextOffset` is the `offset` of the next page when this page came back full,
and `null` when it came back short. A full last page therefore costs one extra,
empty request. `GET /api/workflows` is still a bare array.

This is offset paging. Runs are ordered `created DESC, rowid DESC`, a total
order, so paging an unchanged table visits every run once. Under concurrent
inserts it is not stable: a new run shifts every later page down by one, so the
next page repeats the previous page's last run. Only a keyset cursor fixes that.
The natural key for this order is the pair `(created, rowid)`, but `flow_run`
has a TEXT primary key, so its `rowid` is implicit and `VACUUM` may renumber it,
which would silently invalidate a cursor a client holds; and `flow_run.id` is a
nanoid, not time-sortable. A cursor therefore needs its own stable column.

### Request limits

Every write route under `/api/workflows` that reads a body reads it through one
bounded reader: the declared `content-length` is checked before anything is
read, the text is checked again after, and both answer **413** naming the limit.
A body that is not a JSON object answers 400. The public waitpoint resume route
has its own reader with the same two size checks, but it tolerates a body that
is not JSON (it resumes with `{}`); a body that IS JSON must be an object. Where a route accepts no body (`/publish`, `/run`, `/code-steps`), an
empty or whitespace-only body reads as `{}`.

| Route | Body cap | Other limits |
|---|---|---|
| `POST /api/workflows`, `PATCH /api/workflows/:id` | 262,144 bytes | `displayName` required on POST, at most 512 characters (413). `metadata` a JSON object or null, at most 16,384 characters serialized (413), no `__proto__` / `constructor` / `prototype` key (400). `status` must be `ENABLED` or `DISABLED` (400) |
| `POST /api/workflows/:id/versions`, `PATCH .../versions/:vid` | 4,000,000 bytes | `displayName` at most 512 characters (413). `uiMeta` shape-checked (400). PATCH only: `connectionIds` / `agentIds` arrays of strings (400), at most 100 entries each and 256 characters an entry (413); the POST ignores both |
| `PATCH .../sample-data/:step`, `PATCH .../sample-input/:step` | 2,000,000 bytes | `:step` at most 120 characters (413) and not `__proto__` / `prototype` / `constructor` (400). One entry at most 262,144 characters serialized (413). The whole map at most 100 entries and 4,194,304 characters serialized, keys included (413); a write that shrinks an over-limit map is always allowed. A LOCKED version is refused (409) |
| `POST /api/workflows/:id/publish` | 262,144 bytes | Empty, `{}` or `{ versionId }` with a non-empty string (400 otherwise) |
| `POST /api/workflows/:id/code-steps` | 262,144 bytes | `enabled` must be a boolean (400) |
| `POST /api/workflows/:id/run` | 1,000,000 bytes | `environment` must be `PRODUCTION` or `TESTING` (400). `triggeredBy` a string of at most 200 characters (400). `workItemId` must come alone (400) |
| `POST /api/workflows/connections` | 262,144 bytes | `externalId`, `displayName`, `type`, `pieceName` required; `value` an object; `value` must carry what its `type` needs (`access_token` for OAuth types, `username` + `password` for `BASIC_AUTH`, `secret` or `value` for `SECRET_TEXT`) (400) |
| `PATCH /api/workflows/connections/:id` | 262,144 bytes | `status` must be `ACTIVE`, `MISSING` or `ERROR` (400). `displayName` a non-empty string, `value` an object that passes the same per-type check (400). The type cannot change. A rename leaves the stored ciphertext untouched |
| `POST /api/webhooks/waitpoints/:id` | 1,000,000 bytes | Rate limited: 60 a minute per waitpoint, 30 a minute for unknown ids, 600 a minute overall |

### Version ownership

Every `/api/workflows/:id/versions/:vid` route requires `:vid` to be a version
of `:id`. A wrong-parent, missing or unknown version returns 404 without
reading the version or touching either flow, and `POST /api/workflows/:id/publish`
returns 404 for an explicit `versionId` belonging to another flow. That publish
body must be empty, `{}`, or `{ versionId }` with a non-empty string; malformed
JSON and non-object bodies return 400 instead of falling back to the latest
draft. `flow.published_version_id` can only ever name a version of that flow.

The engine subprocess hits `/v1/*` on the same daemon (the SandboxApi). Those routes are documented in the `sandbox-api/routes/` files; users never call them.

## NL composer and `manage_workflow`

The primary agent has a `manage_workflow` tool registered (`src/actions/tools/manage-workflow.ts`). It exposes:

- `list`, `get`, `delete`, `enable`, `disable`, `publish` -- straight CRUD over flows.
- `run` -- resolve a flow by name or id and enqueue a `RUN_FLOW`.
- `create` -- create an empty draft (requires `empty: true` or reroutes to compose if `description` is set).
- `compose` -- sub-agent that builds a `FlowVersion` body from a plain-English description. Two modes:
  - **Tool loop (preferred)**: the planner LLM discovers the platform through tools -- `list_pieces` (compact index), `get_piece_details` / `get_tool_details` (input schemas + `outputSample`s on demand), `search_library` (installable community pieces) -- and finishes via `submit_flow` (validated against the engine-extracted piece schemas; errors fed back as the tool result, up to 4 submits) or `report_blocked` (structured failure carrying `suggestedInstalls` when a library piece would cover the request).
  - **One-shot fallback**: for text-only clients or models that don't call tools, the full piece catalog is inlined into one system prompt and parse/validation errors feed a retry loop (up to 4 attempts). Both modes share the same rule sections and worked examples in the system prompt.

Source: `src/actions/tools/manage-workflow.ts` and `src/actions/tools/workflow-composer.ts`. The composer's role profile lives in `roles/specialists/workflow-default.yaml`.

### Intent-preserving repair

Every repair prompt carries the same versioned job specification, the latest raw
candidate response, the last parseable graph and the current parse/validation
errors. This applies to one-shot repairs, inline JSON and `submit_flow` feedback,
including a first-turn tool response that falls back to one-shot composition.
Malformed text does not erase the last parseable graph. The specification is
authoritative over conflicting candidate data; repair instructions explicitly
preserve the requested trigger, output, destination and negative constraints.

Specification version 1 is `{ schemaVersion: 1, name, description }`. It preserves
the caller's wording rather than inferring structured constraints with another
model. For accepted suggestions, the description includes the accepted expected
outcome. Structural validation still cannot prove fidelity to arbitrary natural
language; the regression tests exercise context transport with synthetic providers,
not live-model success rates.

Both production entry points use `composePersistedFlow`, which saves the
specification to `workflow_composition` before the first provider request and
checkpoints each candidate before another repair. Each write commits separately;
no database transaction spans an LLM call. Records retain full candidate text even
when the chat tool caps its returned `rawResponse`. The resulting flow metadata
contains `compositionRecordId`; chat also returns that ID on success or a normal
composition failure. The record is readable with `getWorkflowComposition(id)`.

Records have three states: `COMPOSING`, `VALIDATED` (structural checks passed), and
`FAILED`. `VALIDATED` does not mean a draft was attached, published, or executed.
An interrupted attempt may remain `COMPOSING` with its last checkpoint after a
restart; this table is authoring provenance, not a queue, and never resumes work
or spends on its own. Suggestion retries continue to use their existing explicit
job contract. The new table is additive; older binaries can ignore it without
rewriting existing flows. Like draft graphs, these records contain user content
in the shared database and its backups.

## Visual editor (UI)

Lives in `ui/src/v2/rooms/workflows/`. Built on `@xyflow/react`.

Notable behaviors a contributor should know:

- The canvas is horizontal (root on the left, downstream to the right).
- Editor state is owned by `useWorkflowEditor.ts`; tree algebra (insert/delete/wire branches) is a pure module at `tree.ts` with its own test file.
- LOOP body and ROUTER branches render as indented sub-graphs on the canvas. The tree-aware auto-layout distributes router branches symmetrically around the parent.
- Inputs accept `{{step.field}}` templates and render them as chips inline.
- The variable picker opens on input focus and lists predecessor outputs (drawn from `outputSample`). Drag-to-insert or click-to-insert; the chip is placed at the caret.
- Per-step sample input override is stored in `flow_version.sample_input`; a run-from-here (`stepNameToTest`) passes it to the engine as `sampleInputOverride`, which replaces that step's `settings.input` (`engine-flow-executor.ts`). Used by the "test this step" affordance.
- Right-click on a node opens delete + error-handling options. Right-click on the canvas opens add-piece. Background tap dismisses popovers.
- Connection picker auto-fills the first available connection for the piece's auth type.
- The editor's runs panel (`useFlowRuns.ts`) polls adaptively: every 2s while any run is QUEUED, RUNNING or PAUSED, every 8s otherwise, and not at all while the tab is hidden. The room-level list (`useWorkflowsData.ts`) polls every 8s.

### Routine requests tab

`RoutineRequestsPanel.tsx` is a fourth tab beside Flows, Connections and Library. It
lists the automation proposals awareness has saved and the drafts they turned into,
reading `/api/awareness/routines` (and `/api/goals` for the goal picker). The legacy
overlay (`ui/overlay.html`) reads `/api/awareness/compositions` instead.

Accepting a proposal (`POST /api/awareness/suggestions/:id/accept`) does not compose
inline. It saves the user-confirmed request as one row in `suggestion_composition_jobs`
and returns. `SuggestionComposer` (`src/awareness/suggestion-composer.ts`) then claims
the job under a lease token, calls `composePersistedFlow` with the same deps `manage_workflow`
uses, and commits the flow, its draft version and the job result in a single
transaction -- the LLM call itself never runs inside a transaction. An interrupted or
timed-out attempt keeps the saved request and requires an explicit retry, so a crash
never re-spends on its own.

The composed flow is created DISABLED with no published version, so accepting a
proposal registers no trigger and runs nothing; publishing and enabling stay explicit
user steps.

## Persistence and encryption

All workflow tables live in `~/.jarvis/jarvis.db` (the same SQLite file as the rest of Jarvis). Schema: `src/workflows/db/schema.ts`. Repos: `src/workflows/db/repos/`.

Connection secrets are encrypted at rest with AES-256-GCM. Wrapping format: `enc1a:<base64(iv | tag | ciphertext)>`, with the row's `(id, project_id, piece_name, external_id)` passed as GCM associated data so a stored value only authenticates against the row it was written for. The older unbound `enc1:` format is still read; convert it with `bun scripts/migrate-native-credentials.ts bind`. The key comes from `JARVIS_WORKFLOW_ENCRYPTION_KEY` (env), `JARVIS_WORKFLOW_ENCRYPTION_KEY_FILE` (an explicit file), or `<data dir>/workflow-encryption.key` (auto-generated, `chmod 0600`) -- the data dir being `JARVIS_SECRETS_DIR` or `JARVIS_HOME` when set and `~/.jarvis` otherwise, the same resolution `.secrets.key` uses. It sits at the data-dir ROOT so any backup of the data dir carries it and `jarvis export --full` lists it; it used to live under `cache/`, which is excluded from exports and documented as disposable. A key still found at the old path is read, and relocated once at daemon boot. Legacy plaintext rows are accepted transparently for backwards compat; set `JARVIS_REQUIRE_ENCRYPTED_CREDENTIALS=1` once conversion is done to refuse them.

If `app_connection` holds encrypted rows in either envelope and no key can be resolved, the daemon refuses to start rather than generating a fresh one: a new key cannot decrypt those rows, and writing with it would overwrite the last copy of the ciphertext. Restore the key file (or set the env var) and start again.

To rotate the key, run `scripts/rotate-encryption-key.ts`. It decrypts every row with the old key, re-encrypts with the new key, and atomically swaps the keychain. It refuses to run while the daemon is up (checks the daemon lock file).

Run state is checkpointed via zstd. When a flow pauses, the engine sends `uploadRunLog(<zstd-state>)`; on resume, `execution-state-loader.ts` decompresses and hands it back via the BEGIN operation as `RESUME` state. This is why a paused workflow survives a daemon restart cleanly.

## Build, cache, and sync

The whole runtime depends on a content-addressed cache chain. Understanding it is essential for debugging "why isn't my change picked up":

- **Engine bundle hash** mixes the synthesized package.json (esbuild deps), the `UPSTREAM_PIN_SHA`, and every file in `PATCHED_VENDOR_SOURCES` (see `src/workflows/runner/engine-runtime/build.ts`). Editing a patched vendor file flips the hash; a fresh bundle goes to `~/.jarvis/cache/engine/<new-hash>/`.
- **Piece bundle hash** mixes the piece's source tree hash with the engine bundle hash. Framework changes invalidate every piece automatically.
- **Catalog cache key** mixes the bundle hashes of every piece + `CATALOG_SCHEMA_VERSION`. Bump the constant in `piece-catalog.ts` if you change the projection format. Cache lives at `~/.jarvis/cache/piece-metadata.json`.

To re-sync with a newer upstream Activepieces release, edit `UPSTREAM_PIN_TAG` + `UPSTREAM_PIN_SHA` in `src/workflows/activepieces/upstream-pin.ts` and run `bun run scripts/sync-activepieces.ts`. The script pulls the new SHA, re-applies every entry in `PATCH_INSERTIONS`, and fails loudly if any anchor goes missing.

The CI guard `scripts/check-no-ee-imports.ts` runs on pre-commit and on every PR. It refuses any import or vendored path that touches Activepieces' `/ee/` (Enterprise License) tree.

### Engine subprocess lifecycle (who kills the engine)

The engine is **pooled across runs by design**, so an engine that is merely still running is working as intended. An engine with no owner is not. Four things keep that from happening (added for #491, where one survived its parent by 82 minutes and ignored SIGTERM):

- **The engine exits on SIGTERM.** Upstream registers a SIGTERM listener that flushes run progress and never exits, which silently removes the runtime's default terminate-on-signal. A shim prepended by the esbuild banner (`engine-lifecycle.ts`) registers first, lets that flush run, then restores the default disposition and re-raises the signal. The shim is part of the bundle hash, so changing it invalidates cached bundles.
- **The engine exits when its owner dies.** The same shim polls whether the pid that spawned it is still alive (signal 0 plus a `/proc` start-time comparison, because Bun caches `process.ppid` at first access and a reparenting check would never fire).
- **The owner reclaims what it spawned.** `spawn.ts` keeps a registry of live engines; `EngineRuntime.shutdown()` kills every engine it spawned, not just the parked one; a `bun test` run that ends with one still alive is reclaimed and **fails the run** via the guard in `src/test-preload.ts` (`JARVIS_ALLOW_LEAKED_ENGINES=1` to opt out while reproducing).
- **Known residue:** a CODE action's own `bun --eval` child inherits the engine's environment but is deliberately never matched by the reaper (it may be mid-step), so reaping its engine orphans it in turn. It holds no pool state and no socket, and `engine-reaper.ts` documents how to match it by ppid if they ever start accumulating.
- **The daemon reaps and prunes at startup.** `engine-reaper.ts` kills engines whose owner is provably gone -- matched by our marker env var, our uid and an argv naming their own bundle, never by process-name pattern -- and prunes `~/.jarvis/cache/engine` by count and age, never touching the bundle in use, a bundle a running engine is executing, or a shared read-only root. `bun run scripts/reap-engines.ts [--dry-run]` does the same by hand.

Knobs (env var wins over the `workflows` config section):

| Variable | Default | Meaning |
| --- | --- | --- |
| `JARVIS_ENGINE_SHUTDOWN_GRACE_MS` | derived: strictly inside the owner's SIGKILL deadline | How long the engine keeps flushing after SIGTERM before exiting. Derived from the owner's kill grace so the two cannot drift; setting it at or above that deadline is warned about. |
| `JARVIS_ENGINE_ORPHAN_POLL_MS` | 5000 | Orphan-watchdog interval inside the engine. 0 disables it. |
| `JARVIS_ENGINE_CACHE_MAX_BUNDLES` / `workflows.engineCacheMaxBundles` | 3 | Bundles kept in `~/.jarvis/cache/engine`. 0 disables the count cap. |
| `JARVIS_ENGINE_CACHE_MAX_AGE_DAYS` / `workflows.engineCacheMaxAgeDays` | 14 | Age past which an untouched bundle is deleted. 0 disables the age cap. |

## Testing

Three test layers, run from cheap to expensive:

1. **Unit + integration tests** -- the bulk. Cover repos, queue, tree algebra, composer parser, catalog projection, drift, etc. Run with `bun test src/workflows/`.
2. **Engine-extract tests against real pieces** -- gated. Set both `JARVIS_TEST_ENGINE_BUILD=1` and `JARVIS_TEST_ENGINE_EXTRACT_PIECE=1` to opt in (`src/workflows/pieces-library/engine-extract.test.ts`). They actually install a piece (e.g. Gmail) and run `EXTRACT_PIECE_METADATA` against it; useful in CI but pricey locally.
3. **End-to-end engine tests** -- gated by `JARVIS_TEST_ENGINE_BUILD=1`. Build the engine bundle, spawn it, run real flows from BEGIN to terminal status. Includes the RESUME-from-paused suite (`end-to-end-resume.test.ts`) and the Phase L plumbing smoke (`end-to-end-l.test.ts`).

The drift test (`runtime/test-fixtures-drift.test.ts`) compares the live engine-extracted catalog against a committed snapshot. If you change a piece's surface, regenerate the fixture and commit it.

## Common contributor tasks

| Task | Where to start | Cross-links |
|---|---|---|
| Add a new Jarvis piece | Drop a directory under `packages/pieces/jarvis/<name>/` | [`PIECE_VERIFICATION.md`](./PIECE_VERIFICATION.md) |
| Verify a piece works end-to-end | Walk the 8-stage checklist | [`PIECE_VERIFICATION.md`](./PIECE_VERIFICATION.md) |
| Add a community piece to the Verified tier | Edit `catalog-overrides.ts` -> `VERIFIED` | [`pieces-library/README.md`](../src/workflows/pieces-library/README.md) |
| Patch a vendored upstream file | Add an entry to `PATCH_INSERTIONS` in `scripts/sync-activepieces.ts` + register the file in `PATCHED_VENDOR_SOURCES` (so the bundle hash invalidates) | [`UPSTREAM.md`](../src/workflows/activepieces/UPSTREAM.md) |
| Upgrade Activepieces | Edit `UPSTREAM_PIN_*` constants, run `sync-activepieces.ts`, fix any drift the patch layer reports | [`UPSTREAM.md`](../src/workflows/activepieces/UPSTREAM.md) |
| Add a new `/v1/jarvis/*` service | Add a route file under `sandbox-api/routes/`, wire it into `server.ts`, wire the backend into `service-backends.ts` | (this file -- "Source tree map") |
| Bump the catalog projection | Bump `CATALOG_SCHEMA_VERSION` in `piece-catalog.ts` so existing caches invalidate | (this file -- "Build, cache, and sync") |
| Run the engine-extract test against a real piece | `JARVIS_TEST_ENGINE_BUILD=1 JARVIS_TEST_ENGINE_EXTRACT_PIECE=1 bun test src/workflows/pieces-library/engine-extract.test.ts` | (this file -- "Testing") |
| Add a new connection source for `jarvis:*` external ids | Implement a `JarvisConnectionSource`, register in `src/workflows/credentials/adapter.ts` | (this file -- "Source tree map") |
| Debug a stuck or weird run | Inspect `flow_run.status` + `waitpoint` rows (a run stuck PAUSED has an unresumed one), then `~/.jarvis/workflow-logs/<runId>.bin` for the engine's last execution state | (this file -- "Persistence and encryption") |

## Glossary

- **Piece** -- an npm package that ships actions and/or triggers. Examples: `@jarvispieces/piece-jarvis-ask`, `@activepieces/piece-gmail`.
- **Flow** -- a workflow as the user sees it. Has a name, a published state, and many versions.
- **Flow version** -- an immutable snapshot of a flow's tree. Triggers reference a specific version.
- **Flow run** -- one execution of a flow version. Has a status (QUEUED / RUNNING / SUCCEEDED / FAILED / PAUSED / TIMEOUT / INTERNAL_ERROR / QUOTA_EXCEEDED / STOPPED / MEMORY_LIMIT_EXCEEDED / SCHEDULE_FAILURE) and a checkpointed execution state. See "Run status lifecycle".
- **Connection** -- a stored credential bound to a piece's auth shape. Encrypted at rest.
- **Engine** -- the vendored Activepieces flow executor, built as a CJS bundle and spawned as a child Bun process.
- **Engine subprocess** -- one instance of the engine, running with a unique sandbox id and engine token. Held in a single-slot warm pool with a 5min idle TTL.
- **`outputSample`** -- a literal sample object an action declares to describe its return shape. The variable picker reads from this; the LLM composer reads from this. Required on every action.
- **`PATCHED_VENDOR_SOURCES`** -- the explicit list of vendored upstream files we patch in this fork. Editing any of them must flip the engine bundle hash.
- **`CATALOG_SCHEMA_VERSION`** -- a string mixed into the piece-metadata cache key. Bump it whenever you change the catalog projection format.
- **`SANDBOX_PROCESS`** -- the engine execution mode we use. Child-process IPC, no `isolated-vm`.
