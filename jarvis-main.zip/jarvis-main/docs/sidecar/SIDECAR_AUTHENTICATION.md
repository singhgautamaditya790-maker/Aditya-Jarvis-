# Sidecar Authentication & Enrollment

## Overview

Sidecars are lightweight processes running on user PCs that expose local capabilities (terminal, filesystem, desktop, browser) to the Jarvis brain (the central server). This document describes how sidecars are enrolled and authenticated.

## Choosing the Brain and JWKS URLs

Each enrollment token contains two operator-controlled URLs:

- `brain` → the WebSocket endpoint the sidecar dials (`wss://.../sidecar/connect` or `ws://.../sidecar/connect`)
- `jwks` → the HTTP(S) endpoint the sidecar uses to fetch the signing key (`https://.../api/sidecars/.well-known/jwks.json`)

In the current daemon, those claims are chosen from a single configured public origin with this precedence:

1. `JARVIS_PUBLIC_URL`
2. `daemon.public_url`
3. `JARVIS_BRAIN_DOMAIN` (legacy alias)
4. `daemon.brain_domain` (legacy alias)
5. `localhost:<daemon.port>` fallback

At startup, the daemon applies the env override in `src/config/loader.ts`, then passes the effective value into `SidecarManager` in `src/daemon/index.ts`. `src/sidecar/manager.ts` derives both JWT claims from that one origin:

- full `https://...` / `wss://...` URLs keep their host and map to secure `brain` + `jwks` endpoints
- bare local hosts such as `localhost:3142` stay `ws://` + `http://`
- other bare hosts default to `wss://` + `https://`

### What to Set for Remote Sidecars

For sidecars running on another machine, set `JARVIS_PUBLIC_URL` or
`daemon.public_url` to the public origin that machine can actually reach.

Good examples:

- `https://brain.example.com`
- `https://brain.example.com:8443`
- `brain.example.com`

Usually wrong for remote sidecars:

- `localhost:3142`
- `127.0.0.1:3142`
- Docker-only hostnames
- private LAN names the sidecar machine cannot resolve or route to

The sidecar must be able to reach the configured origin for both WebSocket connections and JWKS fetches.

If you enroll while the brain is configured with the wrong host, the token will keep those wrong URLs until you re-enroll.

## Architecture

```
Brain (VPS)                              Sidecar (User PC)
┌────────────────────┐                  ┌──────────────────┐
│ ES256 Key Pair     │                  │                  │
│  - private.pem     │    JWT Token     │  Receives token  │
│  - public.pem      │ ───────────────► │  from user       │
│                    │                  │                  │
│ JWKS Endpoint      │ ◄─────────────── │  Fetches public  │
│  /api/sidecars/    │   GET request    │  key from brain  │
│  .well-known/      │                  │                  │
│  jwks.json         │                  │  Verifies JWT    │
│                    │                  │  signature       │
│ WSS Endpoint       │ ◄─────────────── │                  │
│  /sidecar/connect  │   WebSocket      │  Connects with   │
│                    │   + JWT          │  verified token  │
└────────────────────┘                  └──────────────────┘
```

## Key Management

### ES256 Key Pair

The brain uses a single **ES256 (ECDSA P-256)** key pair for signing all sidecar enrollment tokens.

- **Algorithm:** ES256 (ECDSA with P-256 curve and SHA-256)
- **Purpose:** The private key signs JWTs; the public key allows sidecars to verify token authenticity
- **Storage:** `{data_dir}/sidecar-keys/private.pem` and `{data_dir}/sidecar-keys/public.pem`
- **Generation:** Automatically generated on first daemon boot if files don't exist
- **Rotation:** Delete the key files and restart the daemon. All existing sidecar tokens will become invalid and sidecars must re-enroll.

### Why Asymmetric?

Asymmetric signing (ES256) allows sidecars to **verify** that a token was genuinely issued by the brain without possessing the signing secret. This prevents token tampering — a modified token will fail signature verification.

## Enrollment Flow

### Step 1: User Initiates Enrollment (CLI)

On the machine running the brain, the user runs:

```
jarvis enroll "<device-name>"
```

- **`<device-name>`** — a human-readable identifier (e.g., `home-desktop`, `work-laptop`). Enrolling an existing name re-mints its token (upsert); add `--rotate` to also invalidate all previously issued tokens for that device.

The CLI opens the database directly, so it works without a running daemon — including over SSH. Related commands:

```
jarvis enroll "<name>" [--json] [--rotate]   # mint (or re-mint) a device token
jarvis sidecars list [--json]                # list enrolled devices
jarvis revoke <sid>                          # revoke a device
```

(An authenticated `POST /api/sidecars/enroll` endpoint also exists for programmatic use, but the CLI is the normal path.)

### Step 2: Brain Generates JWT

The brain creates a signed JWT containing:

```json
{
  "sub": "sidecar:<sidecar-id>",
  "jti": "<unique-token-id>",
  "sid": "<sidecar-uuid>",
  "name": "home-desktop",
  "brain": "wss://shiny-panda.domain.com/sidecar/connect",
  "jwks": "https://shiny-panda.domain.com/api/sidecars/.well-known/jwks.json",
  "iat": 1709740800
}
```

| Claim  | Description                                              |
|--------|----------------------------------------------------------|
| `sub`  | Subject identifier: `sidecar:<id>`                       |
| `jti`  | Unique token ID (for revocation tracking)                |
| `sid`  | Sidecar UUID (primary identifier)                        |
| `name` | Human-readable sidecar name                              |
| `brain`| WebSocket URL the sidecar should connect to              |
| `jwks` | URL to fetch the brain's public key for token verification |
| `iat`  | Issued-at timestamp                                      |

**Note:** There is no `exp` (expiration) claim. Tokens are long-lived and revoked explicitly (`jarvis revoke <sid>`).

The `brain` and `jwks` claims are operational, not informational:

- the sidecar fetches the signing key from `jwks`
- after verification, it connects to `brain`

If those claims point at the wrong domain, an old ingress, or a host unreachable from the sidecar machine, the token must be re-issued after fixing the configured brain origin.

### Step 3: User Copies Token to Sidecar

`jarvis enroll` prints the JWT to the terminal. The user pastes it into the sidecar's token form (the desktop app asks for it on first run; it is also accepted in Settings, and headlessly via `--token`). Before the token is stored, the sidecar verifies it against the brain it names by requesting an access token (`POST {brain}/sidecar/token` with the enrollment JWT as bearer): an unreachable brain URL, a rejected token, and a server that isn't a Jarvis brain each produce a distinct inline error, and nothing is saved. Only a token the brain accepted is written to the sidecar configuration at `~/.jarvis/sidecar.yaml`.

### Step 4: Sidecar Verifies Token

Before connecting, the sidecar:

1. **Decodes** the JWT payload (without verification) to extract the `brain` domain and `jwks` URL
2. **Fetches** the brain's public key from the JWKS endpoint (`GET {jwks}`)
3. **Verifies** the JWT signature using the fetched public key
4. If verification **fails**, the sidecar refuses to connect and reports an error
5. If verification **succeeds**, the sidecar trusts the token contents

This ensures the token was signed by the real brain and hasn't been tampered with. The JWKS fetch is secured by TLS (HTTPS), which guarantees the domain authenticity.

### Step 5: Sidecar Connects via WebSocket

The sidecar opens a WebSocket connection to the `brain` URL from the JWT, passing the token in the `Authorization` header:

```
GET wss://shiny-panda.domain.com/sidecar/connect
Authorization: Bearer <jwt>
```

### Step 6: Brain Validates Connection

The brain:

1. Extracts the JWT from the `Authorization: Bearer` header
2. Verifies the signature using its private key
3. Checks that the `sid` corresponds to a registered (non-revoked) sidecar
4. Accepts the WebSocket connection and associates it with the sidecar record
5. The sidecar sends a **registration message** with its capabilities:

```json
{
  "type": "register",
  "hostname": "DESKTOP-ABC123",
  "os": "windows",
  "platform": "win32",
  "capabilities": ["terminal", "filesystem", "desktop", "browser", "clipboard", "screenshot"]
}
```

## Token Revocation

Tokens are revoked by deleting the sidecar with `jarvis revoke <sid>` (find the `sid` with `jarvis sidecars list`). The brain maintains a registry of enrolled sidecars in the database. When a sidecar is deleted:

- Its record is removed from the registry
- Any active WebSocket connection is terminated (a running daemon sweeps and severs live sessions of revoked devices within ~30 seconds; new connections and token mints are rejected immediately)
- The JWT token becomes invalid (the `sid` is no longer recognized), even though the signature still verifies

## JWKS Endpoint

**URL:** `GET /api/sidecars/.well-known/jwks.json`

**Response:**
```json
{
  "keys": [
    {
      "kty": "EC",
      "crv": "P-256",
      "x": "<base64url-encoded>",
      "y": "<base64url-encoded>",
      "alg": "ES256",
      "use": "sig",
      "kid": "<key-id>"
    }
  ]
}
```

This endpoint requires no authentication — public keys are safe to expose.

## Troubleshooting Enrollment URL Problems

### Token contains the wrong domain

Symptoms:

- the JWT payload shows `brain` or `jwks` pointing at `localhost`, an outdated hostname, or an internal-only address
- enrollment looked fine on the brain machine, but the sidecar is on another machine (`jarvis enroll` warns when the token falls back to `localhost:<port>`)

Fix:

1. Set `JARVIS_PUBLIC_URL` or `daemon.public_url` to the correct public origin
2. Restart/reload Jarvis so the daemon uses the new value
3. Re-enroll the sidecar so a fresh token is minted with corrected claims

Remember: existing tokens keep the URLs they were issued with.

### JWKS fetch fails

Symptoms:

- TLS/certificate errors
- `404`, `502`, DNS failure, or `connection refused` when requesting `/api/sidecars/.well-known/jwks.json`

Fix:

1. Verify the configured origin serves `GET /api/sidecars/.well-known/jwks.json`
2. Confirm your proxy/tunnel forwards that path to Jarvis
3. Make sure the sidecar machine can resolve and reach the configured host
4. Use a certificate trusted by the sidecar machine when using HTTPS

### WebSocket connection fails after verification

Symptoms:

- JWT verification succeeds, but the sidecar cannot connect to `/sidecar/connect`
- handshake failures, `404`, `426`, or proxy disconnects

Fix:

1. Verify the `brain` claim points to the correct public host and port
2. Confirm your proxy supports WebSocket upgrades for `/sidecar/connect`
3. Check firewall and routing rules between the sidecar machine and the brain ingress
4. Re-enroll after fixing the configured origin so the token carries the corrected `brain` claim

### YAML and environment disagree

`JARVIS_PUBLIC_URL` overrides `daemon.public_url`, which overrides the legacy
brain-domain settings. If the token does not match the YAML value you expected,
check the daemon process environment first.

## Security Considerations

1. **Token transport:** The JWT is printed to the terminal by `jarvis enroll` and must be securely transferred to the sidecar machine by the user. Treat it like a password.
2. **TLS required:** Both the JWKS fetch and the WebSocket connection must use HTTPS/WSS in production.
3. **No expiration:** Tokens don't expire. Revocation is handled by removing the sidecar from the brain's registry.
4. **Single key pair:** One ES256 key pair signs all sidecar tokens. Rotation requires re-enrollment of all sidecars.
5. **Authority gates:** Tool execution on sidecars goes through the same authority engine as local tools — the sidecar connection is just a transport layer.

## Database Schema

Enrolled sidecars are tracked in the `sidecars` table:

```sql
CREATE TABLE IF NOT EXISTS sidecars (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  token_id TEXT NOT NULL UNIQUE,
  enrolled_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT,
  status TEXT NOT NULL DEFAULT 'enrolled',
  hostname TEXT,
  os TEXT,
  platform TEXT,
  capabilities TEXT
);
```

| Column         | Description                                                         |
|----------------|---------------------------------------------------------------------|
| `id`           | Sidecar UUID (matches `sid` in JWT)                                 |
| `name`         | Human-readable name                                                  |
| `token_id`     | JWT `jti` claim (for revocation tracking)                           |
| `enrolled_at`  | Enrollment timestamp                                                 |
| `last_seen_at` | Last WebSocket connection timestamp                                  |
| `status`       | `enrolled` or `revoked`                                             |
| `hostname`     | Machine hostname (populated on first connection)                     |
| `os`           | Operating system (e.g., `windows`, `linux`, `darwin`)                |
| `platform`     | Platform identifier (e.g., `win32`, `linux`)                         |
| `capabilities` | JSON array of capabilities (e.g., `["terminal","desktop","browser"]`) |
